const r=e=>!(!e||e!==window.location.origin);window.addEventListener("message",async e=>{const{data:i,origin:n}=e;r(n)&&await chrome.runtime.sendMessage(chrome.runtime.id,i)});
