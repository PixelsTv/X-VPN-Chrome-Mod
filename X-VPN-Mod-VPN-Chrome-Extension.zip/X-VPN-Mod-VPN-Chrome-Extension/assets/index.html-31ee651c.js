import {
    l as log,
    R as STORE_USERINFO,
    S as STORE_CONNECTSTATUS,
    T as STORE_SERVERGROUP,
    U as STORE_SERVER,
    V as STORE_BYPASS,
    W as STORE_AUTOPROTECTION,
    q as STORE_STABLECONNECT,
    X as STORE_KILLSWITCH,
    Y as STORE_WEBRTC,
    Z as STORE_SETTINGS,
    _ as STORE_ERROR,
    f as store,
    $ as STORE_PRIVACY,
    r as getConnectServer,
    a0 as isProxyCanControlled,
    y as serverObj,
    a1 as setConnectServer,
    a2 as sendMessage,
    m as STORE_CONNECT_INFO,
    K as getUser,
    a as api,
    b as safeParse,
    e as showError,
    c as setUser,
    k as CONNECT_CONNECTED,
    a3 as STORE_FLAG_AUTOPROTECT,
    n as newUrlTab,
    A as APIHOST,
    a4 as DIALOG_SIGNOUT,
    a5 as DIALOG_SPLITTUNNEL_CONNECTED,
    a6 as DIALOG_AUTOPROTECT_WARNING,
    a7 as DIALOG_KILLSWITCH_CONNECTED,
    a8 as DIALOG_KILLSWITCH_SET,
    h as CONNECT_DISCONNECTED,
    o as CONNECT_DISCONNECTING,
    C as CONNECT_CONNECTING,
    a9 as VERSION,
    M as hideError,
    E as ERROR_CONNECTFAILED,
    P as ERROR_CONNECTION,
    O as ERROR_CONNECTIONWITHKS,
    Q as ERROR_TUNNEL,
    aa as ERROR_SYNCFAILED,
    ab as ERROR_AUTHFAILED
} from "./server-f1f17c64.js";
(function () {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload")) return;
    for (const s of document.querySelectorAll('link[rel="modulepreload"]')) i(s);
    new MutationObserver(s => {
        for (const n of s)
            if (n.type === "childList")
                for (const a of n.addedNodes) a.tagName === "LINK" && a.rel === "modulepreload" && i(a)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function r(s) {
        const n = {};
        return s.integrity && (n.integrity = s.integrity), s.referrerPolicy && (n.referrerPolicy = s.referrerPolicy), s.crossOrigin === "use-credentials" ? n.credentials = "include" : s.crossOrigin === "anonymous" ? n.credentials = "omit" : n.credentials = "same-origin", n
    }

    function i(s) {
        if (s.ep) return;
        s.ep = !0;
        const n = r(s);
        fetch(s.href, n)
    }
})();
const main = "";

function makeMap(e, t) {
    const r = Object.create(null),
        i = e.split(",");
    for (let s = 0; s < i.length; s++) r[i[s]] = !0;
    return t ? s => !!r[s.toLowerCase()] : s => !!r[s]
}
const EMPTY_OBJ = {},
    EMPTY_ARR = [],
    NOOP = () => {},
    NO = () => !1,
    onRE = /^on[^a-z]/,
    isOn = e => onRE.test(e),
    isModelListener = e => e.startsWith("onUpdate:"),
    extend = Object.assign,
    remove = (e, t) => {
        const r = e.indexOf(t);
        r > -1 && e.splice(r, 1)
    },
    hasOwnProperty$1 = Object.prototype.hasOwnProperty,
    hasOwn = (e, t) => hasOwnProperty$1.call(e, t),
    isArray = Array.isArray,
    isMap = e => toTypeString(e) === "[object Map]",
    isSet = e => toTypeString(e) === "[object Set]",
    isFunction = e => typeof e == "function",
    isString = e => typeof e == "string",
    isSymbol = e => typeof e == "symbol",
    isObject = e => e !== null && typeof e == "object",
    isPromise = e => isObject(e) && isFunction(e.then) && isFunction(e.catch),
    objectToString = Object.prototype.toString,
    toTypeString = e => objectToString.call(e),
    toRawType = e => toTypeString(e).slice(8, -1),
    isPlainObject = e => toTypeString(e) === "[object Object]",
    isIntegerKey = e => isString(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e,
    isReservedProp = makeMap(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
    cacheStringFunction = e => {
        const t = Object.create(null);
        return r => t[r] || (t[r] = e(r))
    },
    camelizeRE = /-(\w)/g,
    camelize = cacheStringFunction(e => e.replace(camelizeRE, (t, r) => r ? r.toUpperCase() : "")),
    hyphenateRE = /\B([A-Z])/g,
    hyphenate = cacheStringFunction(e => e.replace(hyphenateRE, "-$1").toLowerCase()),
    capitalize = cacheStringFunction(e => e.charAt(0).toUpperCase() + e.slice(1)),
    toHandlerKey = cacheStringFunction(e => e ? `on${capitalize(e)}` : ""),
    hasChanged = (e, t) => !Object.is(e, t),
    invokeArrayFns = (e, t) => {
        for (let r = 0; r < e.length; r++) e[r](t)
    },
    def = (e, t, r) => {
        Object.defineProperty(e, t, {
            configurable: !0,
            enumerable: !1,
            value: r
        })
    },
    looseToNumber = e => {
        const t = parseFloat(e);
        return isNaN(t) ? e : t
    };
let _globalThis;
const getGlobalThis = () => _globalThis || (_globalThis = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});

function normalizeStyle(e) {
    if (isArray(e)) {
        const t = {};
        for (let r = 0; r < e.length; r++) {
            const i = e[r],
                s = isString(i) ? parseStringStyle(i) : normalizeStyle(i);
            if (s)
                for (const n in s) t[n] = s[n]
        }
        return t
    } else {
        if (isString(e)) return e;
        if (isObject(e)) return e
    }
}
const listDelimiterRE = /;(?![^(]*\))/g,
    propertyDelimiterRE = /:([^]+)/,
    styleCommentRE = /\/\*[^]*?\*\//g;

function parseStringStyle(e) {
    const t = {};
    return e.replace(styleCommentRE, "").split(listDelimiterRE).forEach(r => {
        if (r) {
            const i = r.split(propertyDelimiterRE);
            i.length > 1 && (t[i[0].trim()] = i[1].trim())
        }
    }), t
}

function normalizeClass(e) {
    let t = "";
    if (isString(e)) t = e;
    else if (isArray(e))
        for (let r = 0; r < e.length; r++) {
            const i = normalizeClass(e[r]);
            i && (t += i + " ")
        } else if (isObject(e))
            for (const r in e) e[r] && (t += r + " ");
    return t.trim()
}
const specialBooleanAttrs = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",
    isSpecialBooleanAttr = makeMap(specialBooleanAttrs);

function includeBooleanAttr(e) {
    return !!e || e === ""
}
const toDisplayString = e => isString(e) ? e : e == null ? "" : isArray(e) || isObject(e) && (e.toString === objectToString || !isFunction(e.toString)) ? JSON.stringify(e, replacer, 2) : String(e),
    replacer = (e, t) => t && t.__v_isRef ? replacer(e, t.value) : isMap(t) ? {
        [`Map(${t.size})`]: [...t.entries()].reduce((r, [i, s]) => (r[`${i} =>`] = s, r), {})
    } : isSet(t) ? {
        [`Set(${t.size})`]: [...t.values()]
    } : isObject(t) && !isArray(t) && !isPlainObject(t) ? String(t) : t;
let activeEffectScope;
class EffectScope {
    constructor(t = !1) {
        this.detached = t, this._active = !0, this.effects = [], this.cleanups = [], this.parent = activeEffectScope, !t && activeEffectScope && (this.index = (activeEffectScope.scopes || (activeEffectScope.scopes = [])).push(this) - 1)
    }
    get active() {
        return this._active
    }
    run(t) {
        if (this._active) {
            const r = activeEffectScope;
            try {
                return activeEffectScope = this, t()
            } finally {
                activeEffectScope = r
            }
        }
    }
    on() {
        activeEffectScope = this
    }
    off() {
        activeEffectScope = this.parent
    }
    stop(t) {
        if (this._active) {
            let r, i;
            for (r = 0, i = this.effects.length; r < i; r++) this.effects[r].stop();
            for (r = 0, i = this.cleanups.length; r < i; r++) this.cleanups[r]();
            if (this.scopes)
                for (r = 0, i = this.scopes.length; r < i; r++) this.scopes[r].stop(!0);
            if (!this.detached && this.parent && !t) {
                const s = this.parent.scopes.pop();
                s && s !== this && (this.parent.scopes[this.index] = s, s.index = this.index)
            }
            this.parent = void 0, this._active = !1
        }
    }
}

function recordEffectScope(e, t = activeEffectScope) {
    t && t.active && t.effects.push(e)
}

function getCurrentScope() {
    return activeEffectScope
}
const createDep = e => {
        const t = new Set(e);
        return t.w = 0, t.n = 0, t
    },
    wasTracked = e => (e.w & trackOpBit) > 0,
    newTracked = e => (e.n & trackOpBit) > 0,
    initDepMarkers = ({
        deps: e
    }) => {
        if (e.length)
            for (let t = 0; t < e.length; t++) e[t].w |= trackOpBit
    },
    finalizeDepMarkers = e => {
        const {
            deps: t
        } = e;
        if (t.length) {
            let r = 0;
            for (let i = 0; i < t.length; i++) {
                const s = t[i];
                wasTracked(s) && !newTracked(s) ? s.delete(e) : t[r++] = s, s.w &= ~trackOpBit, s.n &= ~trackOpBit
            }
            t.length = r
        }
    },
    targetMap = new WeakMap;
let effectTrackDepth = 0,
    trackOpBit = 1;
const maxMarkerBits = 30;
let activeEffect;
const ITERATE_KEY = Symbol(""),
    MAP_KEY_ITERATE_KEY = Symbol("");
class ReactiveEffect {
    constructor(t, r = null, i) {
        this.fn = t, this.scheduler = r, this.active = !0, this.deps = [], this.parent = void 0, recordEffectScope(this, i)
    }
    run() {
        if (!this.active) return this.fn();
        let t = activeEffect,
            r = shouldTrack;
        for (; t;) {
            if (t === this) return;
            t = t.parent
        }
        try {
            return this.parent = activeEffect, activeEffect = this, shouldTrack = !0, trackOpBit = 1 << ++effectTrackDepth, effectTrackDepth <= maxMarkerBits ? initDepMarkers(this) : cleanupEffect(this), this.fn()
        } finally {
            effectTrackDepth <= maxMarkerBits && finalizeDepMarkers(this), trackOpBit = 1 << --effectTrackDepth, activeEffect = this.parent, shouldTrack = r, this.parent = void 0, this.deferStop && this.stop()
        }
    }
    stop() {
        activeEffect === this ? this.deferStop = !0 : this.active && (cleanupEffect(this), this.onStop && this.onStop(), this.active = !1)
    }
}

function cleanupEffect(e) {
    const {
        deps: t
    } = e;
    if (t.length) {
        for (let r = 0; r < t.length; r++) t[r].delete(e);
        t.length = 0
    }
}
let shouldTrack = !0;
const trackStack = [];

function pauseTracking() {
    trackStack.push(shouldTrack), shouldTrack = !1
}

function resetTracking() {
    const e = trackStack.pop();
    shouldTrack = e === void 0 ? !0 : e
}

function track(e, t, r) {
    if (shouldTrack && activeEffect) {
        let i = targetMap.get(e);
        i || targetMap.set(e, i = new Map);
        let s = i.get(r);
        s || i.set(r, s = createDep()), trackEffects(s)
    }
}

function trackEffects(e, t) {
    let r = !1;
    effectTrackDepth <= maxMarkerBits ? newTracked(e) || (e.n |= trackOpBit, r = !wasTracked(e)) : r = !e.has(activeEffect), r && (e.add(activeEffect), activeEffect.deps.push(e))
}

function trigger(e, t, r, i, s, n) {
    const a = targetMap.get(e);
    if (!a) return;
    let l = [];
    if (t === "clear") l = [...a.values()];
    else if (r === "length" && isArray(e)) {
        const c = Number(i);
        a.forEach((g, _) => {
            (_ === "length" || _ >= c) && l.push(g)
        })
    } else switch (r !== void 0 && l.push(a.get(r)), t) {
        case "add":
            isArray(e) ? isIntegerKey(r) && l.push(a.get("length")) : (l.push(a.get(ITERATE_KEY)), isMap(e) && l.push(a.get(MAP_KEY_ITERATE_KEY)));
            break;
        case "delete":
            isArray(e) || (l.push(a.get(ITERATE_KEY)), isMap(e) && l.push(a.get(MAP_KEY_ITERATE_KEY)));
            break;
        case "set":
            isMap(e) && l.push(a.get(ITERATE_KEY));
            break
    }
    if (l.length === 1) l[0] && triggerEffects(l[0]);
    else {
        const c = [];
        for (const g of l) g && c.push(...g);
        triggerEffects(createDep(c))
    }
}

function triggerEffects(e, t) {
    const r = isArray(e) ? e : [...e];
    for (const i of r) i.computed && triggerEffect(i);
    for (const i of r) i.computed || triggerEffect(i)
}

function triggerEffect(e, t) {
    (e !== activeEffect || e.allowRecurse) && (e.scheduler ? e.scheduler() : e.run())
}
const isNonTrackableKeys = makeMap("__proto__,__v_isRef,__isVue"),
    builtInSymbols = new Set(Object.getOwnPropertyNames(Symbol).filter(e => e !== "arguments" && e !== "caller").map(e => Symbol[e]).filter(isSymbol)),
    get$1 = createGetter(),
    shallowGet = createGetter(!1, !0),
    readonlyGet = createGetter(!0),
    arrayInstrumentations = createArrayInstrumentations();

function createArrayInstrumentations() {
    const e = {};
    return ["includes", "indexOf", "lastIndexOf"].forEach(t => {
        e[t] = function (...r) {
            const i = toRaw(this);
            for (let n = 0, a = this.length; n < a; n++) track(i, "get", n + "");
            const s = i[t](...r);
            return s === -1 || s === !1 ? i[t](...r.map(toRaw)) : s
        }
    }), ["push", "pop", "shift", "unshift", "splice"].forEach(t => {
        e[t] = function (...r) {
            pauseTracking();
            const i = toRaw(this)[t].apply(this, r);
            return resetTracking(), i
        }
    }), e
}

function hasOwnProperty(e) {
    const t = toRaw(this);
    return track(t, "has", e), t.hasOwnProperty(e)
}

function createGetter(e = !1, t = !1) {
    return function (i, s, n) {
        if (s === "__v_isReactive") return !e;
        if (s === "__v_isReadonly") return e;
        if (s === "__v_isShallow") return t;
        if (s === "__v_raw" && n === (e ? t ? shallowReadonlyMap : readonlyMap : t ? shallowReactiveMap : reactiveMap).get(i)) return i;
        const a = isArray(i);
        if (!e) {
            if (a && hasOwn(arrayInstrumentations, s)) return Reflect.get(arrayInstrumentations, s, n);
            if (s === "hasOwnProperty") return hasOwnProperty
        }
        const l = Reflect.get(i, s, n);
        return (isSymbol(s) ? builtInSymbols.has(s) : isNonTrackableKeys(s)) || (e || track(i, "get", s), t) ? l : isRef(l) ? a && isIntegerKey(s) ? l : l.value : isObject(l) ? e ? readonly(l) : reactive(l) : l
    }
}
const set$1 = createSetter(),
    shallowSet = createSetter(!0);

function createSetter(e = !1) {
    return function (r, i, s, n) {
        let a = r[i];
        if (isReadonly(a) && isRef(a) && !isRef(s)) return !1;
        if (!e && (!isShallow(s) && !isReadonly(s) && (a = toRaw(a), s = toRaw(s)), !isArray(r) && isRef(a) && !isRef(s))) return a.value = s, !0;
        const l = isArray(r) && isIntegerKey(i) ? Number(i) < r.length : hasOwn(r, i),
            c = Reflect.set(r, i, s, n);
        return r === toRaw(n) && (l ? hasChanged(s, a) && trigger(r, "set", i, s) : trigger(r, "add", i, s)), c
    }
}

function deleteProperty(e, t) {
    const r = hasOwn(e, t);
    e[t];
    const i = Reflect.deleteProperty(e, t);
    return i && r && trigger(e, "delete", t, void 0), i
}

function has$1(e, t) {
    const r = Reflect.has(e, t);
    return (!isSymbol(t) || !builtInSymbols.has(t)) && track(e, "has", t), r
}

function ownKeys(e) {
    return track(e, "iterate", isArray(e) ? "length" : ITERATE_KEY), Reflect.ownKeys(e)
}
const mutableHandlers = {
        get: get$1,
        set: set$1,
        deleteProperty,
        has: has$1,
        ownKeys
    },
    readonlyHandlers = {
        get: readonlyGet,
        set(e, t) {
            return !0
        },
        deleteProperty(e, t) {
            return !0
        }
    },
    shallowReactiveHandlers = extend({}, mutableHandlers, {
        get: shallowGet,
        set: shallowSet
    }),
    toShallow = e => e,
    getProto = e => Reflect.getPrototypeOf(e);

function get(e, t, r = !1, i = !1) {
    e = e.__v_raw;
    const s = toRaw(e),
        n = toRaw(t);
    r || (t !== n && track(s, "get", t), track(s, "get", n));
    const {
        has: a
    } = getProto(s), l = i ? toShallow : r ? toReadonly : toReactive;
    if (a.call(s, t)) return l(e.get(t));
    if (a.call(s, n)) return l(e.get(n));
    e !== s && e.get(t)
}

function has(e, t = !1) {
    const r = this.__v_raw,
        i = toRaw(r),
        s = toRaw(e);
    return t || (e !== s && track(i, "has", e), track(i, "has", s)), e === s ? r.has(e) : r.has(e) || r.has(s)
}

function size(e, t = !1) {
    return e = e.__v_raw, !t && track(toRaw(e), "iterate", ITERATE_KEY), Reflect.get(e, "size", e)
}

function add(e) {
    e = toRaw(e);
    const t = toRaw(this);
    return getProto(t).has.call(t, e) || (t.add(e), trigger(t, "add", e, e)), this
}

function set(e, t) {
    t = toRaw(t);
    const r = toRaw(this),
        {
            has: i,
            get: s
        } = getProto(r);
    let n = i.call(r, e);
    n || (e = toRaw(e), n = i.call(r, e));
    const a = s.call(r, e);
    return r.set(e, t), n ? hasChanged(t, a) && trigger(r, "set", e, t) : trigger(r, "add", e, t), this
}

function deleteEntry(e) {
    const t = toRaw(this),
        {
            has: r,
            get: i
        } = getProto(t);
    let s = r.call(t, e);
    s || (e = toRaw(e), s = r.call(t, e)), i && i.call(t, e);
    const n = t.delete(e);
    return s && trigger(t, "delete", e, void 0), n
}

function clear() {
    const e = toRaw(this),
        t = e.size !== 0,
        r = e.clear();
    return t && trigger(e, "clear", void 0, void 0), r
}

function createForEach(e, t) {
    return function (i, s) {
        const n = this,
            a = n.__v_raw,
            l = toRaw(a),
            c = t ? toShallow : e ? toReadonly : toReactive;
        return !e && track(l, "iterate", ITERATE_KEY), a.forEach((g, _) => i.call(s, c(g), c(_), n))
    }
}

function createIterableMethod(e, t, r) {
    return function (...i) {
        const s = this.__v_raw,
            n = toRaw(s),
            a = isMap(n),
            l = e === "entries" || e === Symbol.iterator && a,
            c = e === "keys" && a,
            g = s[e](...i),
            _ = r ? toShallow : t ? toReadonly : toReactive;
        return !t && track(n, "iterate", c ? MAP_KEY_ITERATE_KEY : ITERATE_KEY), {
            next() {
                const {
                    value: E,
                    done: P
                } = g.next();
                return P ? {
                    value: E,
                    done: P
                } : {
                    value: l ? [_(E[0]), _(E[1])] : _(E),
                    done: P
                }
            },
            [Symbol.iterator]() {
                return this
            }
        }
    }
}

function createReadonlyMethod(e) {
    return function (...t) {
        return e === "delete" ? !1 : this
    }
}

function createInstrumentations() {
    const e = {
            get(n) {
                return get(this, n)
            },
            get size() {
                return size(this)
            },
            has,
            add,
            set,
            delete: deleteEntry,
            clear,
            forEach: createForEach(!1, !1)
        },
        t = {
            get(n) {
                return get(this, n, !1, !0)
            },
            get size() {
                return size(this)
            },
            has,
            add,
            set,
            delete: deleteEntry,
            clear,
            forEach: createForEach(!1, !0)
        },
        r = {
            get(n) {
                return get(this, n, !0)
            },
            get size() {
                return size(this, !0)
            },
            has(n) {
                return has.call(this, n, !0)
            },
            add: createReadonlyMethod("add"),
            set: createReadonlyMethod("set"),
            delete: createReadonlyMethod("delete"),
            clear: createReadonlyMethod("clear"),
            forEach: createForEach(!0, !1)
        },
        i = {
            get(n) {
                return get(this, n, !0, !0)
            },
            get size() {
                return size(this, !0)
            },
            has(n) {
                return has.call(this, n, !0)
            },
            add: createReadonlyMethod("add"),
            set: createReadonlyMethod("set"),
            delete: createReadonlyMethod("delete"),
            clear: createReadonlyMethod("clear"),
            forEach: createForEach(!0, !0)
        };
    return ["keys", "values", "entries", Symbol.iterator].forEach(n => {
        e[n] = createIterableMethod(n, !1, !1), r[n] = createIterableMethod(n, !0, !1), t[n] = createIterableMethod(n, !1, !0), i[n] = createIterableMethod(n, !0, !0)
    }), [e, r, t, i]
}
const [mutableInstrumentations, readonlyInstrumentations, shallowInstrumentations, shallowReadonlyInstrumentations] = createInstrumentations();

function createInstrumentationGetter(e, t) {
    const r = t ? e ? shallowReadonlyInstrumentations : shallowInstrumentations : e ? readonlyInstrumentations : mutableInstrumentations;
    return (i, s, n) => s === "__v_isReactive" ? !e : s === "__v_isReadonly" ? e : s === "__v_raw" ? i : Reflect.get(hasOwn(r, s) && s in i ? r : i, s, n)
}
const mutableCollectionHandlers = {
        get: createInstrumentationGetter(!1, !1)
    },
    shallowCollectionHandlers = {
        get: createInstrumentationGetter(!1, !0)
    },
    readonlyCollectionHandlers = {
        get: createInstrumentationGetter(!0, !1)
    },
    reactiveMap = new WeakMap,
    shallowReactiveMap = new WeakMap,
    readonlyMap = new WeakMap,
    shallowReadonlyMap = new WeakMap;

function targetTypeMap(e) {
    switch (e) {
        case "Object":
        case "Array":
            return 1;
        case "Map":
        case "Set":
        case "WeakMap":
        case "WeakSet":
            return 2;
        default:
            return 0
    }
}

function getTargetType(e) {
    return e.__v_skip || !Object.isExtensible(e) ? 0 : targetTypeMap(toRawType(e))
}

function reactive(e) {
    return isReadonly(e) ? e : createReactiveObject(e, !1, mutableHandlers, mutableCollectionHandlers, reactiveMap)
}

function shallowReactive(e) {
    return createReactiveObject(e, !1, shallowReactiveHandlers, shallowCollectionHandlers, shallowReactiveMap)
}

function readonly(e) {
    return createReactiveObject(e, !0, readonlyHandlers, readonlyCollectionHandlers, readonlyMap)
}

function createReactiveObject(e, t, r, i, s) {
    if (!isObject(e) || e.__v_raw && !(t && e.__v_isReactive)) return e;
    const n = s.get(e);
    if (n) return n;
    const a = getTargetType(e);
    if (a === 0) return e;
    const l = new Proxy(e, a === 2 ? i : r);
    return s.set(e, l), l
}

function isReactive(e) {
    return isReadonly(e) ? isReactive(e.__v_raw) : !!(e && e.__v_isReactive)
}

function isReadonly(e) {
    return !!(e && e.__v_isReadonly)
}

function isShallow(e) {
    return !!(e && e.__v_isShallow)
}

function isProxy(e) {
    return isReactive(e) || isReadonly(e)
}

function toRaw(e) {
    const t = e && e.__v_raw;
    return t ? toRaw(t) : e
}

function markRaw(e) {
    return def(e, "__v_skip", !0), e
}
const toReactive = e => isObject(e) ? reactive(e) : e,
    toReadonly = e => isObject(e) ? readonly(e) : e;

function trackRefValue(e) {
    shouldTrack && activeEffect && (e = toRaw(e), trackEffects(e.dep || (e.dep = createDep())))
}

function triggerRefValue(e, t) {
    e = toRaw(e);
    const r = e.dep;
    r && triggerEffects(r)
}

function isRef(e) {
    return !!(e && e.__v_isRef === !0)
}

function ref(e) {
    return createRef(e, !1)
}

function createRef(e, t) {
    return isRef(e) ? e : new RefImpl(e, t)
}
class RefImpl {
    constructor(t, r) {
        this.__v_isShallow = r, this.dep = void 0, this.__v_isRef = !0, this._rawValue = r ? t : toRaw(t), this._value = r ? t : toReactive(t)
    }
    get value() {
        return trackRefValue(this), this._value
    }
    set value(t) {
        const r = this.__v_isShallow || isShallow(t) || isReadonly(t);
        t = r ? t : toRaw(t), hasChanged(t, this._rawValue) && (this._rawValue = t, this._value = r ? t : toReactive(t), triggerRefValue(this))
    }
}

function unref(e) {
    return isRef(e) ? e.value : e
}
const shallowUnwrapHandlers = {
    get: (e, t, r) => unref(Reflect.get(e, t, r)),
    set: (e, t, r, i) => {
        const s = e[t];
        return isRef(s) && !isRef(r) ? (s.value = r, !0) : Reflect.set(e, t, r, i)
    }
};

function proxyRefs(e) {
    return isReactive(e) ? e : new Proxy(e, shallowUnwrapHandlers)
}
class ComputedRefImpl {
    constructor(t, r, i, s) {
        this._setter = r, this.dep = void 0, this.__v_isRef = !0, this.__v_isReadonly = !1, this._dirty = !0, this.effect = new ReactiveEffect(t, () => {
            this._dirty || (this._dirty = !0, triggerRefValue(this))
        }), this.effect.computed = this, this.effect.active = this._cacheable = !s, this.__v_isReadonly = i
    }
    get value() {
        const t = toRaw(this);
        return trackRefValue(t), (t._dirty || !t._cacheable) && (t._dirty = !1, t._value = t.effect.run()), t._value
    }
    set value(t) {
        this._setter(t)
    }
}

function computed$1(e, t, r = !1) {
    let i, s;
    const n = isFunction(e);
    return n ? (i = e, s = NOOP) : (i = e.get, s = e.set), new ComputedRefImpl(i, s, n || !s, r)
}

function warn(e, ...t) {}

function callWithErrorHandling(e, t, r, i) {
    let s;
    try {
        s = i ? e(...i) : e()
    } catch (n) {
        handleError(n, t, r)
    }
    return s
}

function callWithAsyncErrorHandling(e, t, r, i) {
    if (isFunction(e)) {
        const n = callWithErrorHandling(e, t, r, i);
        return n && isPromise(n) && n.catch(a => {
            handleError(a, t, r)
        }), n
    }
    const s = [];
    for (let n = 0; n < e.length; n++) s.push(callWithAsyncErrorHandling(e[n], t, r, i));
    return s
}

function handleError(e, t, r, i = !0) {
    const s = t ? t.vnode : null;
    if (t) {
        let n = t.parent;
        const a = t.proxy,
            l = r;
        for (; n;) {
            const g = n.ec;
            if (g) {
                for (let _ = 0; _ < g.length; _++)
                    if (g[_](e, a, l) === !1) return
            }
            n = n.parent
        }
        const c = t.appContext.config.errorHandler;
        if (c) {
            callWithErrorHandling(c, null, 10, [e, a, l]);
            return
        }
    }
    logError(e, r, s, i)
}

function logError(e, t, r, i = !0) {
    console.error(e)
}
let isFlushing = !1,
    isFlushPending = !1;
const queue = [];
let flushIndex = 0;
const pendingPostFlushCbs = [];
let activePostFlushCbs = null,
    postFlushIndex = 0;
const resolvedPromise = Promise.resolve();
let currentFlushPromise = null;

function nextTick(e) {
    const t = currentFlushPromise || resolvedPromise;
    return e ? t.then(this ? e.bind(this) : e) : t
}

function findInsertionIndex(e) {
    let t = flushIndex + 1,
        r = queue.length;
    for (; t < r;) {
        const i = t + r >>> 1;
        getId(queue[i]) < e ? t = i + 1 : r = i
    }
    return t
}

function queueJob(e) {
    (!queue.length || !queue.includes(e, isFlushing && e.allowRecurse ? flushIndex + 1 : flushIndex)) && (e.id == null ? queue.push(e) : queue.splice(findInsertionIndex(e.id), 0, e), queueFlush())
}

function queueFlush() {
    !isFlushing && !isFlushPending && (isFlushPending = !0, currentFlushPromise = resolvedPromise.then(flushJobs))
}

function invalidateJob(e) {
    const t = queue.indexOf(e);
    t > flushIndex && queue.splice(t, 1)
}

function queuePostFlushCb(e) {
    isArray(e) ? pendingPostFlushCbs.push(...e) : (!activePostFlushCbs || !activePostFlushCbs.includes(e, e.allowRecurse ? postFlushIndex + 1 : postFlushIndex)) && pendingPostFlushCbs.push(e), queueFlush()
}

function flushPreFlushCbs(e, t = isFlushing ? flushIndex + 1 : 0) {
    for (; t < queue.length; t++) {
        const r = queue[t];
        r && r.pre && (queue.splice(t, 1), t--, r())
    }
}

function flushPostFlushCbs(e) {
    if (pendingPostFlushCbs.length) {
        const t = [...new Set(pendingPostFlushCbs)];
        if (pendingPostFlushCbs.length = 0, activePostFlushCbs) {
            activePostFlushCbs.push(...t);
            return
        }
        for (activePostFlushCbs = t, activePostFlushCbs.sort((r, i) => getId(r) - getId(i)), postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) activePostFlushCbs[postFlushIndex]();
        activePostFlushCbs = null, postFlushIndex = 0
    }
}
const getId = e => e.id == null ? 1 / 0 : e.id,
    comparator = (e, t) => {
        const r = getId(e) - getId(t);
        if (r === 0) {
            if (e.pre && !t.pre) return -1;
            if (t.pre && !e.pre) return 1
        }
        return r
    };

function flushJobs(e) {
    isFlushPending = !1, isFlushing = !0, queue.sort(comparator);
    const t = NOOP;
    try {
        for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
            const r = queue[flushIndex];
            r && r.active !== !1 && callWithErrorHandling(r, null, 14)
        }
    } finally {
        flushIndex = 0, queue.length = 0, flushPostFlushCbs(), isFlushing = !1, currentFlushPromise = null, (queue.length || pendingPostFlushCbs.length) && flushJobs()
    }
}

function emit(e, t, ...r) {
    if (e.isUnmounted) return;
    const i = e.vnode.props || EMPTY_OBJ;
    let s = r;
    const n = t.startsWith("update:"),
        a = n && t.slice(7);
    if (a && a in i) {
        const _ = `${a==="modelValue"?"model":a}Modifiers`,
            {
                number: E,
                trim: P
            } = i[_] || EMPTY_OBJ;
        P && (s = r.map(x => isString(x) ? x.trim() : x)), E && (s = r.map(looseToNumber))
    }
    let l, c = i[l = toHandlerKey(t)] || i[l = toHandlerKey(camelize(t))];
    !c && n && (c = i[l = toHandlerKey(hyphenate(t))]), c && callWithAsyncErrorHandling(c, e, 6, s);
    const g = i[l + "Once"];
    if (g) {
        if (!e.emitted) e.emitted = {};
        else if (e.emitted[l]) return;
        e.emitted[l] = !0, callWithAsyncErrorHandling(g, e, 6, s)
    }
}

function normalizeEmitsOptions(e, t, r = !1) {
    const i = t.emitsCache,
        s = i.get(e);
    if (s !== void 0) return s;
    const n = e.emits;
    let a = {},
        l = !1;
    if (!isFunction(e)) {
        const c = g => {
            const _ = normalizeEmitsOptions(g, t, !0);
            _ && (l = !0, extend(a, _))
        };
        !r && t.mixins.length && t.mixins.forEach(c), e.extends && c(e.extends), e.mixins && e.mixins.forEach(c)
    }
    return !n && !l ? (isObject(e) && i.set(e, null), null) : (isArray(n) ? n.forEach(c => a[c] = null) : extend(a, n), isObject(e) && i.set(e, a), a)
}

function isEmitListener(e, t) {
    return !e || !isOn(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), hasOwn(e, t[0].toLowerCase() + t.slice(1)) || hasOwn(e, hyphenate(t)) || hasOwn(e, t))
}
let currentRenderingInstance = null,
    currentScopeId = null;

function setCurrentRenderingInstance(e) {
    const t = currentRenderingInstance;
    return currentRenderingInstance = e, currentScopeId = e && e.type.__scopeId || null, t
}

function pushScopeId(e) {
    currentScopeId = e
}

function popScopeId() {
    currentScopeId = null
}

function withCtx(e, t = currentRenderingInstance, r) {
    if (!t || e._n) return e;
    const i = (...s) => {
        i._d && setBlockTracking(-1);
        const n = setCurrentRenderingInstance(t);
        let a;
        try {
            a = e(...s)
        } finally {
            setCurrentRenderingInstance(n), i._d && setBlockTracking(1)
        }
        return a
    };
    return i._n = !0, i._c = !0, i._d = !0, i
}

function markAttrsAccessed() {}

function renderComponentRoot(e) {
    const {
        type: t,
        vnode: r,
        proxy: i,
        withProxy: s,
        props: n,
        propsOptions: [a],
        slots: l,
        attrs: c,
        emit: g,
        render: _,
        renderCache: E,
        data: P,
        setupState: x,
        ctx: y,
        inheritAttrs: d
    } = e;
    let b, m;
    const o = setCurrentRenderingInstance(e);
    try {
        if (r.shapeFlag & 4) {
            const u = s || i;
            b = normalizeVNode(_.call(u, u, E, n, x, P, y)), m = c
        } else {
            const u = t;
            b = normalizeVNode(u.length > 1 ? u(n, {
                attrs: c,
                slots: l,
                emit: g
            }) : u(n, null)), m = t.props ? c : getFunctionalFallthrough(c)
        }
    } catch (u) {
        blockStack.length = 0, handleError(u, e, 1), b = createVNode(Comment)
    }
    let f = b;
    if (m && d !== !1) {
        const u = Object.keys(m),
            {
                shapeFlag: S
            } = f;
        u.length && S & 7 && (a && u.some(isModelListener) && (m = filterModelListeners(m, a)), f = cloneVNode(f, m))
    }
    return r.dirs && (f = cloneVNode(f), f.dirs = f.dirs ? f.dirs.concat(r.dirs) : r.dirs), r.transition && (f.transition = r.transition), b = f, setCurrentRenderingInstance(o), b
}
const getFunctionalFallthrough = e => {
        let t;
        for (const r in e)(r === "class" || r === "style" || isOn(r)) && ((t || (t = {}))[r] = e[r]);
        return t
    },
    filterModelListeners = (e, t) => {
        const r = {};
        for (const i in e)(!isModelListener(i) || !(i.slice(9) in t)) && (r[i] = e[i]);
        return r
    };

function shouldUpdateComponent(e, t, r) {
    const {
        props: i,
        children: s,
        component: n
    } = e, {
        props: a,
        children: l,
        patchFlag: c
    } = t, g = n.emitsOptions;
    if (t.dirs || t.transition) return !0;
    if (r && c >= 0) {
        if (c & 1024) return !0;
        if (c & 16) return i ? hasPropsChanged(i, a, g) : !!a;
        if (c & 8) {
            const _ = t.dynamicProps;
            for (let E = 0; E < _.length; E++) {
                const P = _[E];
                if (a[P] !== i[P] && !isEmitListener(g, P)) return !0
            }
        }
    } else return (s || l) && (!l || !l.$stable) ? !0 : i === a ? !1 : i ? a ? hasPropsChanged(i, a, g) : !0 : !!a;
    return !1
}

function hasPropsChanged(e, t, r) {
    const i = Object.keys(t);
    if (i.length !== Object.keys(e).length) return !0;
    for (let s = 0; s < i.length; s++) {
        const n = i[s];
        if (t[n] !== e[n] && !isEmitListener(r, n)) return !0
    }
    return !1
}

function updateHOCHostEl({
    vnode: e,
    parent: t
}, r) {
    for (; t && t.subTree === e;)(e = t.vnode).el = r, t = t.parent
}
const isSuspense = e => e.__isSuspense;

function queueEffectWithSuspense(e, t) {
    t && t.pendingBranch ? isArray(e) ? t.effects.push(...e) : t.effects.push(e) : queuePostFlushCb(e)
}

function watchEffect(e, t) {
    return doWatch(e, null, t)
}
const INITIAL_WATCHER_VALUE = {};

function watch(e, t, r) {
    return doWatch(e, t, r)
}

function doWatch(e, t, {
    immediate: r,
    deep: i,
    flush: s,
    onTrack: n,
    onTrigger: a
} = EMPTY_OBJ) {
    var l;
    const c = getCurrentScope() === ((l = currentInstance) == null ? void 0 : l.scope) ? currentInstance : null;
    let g, _ = !1,
        E = !1;
    if (isRef(e) ? (g = () => e.value, _ = isShallow(e)) : isReactive(e) ? (g = () => e, i = !0) : isArray(e) ? (E = !0, _ = e.some(u => isReactive(u) || isShallow(u)), g = () => e.map(u => {
            if (isRef(u)) return u.value;
            if (isReactive(u)) return traverse(u);
            if (isFunction(u)) return callWithErrorHandling(u, c, 2)
        })) : isFunction(e) ? t ? g = () => callWithErrorHandling(e, c, 2) : g = () => {
            if (!(c && c.isUnmounted)) return P && P(), callWithAsyncErrorHandling(e, c, 3, [x])
        } : g = NOOP, t && i) {
        const u = g;
        g = () => traverse(u())
    }
    let P, x = u => {
            P = o.onStop = () => {
                callWithErrorHandling(u, c, 4)
            }
        },
        y;
    if (isInSSRComponentSetup)
        if (x = NOOP, t ? r && callWithAsyncErrorHandling(t, c, 3, [g(), E ? [] : void 0, x]) : g(), s === "sync") {
            const u = useSSRContext();
            y = u.__watcherHandles || (u.__watcherHandles = [])
        } else return NOOP;
    let d = E ? new Array(e.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
    const b = () => {
        if (o.active)
            if (t) {
                const u = o.run();
                (i || _ || (E ? u.some((S, k) => hasChanged(S, d[k])) : hasChanged(u, d))) && (P && P(), callWithAsyncErrorHandling(t, c, 3, [u, d === INITIAL_WATCHER_VALUE ? void 0 : E && d[0] === INITIAL_WATCHER_VALUE ? [] : d, x]), d = u)
            } else o.run()
    };
    b.allowRecurse = !!t;
    let m;
    s === "sync" ? m = b : s === "post" ? m = () => queuePostRenderEffect(b, c && c.suspense) : (b.pre = !0, c && (b.id = c.uid), m = () => queueJob(b));
    const o = new ReactiveEffect(g, m);
    t ? r ? b() : d = o.run() : s === "post" ? queuePostRenderEffect(o.run.bind(o), c && c.suspense) : o.run();
    const f = () => {
        o.stop(), c && c.scope && remove(c.scope.effects, o)
    };
    return y && y.push(f), f
}

function instanceWatch(e, t, r) {
    const i = this.proxy,
        s = isString(e) ? e.includes(".") ? createPathGetter(i, e) : () => i[e] : e.bind(i, i);
    let n;
    isFunction(t) ? n = t : (n = t.handler, r = t);
    const a = currentInstance;
    setCurrentInstance(this);
    const l = doWatch(s, n.bind(i), r);
    return a ? setCurrentInstance(a) : unsetCurrentInstance(), l
}

function createPathGetter(e, t) {
    const r = t.split(".");
    return () => {
        let i = e;
        for (let s = 0; s < r.length && i; s++) i = i[r[s]];
        return i
    }
}

function traverse(e, t) {
    if (!isObject(e) || e.__v_skip || (t = t || new Set, t.has(e))) return e;
    if (t.add(e), isRef(e)) traverse(e.value, t);
    else if (isArray(e))
        for (let r = 0; r < e.length; r++) traverse(e[r], t);
    else if (isSet(e) || isMap(e)) e.forEach(r => {
        traverse(r, t)
    });
    else if (isPlainObject(e))
        for (const r in e) traverse(e[r], t);
    return e
}

function withDirectives(e, t) {
    const r = currentRenderingInstance;
    if (r === null) return e;
    const i = getExposeProxy(r) || r.proxy,
        s = e.dirs || (e.dirs = []);
    for (let n = 0; n < t.length; n++) {
        let [a, l, c, g = EMPTY_OBJ] = t[n];
        a && (isFunction(a) && (a = {
            mounted: a,
            updated: a
        }), a.deep && traverse(l), s.push({
            dir: a,
            instance: i,
            value: l,
            oldValue: void 0,
            arg: c,
            modifiers: g
        }))
    }
    return e
}

function invokeDirectiveHook(e, t, r, i) {
    const s = e.dirs,
        n = t && t.dirs;
    for (let a = 0; a < s.length; a++) {
        const l = s[a];
        n && (l.oldValue = n[a].value);
        let c = l.dir[i];
        c && (pauseTracking(), callWithAsyncErrorHandling(c, r, 8, [e.el, l, e, t]), resetTracking())
    }
}
const isAsyncWrapper = e => !!e.type.__asyncLoader,
    isKeepAlive = e => e.type.__isKeepAlive;

function onActivated(e, t) {
    registerKeepAliveHook(e, "a", t)
}

function onDeactivated(e, t) {
    registerKeepAliveHook(e, "da", t)
}

function registerKeepAliveHook(e, t, r = currentInstance) {
    const i = e.__wdc || (e.__wdc = () => {
        let s = r;
        for (; s;) {
            if (s.isDeactivated) return;
            s = s.parent
        }
        return e()
    });
    if (injectHook(t, i, r), r) {
        let s = r.parent;
        for (; s && s.parent;) isKeepAlive(s.parent.vnode) && injectToKeepAliveRoot(i, t, r, s), s = s.parent
    }
}

function injectToKeepAliveRoot(e, t, r, i) {
    const s = injectHook(t, e, i, !0);
    onUnmounted(() => {
        remove(i[t], s)
    }, r)
}

function injectHook(e, t, r = currentInstance, i = !1) {
    if (r) {
        const s = r[e] || (r[e] = []),
            n = t.__weh || (t.__weh = (...a) => {
                if (r.isUnmounted) return;
                pauseTracking(), setCurrentInstance(r);
                const l = callWithAsyncErrorHandling(t, r, e, a);
                return unsetCurrentInstance(), resetTracking(), l
            });
        return i ? s.unshift(n) : s.push(n), n
    }
}
const createHook = e => (t, r = currentInstance) => (!isInSSRComponentSetup || e === "sp") && injectHook(e, (...i) => t(...i), r),
    onBeforeMount = createHook("bm"),
    onMounted = createHook("m"),
    onBeforeUpdate = createHook("bu"),
    onUpdated = createHook("u"),
    onBeforeUnmount = createHook("bum"),
    onUnmounted = createHook("um"),
    onServerPrefetch = createHook("sp"),
    onRenderTriggered = createHook("rtg"),
    onRenderTracked = createHook("rtc");

function onErrorCaptured(e, t = currentInstance) {
    injectHook("ec", e, t)
}
const COMPONENTS = "components";

function resolveComponent(e, t) {
    return resolveAsset(COMPONENTS, e, !0, t) || e
}
const NULL_DYNAMIC_COMPONENT = Symbol.for("v-ndc");

function resolveAsset(e, t, r = !0, i = !1) {
    const s = currentRenderingInstance || currentInstance;
    if (s) {
        const n = s.type;
        if (e === COMPONENTS) {
            const l = getComponentName(n, !1);
            if (l && (l === t || l === camelize(t) || l === capitalize(camelize(t)))) return n
        }
        const a = resolve(s[e] || n[e], t) || resolve(s.appContext[e], t);
        return !a && i ? n : a
    }
}

function resolve(e, t) {
    return e && (e[t] || e[camelize(t)] || e[capitalize(camelize(t))])
}

function renderList(e, t, r, i) {
    let s;
    const n = r && r[i];
    if (isArray(e) || isString(e)) {
        s = new Array(e.length);
        for (let a = 0, l = e.length; a < l; a++) s[a] = t(e[a], a, void 0, n && n[a])
    } else if (typeof e == "number") {
        s = new Array(e);
        for (let a = 0; a < e; a++) s[a] = t(a + 1, a, void 0, n && n[a])
    } else if (isObject(e))
        if (e[Symbol.iterator]) s = Array.from(e, (a, l) => t(a, l, void 0, n && n[l]));
        else {
            const a = Object.keys(e);
            s = new Array(a.length);
            for (let l = 0, c = a.length; l < c; l++) {
                const g = a[l];
                s[l] = t(e[g], g, l, n && n[l])
            }
        }
    else s = [];
    return r && (r[i] = s), s
}
const getPublicInstance = e => e ? isStatefulComponent(e) ? getExposeProxy(e) || e.proxy : getPublicInstance(e.parent) : null,
    publicPropertiesMap = extend(Object.create(null), {
        $: e => e,
        $el: e => e.vnode.el,
        $data: e => e.data,
        $props: e => e.props,
        $attrs: e => e.attrs,
        $slots: e => e.slots,
        $refs: e => e.refs,
        $parent: e => getPublicInstance(e.parent),
        $root: e => getPublicInstance(e.root),
        $emit: e => e.emit,
        $options: e => resolveMergedOptions(e),
        $forceUpdate: e => e.f || (e.f = () => queueJob(e.update)),
        $nextTick: e => e.n || (e.n = nextTick.bind(e.proxy)),
        $watch: e => instanceWatch.bind(e)
    }),
    hasSetupBinding = (e, t) => e !== EMPTY_OBJ && !e.__isScriptSetup && hasOwn(e, t),
    PublicInstanceProxyHandlers = {
        get({
            _: e
        }, t) {
            const {
                ctx: r,
                setupState: i,
                data: s,
                props: n,
                accessCache: a,
                type: l,
                appContext: c
            } = e;
            let g;
            if (t[0] !== "$") {
                const x = a[t];
                if (x !== void 0) switch (x) {
                    case 1:
                        return i[t];
                    case 2:
                        return s[t];
                    case 4:
                        return r[t];
                    case 3:
                        return n[t]
                } else {
                    if (hasSetupBinding(i, t)) return a[t] = 1, i[t];
                    if (s !== EMPTY_OBJ && hasOwn(s, t)) return a[t] = 2, s[t];
                    if ((g = e.propsOptions[0]) && hasOwn(g, t)) return a[t] = 3, n[t];
                    if (r !== EMPTY_OBJ && hasOwn(r, t)) return a[t] = 4, r[t];
                    shouldCacheAccess && (a[t] = 0)
                }
            }
            const _ = publicPropertiesMap[t];
            let E, P;
            if (_) return t === "$attrs" && track(e, "get", t), _(e);
            if ((E = l.__cssModules) && (E = E[t])) return E;
            if (r !== EMPTY_OBJ && hasOwn(r, t)) return a[t] = 4, r[t];
            if (P = c.config.globalProperties, hasOwn(P, t)) return P[t]
        },
        set({
            _: e
        }, t, r) {
            const {
                data: i,
                setupState: s,
                ctx: n
            } = e;
            return hasSetupBinding(s, t) ? (s[t] = r, !0) : i !== EMPTY_OBJ && hasOwn(i, t) ? (i[t] = r, !0) : hasOwn(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (n[t] = r, !0)
        },
        has({
            _: {
                data: e,
                setupState: t,
                accessCache: r,
                ctx: i,
                appContext: s,
                propsOptions: n
            }
        }, a) {
            let l;
            return !!r[a] || e !== EMPTY_OBJ && hasOwn(e, a) || hasSetupBinding(t, a) || (l = n[0]) && hasOwn(l, a) || hasOwn(i, a) || hasOwn(publicPropertiesMap, a) || hasOwn(s.config.globalProperties, a)
        },
        defineProperty(e, t, r) {
            return r.get != null ? e._.accessCache[t] = 0 : hasOwn(r, "value") && this.set(e, t, r.value, null), Reflect.defineProperty(e, t, r)
        }
    };

function normalizePropsOrEmits(e) {
    return isArray(e) ? e.reduce((t, r) => (t[r] = null, t), {}) : e
}
let shouldCacheAccess = !0;

function applyOptions(e) {
    const t = resolveMergedOptions(e),
        r = e.proxy,
        i = e.ctx;
    shouldCacheAccess = !1, t.beforeCreate && callHook(t.beforeCreate, e, "bc");
    const {
        data: s,
        computed: n,
        methods: a,
        watch: l,
        provide: c,
        inject: g,
        created: _,
        beforeMount: E,
        mounted: P,
        beforeUpdate: x,
        updated: y,
        activated: d,
        deactivated: b,
        beforeDestroy: m,
        beforeUnmount: o,
        destroyed: f,
        unmounted: u,
        render: S,
        renderTracked: k,
        renderTriggered: C,
        errorCaptured: T,
        serverPrefetch: B,
        expose: D,
        inheritAttrs: H,
        components: L,
        directives: U,
        filters: Y
    } = t;
    if (g && resolveInjections(g, i, null), a)
        for (const I in a) {
            const A = a[I];
            isFunction(A) && (i[I] = A.bind(r))
        }
    if (s) {
        const I = s.call(r, r);
        isObject(I) && (e.data = reactive(I))
    }
    if (shouldCacheAccess = !0, n)
        for (const I in n) {
            const A = n[I],
                R = isFunction(A) ? A.bind(r, r) : isFunction(A.get) ? A.get.bind(r, r) : NOOP,
                X = !isFunction(A) && isFunction(A.set) ? A.set.bind(r) : NOOP,
                O = computed({
                    get: R,
                    set: X
                });
            Object.defineProperty(i, I, {
                enumerable: !0,
                configurable: !0,
                get: () => O.value,
                set: ie => O.value = ie
            })
        }
    if (l)
        for (const I in l) createWatcher(l[I], i, r, I);
    if (c) {
        const I = isFunction(c) ? c.call(r) : c;
        Reflect.ownKeys(I).forEach(A => {
            provide(A, I[A])
        })
    }
    _ && callHook(_, e, "c");

    function V(I, A) {
        isArray(A) ? A.forEach(R => I(R.bind(r))) : A && I(A.bind(r))
    }
    if (V(onBeforeMount, E), V(onMounted, P), V(onBeforeUpdate, x), V(onUpdated, y), V(onActivated, d), V(onDeactivated, b), V(onErrorCaptured, T), V(onRenderTracked, k), V(onRenderTriggered, C), V(onBeforeUnmount, o), V(onUnmounted, u), V(onServerPrefetch, B), isArray(D))
        if (D.length) {
            const I = e.exposed || (e.exposed = {});
            D.forEach(A => {
                Object.defineProperty(I, A, {
                    get: () => r[A],
                    set: R => r[A] = R
                })
            })
        } else e.exposed || (e.exposed = {});
    S && e.render === NOOP && (e.render = S), H != null && (e.inheritAttrs = H), L && (e.components = L), U && (e.directives = U)
}

function resolveInjections(e, t, r = NOOP) {
    isArray(e) && (e = normalizeInject(e));
    for (const i in e) {
        const s = e[i];
        let n;
        isObject(s) ? "default" in s ? n = inject(s.from || i, s.default, !0) : n = inject(s.from || i) : n = inject(s), isRef(n) ? Object.defineProperty(t, i, {
            enumerable: !0,
            configurable: !0,
            get: () => n.value,
            set: a => n.value = a
        }) : t[i] = n
    }
}

function callHook(e, t, r) {
    callWithAsyncErrorHandling(isArray(e) ? e.map(i => i.bind(t.proxy)) : e.bind(t.proxy), t, r)
}

function createWatcher(e, t, r, i) {
    const s = i.includes(".") ? createPathGetter(r, i) : () => r[i];
    if (isString(e)) {
        const n = t[e];
        isFunction(n) && watch(s, n)
    } else if (isFunction(e)) watch(s, e.bind(r));
    else if (isObject(e))
        if (isArray(e)) e.forEach(n => createWatcher(n, t, r, i));
        else {
            const n = isFunction(e.handler) ? e.handler.bind(r) : t[e.handler];
            isFunction(n) && watch(s, n, e)
        }
}

function resolveMergedOptions(e) {
    const t = e.type,
        {
            mixins: r,
            extends: i
        } = t,
        {
            mixins: s,
            optionsCache: n,
            config: {
                optionMergeStrategies: a
            }
        } = e.appContext,
        l = n.get(t);
    let c;
    return l ? c = l : !s.length && !r && !i ? c = t : (c = {}, s.length && s.forEach(g => mergeOptions(c, g, a, !0)), mergeOptions(c, t, a)), isObject(t) && n.set(t, c), c
}

function mergeOptions(e, t, r, i = !1) {
    const {
        mixins: s,
        extends: n
    } = t;
    n && mergeOptions(e, n, r, !0), s && s.forEach(a => mergeOptions(e, a, r, !0));
    for (const a in t)
        if (!(i && a === "expose")) {
            const l = internalOptionMergeStrats[a] || r && r[a];
            e[a] = l ? l(e[a], t[a]) : t[a]
        } return e
}
const internalOptionMergeStrats = {
    data: mergeDataFn,
    props: mergeEmitsOrPropsOptions,
    emits: mergeEmitsOrPropsOptions,
    methods: mergeObjectOptions,
    computed: mergeObjectOptions,
    beforeCreate: mergeAsArray,
    created: mergeAsArray,
    beforeMount: mergeAsArray,
    mounted: mergeAsArray,
    beforeUpdate: mergeAsArray,
    updated: mergeAsArray,
    beforeDestroy: mergeAsArray,
    beforeUnmount: mergeAsArray,
    destroyed: mergeAsArray,
    unmounted: mergeAsArray,
    activated: mergeAsArray,
    deactivated: mergeAsArray,
    errorCaptured: mergeAsArray,
    serverPrefetch: mergeAsArray,
    components: mergeObjectOptions,
    directives: mergeObjectOptions,
    watch: mergeWatchOptions,
    provide: mergeDataFn,
    inject: mergeInject
};

function mergeDataFn(e, t) {
    return t ? e ? function () {
        return extend(isFunction(e) ? e.call(this, this) : e, isFunction(t) ? t.call(this, this) : t)
    } : t : e
}

function mergeInject(e, t) {
    return mergeObjectOptions(normalizeInject(e), normalizeInject(t))
}

function normalizeInject(e) {
    if (isArray(e)) {
        const t = {};
        for (let r = 0; r < e.length; r++) t[e[r]] = e[r];
        return t
    }
    return e
}

function mergeAsArray(e, t) {
    return e ? [...new Set([].concat(e, t))] : t
}

function mergeObjectOptions(e, t) {
    return e ? extend(Object.create(null), e, t) : t
}

function mergeEmitsOrPropsOptions(e, t) {
    return e ? isArray(e) && isArray(t) ? [...new Set([...e, ...t])] : extend(Object.create(null), normalizePropsOrEmits(e), normalizePropsOrEmits(t ?? {})) : t
}

function mergeWatchOptions(e, t) {
    if (!e) return t;
    if (!t) return e;
    const r = extend(Object.create(null), e);
    for (const i in t) r[i] = mergeAsArray(e[i], t[i]);
    return r
}

function createAppContext() {
    return {
        app: null,
        config: {
            isNativeTag: NO,
            performance: !1,
            globalProperties: {},
            optionMergeStrategies: {},
            errorHandler: void 0,
            warnHandler: void 0,
            compilerOptions: {}
        },
        mixins: [],
        components: {},
        directives: {},
        provides: Object.create(null),
        optionsCache: new WeakMap,
        propsCache: new WeakMap,
        emitsCache: new WeakMap
    }
}
let uid$1 = 0;

function createAppAPI(e, t) {
    return function (i, s = null) {
        isFunction(i) || (i = extend({}, i)), s != null && !isObject(s) && (s = null);
        const n = createAppContext(),
            a = new Set;
        let l = !1;
        const c = n.app = {
            _uid: uid$1++,
            _component: i,
            _props: s,
            _container: null,
            _context: n,
            _instance: null,
            version,
            get config() {
                return n.config
            },
            set config(g) {},
            use(g, ..._) {
                return a.has(g) || (g && isFunction(g.install) ? (a.add(g), g.install(c, ..._)) : isFunction(g) && (a.add(g), g(c, ..._))), c
            },
            mixin(g) {
                return n.mixins.includes(g) || n.mixins.push(g), c
            },
            component(g, _) {
                return _ ? (n.components[g] = _, c) : n.components[g]
            },
            directive(g, _) {
                return _ ? (n.directives[g] = _, c) : n.directives[g]
            },
            mount(g, _, E) {
                if (!l) {
                    const P = createVNode(i, s);
                    return P.appContext = n, _ && t ? t(P, g) : e(P, g, E), l = !0, c._container = g, g.__vue_app__ = c, getExposeProxy(P.component) || P.component.proxy
                }
            },
            unmount() {
                l && (e(null, c._container), delete c._container.__vue_app__)
            },
            provide(g, _) {
                return n.provides[g] = _, c
            },
            runWithContext(g) {
                currentApp = c;
                try {
                    return g()
                } finally {
                    currentApp = null
                }
            }
        };
        return c
    }
}
let currentApp = null;

function provide(e, t) {
    if (currentInstance) {
        let r = currentInstance.provides;
        const i = currentInstance.parent && currentInstance.parent.provides;
        i === r && (r = currentInstance.provides = Object.create(i)), r[e] = t
    }
}

function inject(e, t, r = !1) {
    const i = currentInstance || currentRenderingInstance;
    if (i || currentApp) {
        const s = i ? i.parent == null ? i.vnode.appContext && i.vnode.appContext.provides : i.parent.provides : currentApp._context.provides;
        if (s && e in s) return s[e];
        if (arguments.length > 1) return r && isFunction(t) ? t.call(i && i.proxy) : t
    }
}

function initProps(e, t, r, i = !1) {
    const s = {},
        n = {};
    def(n, InternalObjectKey, 1), e.propsDefaults = Object.create(null), setFullProps(e, t, s, n);
    for (const a in e.propsOptions[0]) a in s || (s[a] = void 0);
    r ? e.props = i ? s : shallowReactive(s) : e.type.props ? e.props = s : e.props = n, e.attrs = n
}

function updateProps(e, t, r, i) {
    const {
        props: s,
        attrs: n,
        vnode: {
            patchFlag: a
        }
    } = e, l = toRaw(s), [c] = e.propsOptions;
    let g = !1;
    if ((i || a > 0) && !(a & 16)) {
        if (a & 8) {
            const _ = e.vnode.dynamicProps;
            for (let E = 0; E < _.length; E++) {
                let P = _[E];
                if (isEmitListener(e.emitsOptions, P)) continue;
                const x = t[P];
                if (c)
                    if (hasOwn(n, P)) x !== n[P] && (n[P] = x, g = !0);
                    else {
                        const y = camelize(P);
                        s[y] = resolvePropValue(c, l, y, x, e, !1)
                    }
                else x !== n[P] && (n[P] = x, g = !0)
            }
        }
    } else {
        setFullProps(e, t, s, n) && (g = !0);
        let _;
        for (const E in l)(!t || !hasOwn(t, E) && ((_ = hyphenate(E)) === E || !hasOwn(t, _))) && (c ? r && (r[E] !== void 0 || r[_] !== void 0) && (s[E] = resolvePropValue(c, l, E, void 0, e, !0)) : delete s[E]);
        if (n !== l)
            for (const E in n)(!t || !hasOwn(t, E)) && (delete n[E], g = !0)
    }
    g && trigger(e, "set", "$attrs")
}

function setFullProps(e, t, r, i) {
    const [s, n] = e.propsOptions;
    let a = !1,
        l;
    if (t)
        for (let c in t) {
            if (isReservedProp(c)) continue;
            const g = t[c];
            let _;
            s && hasOwn(s, _ = camelize(c)) ? !n || !n.includes(_) ? r[_] = g : (l || (l = {}))[_] = g : isEmitListener(e.emitsOptions, c) || (!(c in i) || g !== i[c]) && (i[c] = g, a = !0)
        }
    if (n) {
        const c = toRaw(r),
            g = l || EMPTY_OBJ;
        for (let _ = 0; _ < n.length; _++) {
            const E = n[_];
            r[E] = resolvePropValue(s, c, E, g[E], e, !hasOwn(g, E))
        }
    }
    return a
}

function resolvePropValue(e, t, r, i, s, n) {
    const a = e[r];
    if (a != null) {
        const l = hasOwn(a, "default");
        if (l && i === void 0) {
            const c = a.default;
            if (a.type !== Function && !a.skipFactory && isFunction(c)) {
                const {
                    propsDefaults: g
                } = s;
                r in g ? i = g[r] : (setCurrentInstance(s), i = g[r] = c.call(null, t), unsetCurrentInstance())
            } else i = c
        }
        a[0] && (n && !l ? i = !1 : a[1] && (i === "" || i === hyphenate(r)) && (i = !0))
    }
    return i
}

function normalizePropsOptions(e, t, r = !1) {
    const i = t.propsCache,
        s = i.get(e);
    if (s) return s;
    const n = e.props,
        a = {},
        l = [];
    let c = !1;
    if (!isFunction(e)) {
        const _ = E => {
            c = !0;
            const [P, x] = normalizePropsOptions(E, t, !0);
            extend(a, P), x && l.push(...x)
        };
        !r && t.mixins.length && t.mixins.forEach(_), e.extends && _(e.extends), e.mixins && e.mixins.forEach(_)
    }
    if (!n && !c) return isObject(e) && i.set(e, EMPTY_ARR), EMPTY_ARR;
    if (isArray(n))
        for (let _ = 0; _ < n.length; _++) {
            const E = camelize(n[_]);
            validatePropName(E) && (a[E] = EMPTY_OBJ)
        } else if (n)
            for (const _ in n) {
                const E = camelize(_);
                if (validatePropName(E)) {
                    const P = n[_],
                        x = a[E] = isArray(P) || isFunction(P) ? {
                            type: P
                        } : extend({}, P);
                    if (x) {
                        const y = getTypeIndex(Boolean, x.type),
                            d = getTypeIndex(String, x.type);
                        x[0] = y > -1, x[1] = d < 0 || y < d, (y > -1 || hasOwn(x, "default")) && l.push(E)
                    }
                }
            }
    const g = [a, l];
    return isObject(e) && i.set(e, g), g
}

function validatePropName(e) {
    return e[0] !== "$"
}

function getType(e) {
    const t = e && e.toString().match(/^\s*(function|class) (\w+)/);
    return t ? t[2] : e === null ? "null" : ""
}

function isSameType(e, t) {
    return getType(e) === getType(t)
}

function getTypeIndex(e, t) {
    return isArray(t) ? t.findIndex(r => isSameType(r, e)) : isFunction(t) && isSameType(t, e) ? 0 : -1
}
const isInternalKey = e => e[0] === "_" || e === "$stable",
    normalizeSlotValue = e => isArray(e) ? e.map(normalizeVNode) : [normalizeVNode(e)],
    normalizeSlot = (e, t, r) => {
        if (t._n) return t;
        const i = withCtx((...s) => normalizeSlotValue(t(...s)), r);
        return i._c = !1, i
    },
    normalizeObjectSlots = (e, t, r) => {
        const i = e._ctx;
        for (const s in e) {
            if (isInternalKey(s)) continue;
            const n = e[s];
            if (isFunction(n)) t[s] = normalizeSlot(s, n, i);
            else if (n != null) {
                const a = normalizeSlotValue(n);
                t[s] = () => a
            }
        }
    },
    normalizeVNodeSlots = (e, t) => {
        const r = normalizeSlotValue(t);
        e.slots.default = () => r
    },
    initSlots = (e, t) => {
        if (e.vnode.shapeFlag & 32) {
            const r = t._;
            r ? (e.slots = toRaw(t), def(t, "_", r)) : normalizeObjectSlots(t, e.slots = {})
        } else e.slots = {}, t && normalizeVNodeSlots(e, t);
        def(e.slots, InternalObjectKey, 1)
    },
    updateSlots = (e, t, r) => {
        const {
            vnode: i,
            slots: s
        } = e;
        let n = !0,
            a = EMPTY_OBJ;
        if (i.shapeFlag & 32) {
            const l = t._;
            l ? r && l === 1 ? n = !1 : (extend(s, t), !r && l === 1 && delete s._) : (n = !t.$stable, normalizeObjectSlots(t, s)), a = t
        } else t && (normalizeVNodeSlots(e, t), a = {
            default: 1
        });
        if (n)
            for (const l in s) !isInternalKey(l) && !(l in a) && delete s[l]
    };

function setRef(e, t, r, i, s = !1) {
    if (isArray(e)) {
        e.forEach((P, x) => setRef(P, t && (isArray(t) ? t[x] : t), r, i, s));
        return
    }
    if (isAsyncWrapper(i) && !s) return;
    const n = i.shapeFlag & 4 ? getExposeProxy(i.component) || i.component.proxy : i.el,
        a = s ? null : n,
        {
            i: l,
            r: c
        } = e,
        g = t && t.r,
        _ = l.refs === EMPTY_OBJ ? l.refs = {} : l.refs,
        E = l.setupState;
    if (g != null && g !== c && (isString(g) ? (_[g] = null, hasOwn(E, g) && (E[g] = null)) : isRef(g) && (g.value = null)), isFunction(c)) callWithErrorHandling(c, l, 12, [a, _]);
    else {
        const P = isString(c),
            x = isRef(c);
        if (P || x) {
            const y = () => {
                if (e.f) {
                    const d = P ? hasOwn(E, c) ? E[c] : _[c] : c.value;
                    s ? isArray(d) && remove(d, n) : isArray(d) ? d.includes(n) || d.push(n) : P ? (_[c] = [n], hasOwn(E, c) && (E[c] = _[c])) : (c.value = [n], e.k && (_[e.k] = c.value))
                } else P ? (_[c] = a, hasOwn(E, c) && (E[c] = a)) : x && (c.value = a, e.k && (_[e.k] = a))
            };
            a ? (y.id = -1, queuePostRenderEffect(y, r)) : y()
        }
    }
}
const queuePostRenderEffect = queueEffectWithSuspense;

function createRenderer(e) {
    return baseCreateRenderer(e)
}

function baseCreateRenderer(e, t) {
    const r = getGlobalThis();
    r.__VUE__ = !0;
    const {
        insert: i,
        remove: s,
        patchProp: n,
        createElement: a,
        createText: l,
        createComment: c,
        setText: g,
        setElementText: _,
        parentNode: E,
        nextSibling: P,
        setScopeId: x = NOOP,
        insertStaticContent: y
    } = e, d = (M, F, N, z = null, G = null, W = null, K = !1, j = null, q = !!F.dynamicChildren) => {
        if (M === F) return;
        M && !isSameVNodeType(M, F) && (z = pe(M), ie(M, G, W, !0), M = null), F.patchFlag === -2 && (q = !1, F.dynamicChildren = null);
        const {
            type: $,
            ref: ee,
            shapeFlag: J
        } = F;
        switch ($) {
            case Text:
                b(M, F, N, z);
                break;
            case Comment:
                m(M, F, N, z);
                break;
            case Static:
                M == null && o(F, N, z, K);
                break;
            case Fragment:
                L(M, F, N, z, G, W, K, j, q);
                break;
            default:
                J & 1 ? S(M, F, N, z, G, W, K, j, q) : J & 6 ? U(M, F, N, z, G, W, K, j, q) : (J & 64 || J & 128) && $.process(M, F, N, z, G, W, K, j, q, de)
        }
        ee != null && G && setRef(ee, M && M.ref, W, F || M, !F)
    }, b = (M, F, N, z) => {
        if (M == null) i(F.el = l(F.children), N, z);
        else {
            const G = F.el = M.el;
            F.children !== M.children && g(G, F.children)
        }
    }, m = (M, F, N, z) => {
        M == null ? i(F.el = c(F.children || ""), N, z) : F.el = M.el
    }, o = (M, F, N, z) => {
        [M.el, M.anchor] = y(M.children, F, N, z, M.el, M.anchor)
    }, f = ({
        el: M,
        anchor: F
    }, N, z) => {
        let G;
        for (; M && M !== F;) G = P(M), i(M, N, z), M = G;
        i(F, N, z)
    }, u = ({
        el: M,
        anchor: F
    }) => {
        let N;
        for (; M && M !== F;) N = P(M), s(M), M = N;
        s(F)
    }, S = (M, F, N, z, G, W, K, j, q) => {
        K = K || F.type === "svg", M == null ? k(F, N, z, G, W, K, j, q) : B(M, F, G, W, K, j, q)
    }, k = (M, F, N, z, G, W, K, j) => {
        let q, $;
        const {
            type: ee,
            props: J,
            shapeFlag: Q,
            transition: te,
            dirs: re
        } = M;
        if (q = M.el = a(M.type, W, J && J.is, J), Q & 8 ? _(q, M.children) : Q & 16 && T(M.children, q, null, z, G, W && ee !== "foreignObject", K, j), re && invokeDirectiveHook(M, null, z, "created"), C(q, M, M.scopeId, K, z), J) {
            for (const ae in J) ae !== "value" && !isReservedProp(ae) && n(q, ae, null, J[ae], W, M.children, z, G, le);
            "value" in J && n(q, "value", null, J.value), ($ = J.onVnodeBeforeMount) && invokeVNodeHook($, z, M)
        }
        re && invokeDirectiveHook(M, null, z, "beforeMount");
        const ne = (!G || G && !G.pendingBranch) && te && !te.persisted;
        ne && te.beforeEnter(q), i(q, F, N), (($ = J && J.onVnodeMounted) || ne || re) && queuePostRenderEffect(() => {
            $ && invokeVNodeHook($, z, M), ne && te.enter(q), re && invokeDirectiveHook(M, null, z, "mounted")
        }, G)
    }, C = (M, F, N, z, G) => {
        if (N && x(M, N), z)
            for (let W = 0; W < z.length; W++) x(M, z[W]);
        if (G) {
            let W = G.subTree;
            if (F === W) {
                const K = G.vnode;
                C(M, K, K.scopeId, K.slotScopeIds, G.parent)
            }
        }
    }, T = (M, F, N, z, G, W, K, j, q = 0) => {
        for (let $ = q; $ < M.length; $++) {
            const ee = M[$] = j ? cloneIfMounted(M[$]) : normalizeVNode(M[$]);
            d(null, ee, F, N, z, G, W, K, j)
        }
    }, B = (M, F, N, z, G, W, K) => {
        const j = F.el = M.el;
        let {
            patchFlag: q,
            dynamicChildren: $,
            dirs: ee
        } = F;
        q |= M.patchFlag & 16;
        const J = M.props || EMPTY_OBJ,
            Q = F.props || EMPTY_OBJ;
        let te;
        N && toggleRecurse(N, !1), (te = Q.onVnodeBeforeUpdate) && invokeVNodeHook(te, N, F, M), ee && invokeDirectiveHook(F, M, N, "beforeUpdate"), N && toggleRecurse(N, !0);
        const re = G && F.type !== "foreignObject";
        if ($ ? D(M.dynamicChildren, $, j, N, z, re, W) : K || A(M, F, j, null, N, z, re, W, !1), q > 0) {
            if (q & 16) H(j, F, J, Q, N, z, G);
            else if (q & 2 && J.class !== Q.class && n(j, "class", null, Q.class, G), q & 4 && n(j, "style", J.style, Q.style, G), q & 8) {
                const ne = F.dynamicProps;
                for (let ae = 0; ae < ne.length; ae++) {
                    const he = ne[ae],
                        ge = J[he],
                        _e = Q[he];
                    (_e !== ge || he === "value") && n(j, he, ge, _e, G, M.children, N, z, le)
                }
            }
            q & 1 && M.children !== F.children && _(j, F.children)
        } else !K && $ == null && H(j, F, J, Q, N, z, G);
        ((te = Q.onVnodeUpdated) || ee) && queuePostRenderEffect(() => {
            te && invokeVNodeHook(te, N, F, M), ee && invokeDirectiveHook(F, M, N, "updated")
        }, z)
    }, D = (M, F, N, z, G, W, K) => {
        for (let j = 0; j < F.length; j++) {
            const q = M[j],
                $ = F[j],
                ee = q.el && (q.type === Fragment || !isSameVNodeType(q, $) || q.shapeFlag & 70) ? E(q.el) : N;
            d(q, $, ee, null, z, G, W, K, !0)
        }
    }, H = (M, F, N, z, G, W, K) => {
        if (N !== z) {
            if (N !== EMPTY_OBJ)
                for (const j in N) !isReservedProp(j) && !(j in z) && n(M, j, N[j], null, K, F.children, G, W, le);
            for (const j in z) {
                if (isReservedProp(j)) continue;
                const q = z[j],
                    $ = N[j];
                q !== $ && j !== "value" && n(M, j, $, q, K, F.children, G, W, le)
            }
            "value" in z && n(M, "value", N.value, z.value)
        }
    }, L = (M, F, N, z, G, W, K, j, q) => {
        const $ = F.el = M ? M.el : l(""),
            ee = F.anchor = M ? M.anchor : l("");
        let {
            patchFlag: J,
            dynamicChildren: Q,
            slotScopeIds: te
        } = F;
        te && (j = j ? j.concat(te) : te), M == null ? (i($, N, z), i(ee, N, z), T(F.children, N, ee, G, W, K, j, q)) : J > 0 && J & 64 && Q && M.dynamicChildren ? (D(M.dynamicChildren, Q, N, G, W, K, j), (F.key != null || G && F === G.subTree) && traverseStaticChildren(M, F, !0)) : A(M, F, N, ee, G, W, K, j, q)
    }, U = (M, F, N, z, G, W, K, j, q) => {
        F.slotScopeIds = j, M == null ? F.shapeFlag & 512 ? G.ctx.activate(F, N, z, K, q) : Y(F, N, z, G, W, K, q) : Z(M, F, q)
    }, Y = (M, F, N, z, G, W, K) => {
        const j = M.component = createComponentInstance(M, z, G);
        if (isKeepAlive(M) && (j.ctx.renderer = de), setupComponent(j), j.asyncDep) {
            if (G && G.registerDep(j, V), !M.el) {
                const q = j.subTree = createVNode(Comment);
                m(null, q, F, N)
            }
            return
        }
        V(j, M, F, N, G, W, K)
    }, Z = (M, F, N) => {
        const z = F.component = M.component;
        if (shouldUpdateComponent(M, F, N))
            if (z.asyncDep && !z.asyncResolved) {
                I(z, F, N);
                return
            } else z.next = F, invalidateJob(z.update), z.update();
        else F.el = M.el, z.vnode = F
    }, V = (M, F, N, z, G, W, K) => {
        const j = () => {
                if (M.isMounted) {
                    let {
                        next: ee,
                        bu: J,
                        u: Q,
                        parent: te,
                        vnode: re
                    } = M, ne = ee, ae;
                    toggleRecurse(M, !1), ee ? (ee.el = re.el, I(M, ee, K)) : ee = re, J && invokeArrayFns(J), (ae = ee.props && ee.props.onVnodeBeforeUpdate) && invokeVNodeHook(ae, te, ee, re), toggleRecurse(M, !0);
                    const he = renderComponentRoot(M),
                        ge = M.subTree;
                    M.subTree = he, d(ge, he, E(ge.el), pe(ge), M, G, W), ee.el = he.el, ne === null && updateHOCHostEl(M, he.el), Q && queuePostRenderEffect(Q, G), (ae = ee.props && ee.props.onVnodeUpdated) && queuePostRenderEffect(() => invokeVNodeHook(ae, te, ee, re), G)
                } else {
                    let ee;
                    const {
                        el: J,
                        props: Q
                    } = F, {
                        bm: te,
                        m: re,
                        parent: ne
                    } = M, ae = isAsyncWrapper(F);
                    if (toggleRecurse(M, !1), te && invokeArrayFns(te), !ae && (ee = Q && Q.onVnodeBeforeMount) && invokeVNodeHook(ee, ne, F), toggleRecurse(M, !0), J && ce) {
                        const he = () => {
                            M.subTree = renderComponentRoot(M), ce(J, M.subTree, M, G, null)
                        };
                        ae ? F.type.__asyncLoader().then(() => !M.isUnmounted && he()) : he()
                    } else {
                        const he = M.subTree = renderComponentRoot(M);
                        d(null, he, N, z, M, G, W), F.el = he.el
                    }
                    if (re && queuePostRenderEffect(re, G), !ae && (ee = Q && Q.onVnodeMounted)) {
                        const he = F;
                        queuePostRenderEffect(() => invokeVNodeHook(ee, ne, he), G)
                    }(F.shapeFlag & 256 || ne && isAsyncWrapper(ne.vnode) && ne.vnode.shapeFlag & 256) && M.a && queuePostRenderEffect(M.a, G), M.isMounted = !0, F = N = z = null
                }
            },
            q = M.effect = new ReactiveEffect(j, () => queueJob($), M.scope),
            $ = M.update = () => q.run();
        $.id = M.uid, toggleRecurse(M, !0), $()
    }, I = (M, F, N) => {
        F.component = M;
        const z = M.vnode.props;
        M.vnode = F, M.next = null, updateProps(M, F.props, z, N), updateSlots(M, F.children, N), pauseTracking(), flushPreFlushCbs(), resetTracking()
    }, A = (M, F, N, z, G, W, K, j, q = !1) => {
        const $ = M && M.children,
            ee = M ? M.shapeFlag : 0,
            J = F.children,
            {
                patchFlag: Q,
                shapeFlag: te
            } = F;
        if (Q > 0) {
            if (Q & 128) {
                X($, J, N, z, G, W, K, j, q);
                return
            } else if (Q & 256) {
                R($, J, N, z, G, W, K, j, q);
                return
            }
        }
        te & 8 ? (ee & 16 && le($, G, W), J !== $ && _(N, J)) : ee & 16 ? te & 16 ? X($, J, N, z, G, W, K, j, q) : le($, G, W, !0) : (ee & 8 && _(N, ""), te & 16 && T(J, N, z, G, W, K, j, q))
    }, R = (M, F, N, z, G, W, K, j, q) => {
        M = M || EMPTY_ARR, F = F || EMPTY_ARR;
        const $ = M.length,
            ee = F.length,
            J = Math.min($, ee);
        let Q;
        for (Q = 0; Q < J; Q++) {
            const te = F[Q] = q ? cloneIfMounted(F[Q]) : normalizeVNode(F[Q]);
            d(M[Q], te, N, null, G, W, K, j, q)
        }
        $ > ee ? le(M, G, W, !0, !1, J) : T(F, N, z, G, W, K, j, q, J)
    }, X = (M, F, N, z, G, W, K, j, q) => {
        let $ = 0;
        const ee = F.length;
        let J = M.length - 1,
            Q = ee - 1;
        for (; $ <= J && $ <= Q;) {
            const te = M[$],
                re = F[$] = q ? cloneIfMounted(F[$]) : normalizeVNode(F[$]);
            if (isSameVNodeType(te, re)) d(te, re, N, null, G, W, K, j, q);
            else break;
            $++
        }
        for (; $ <= J && $ <= Q;) {
            const te = M[J],
                re = F[Q] = q ? cloneIfMounted(F[Q]) : normalizeVNode(F[Q]);
            if (isSameVNodeType(te, re)) d(te, re, N, null, G, W, K, j, q);
            else break;
            J--, Q--
        }
        if ($ > J) {
            if ($ <= Q) {
                const te = Q + 1,
                    re = te < ee ? F[te].el : z;
                for (; $ <= Q;) d(null, F[$] = q ? cloneIfMounted(F[$]) : normalizeVNode(F[$]), N, re, G, W, K, j, q), $++
            }
        } else if ($ > Q)
            for (; $ <= J;) ie(M[$], G, W, !0), $++;
        else {
            const te = $,
                re = $,
                ne = new Map;
            for ($ = re; $ <= Q; $++) {
                const ve = F[$] = q ? cloneIfMounted(F[$]) : normalizeVNode(F[$]);
                ve.key != null && ne.set(ve.key, $)
            }
            let ae, he = 0;
            const ge = Q - re + 1;
            let _e = !1,
                Ee = 0;
            const be = new Array(ge);
            for ($ = 0; $ < ge; $++) be[$] = 0;
            for ($ = te; $ <= J; $++) {
                const ve = M[$];
                if (he >= ge) {
                    ie(ve, G, W, !0);
                    continue
                }
                let ye;
                if (ve.key != null) ye = ne.get(ve.key);
                else
                    for (ae = re; ae <= Q; ae++)
                        if (be[ae - re] === 0 && isSameVNodeType(ve, F[ae])) {
                            ye = ae;
                            break
                        } ye === void 0 ? ie(ve, G, W, !0) : (be[ye - re] = $ + 1, ye >= Ee ? Ee = ye : _e = !0, d(ve, F[ye], N, null, G, W, K, j, q), he++)
            }
            const Se = _e ? getSequence(be) : EMPTY_ARR;
            for (ae = Se.length - 1, $ = ge - 1; $ >= 0; $--) {
                const ve = re + $,
                    ye = F[ve],
                    Pe = ve + 1 < ee ? F[ve + 1].el : z;
                be[$] === 0 ? d(null, ye, N, Pe, G, W, K, j, q) : _e && (ae < 0 || $ !== Se[ae] ? O(ye, N, Pe, 2) : ae--)
            }
        }
    }, O = (M, F, N, z, G = null) => {
        const {
            el: W,
            type: K,
            transition: j,
            children: q,
            shapeFlag: $
        } = M;
        if ($ & 6) {
            O(M.component.subTree, F, N, z);
            return
        }
        if ($ & 128) {
            M.suspense.move(F, N, z);
            return
        }
        if ($ & 64) {
            K.move(M, F, N, de);
            return
        }
        if (K === Fragment) {
            i(W, F, N);
            for (let J = 0; J < q.length; J++) O(q[J], F, N, z);
            i(M.anchor, F, N);
            return
        }
        if (K === Static) {
            f(M, F, N);
            return
        }
        if (z !== 2 && $ & 1 && j)
            if (z === 0) j.beforeEnter(W), i(W, F, N), queuePostRenderEffect(() => j.enter(W), G);
            else {
                const {
                    leave: J,
                    delayLeave: Q,
                    afterLeave: te
                } = j, re = () => i(W, F, N), ne = () => {
                    J(W, () => {
                        re(), te && te()
                    })
                };
                Q ? Q(W, re, ne) : ne()
            }
        else i(W, F, N)
    }, ie = (M, F, N, z = !1, G = !1) => {
        const {
            type: W,
            props: K,
            ref: j,
            children: q,
            dynamicChildren: $,
            shapeFlag: ee,
            patchFlag: J,
            dirs: Q
        } = M;
        if (j != null && setRef(j, null, N, M, !0), ee & 256) {
            F.ctx.deactivate(M);
            return
        }
        const te = ee & 1 && Q,
            re = !isAsyncWrapper(M);
        let ne;
        if (re && (ne = K && K.onVnodeBeforeUnmount) && invokeVNodeHook(ne, F, M), ee & 6) fe(M.component, N, z);
        else {
            if (ee & 128) {
                M.suspense.unmount(N, z);
                return
            }
            te && invokeDirectiveHook(M, null, F, "beforeUnmount"), ee & 64 ? M.type.remove(M, F, N, G, de, z) : $ && (W !== Fragment || J > 0 && J & 64) ? le($, F, N, !1, !0) : (W === Fragment && J & 384 || !G && ee & 16) && le(q, F, N), z && se(M)
        }(re && (ne = K && K.onVnodeUnmounted) || te) && queuePostRenderEffect(() => {
            ne && invokeVNodeHook(ne, F, M), te && invokeDirectiveHook(M, null, F, "unmounted")
        }, N)
    }, se = M => {
        const {
            type: F,
            el: N,
            anchor: z,
            transition: G
        } = M;
        if (F === Fragment) {
            oe(N, z);
            return
        }
        if (F === Static) {
            u(M);
            return
        }
        const W = () => {
            s(N), G && !G.persisted && G.afterLeave && G.afterLeave()
        };
        if (M.shapeFlag & 1 && G && !G.persisted) {
            const {
                leave: K,
                delayLeave: j
            } = G, q = () => K(N, W);
            j ? j(M.el, W, q) : q()
        } else W()
    }, oe = (M, F) => {
        let N;
        for (; M !== F;) N = P(M), s(M), M = N;
        s(F)
    }, fe = (M, F, N) => {
        const {
            bum: z,
            scope: G,
            update: W,
            subTree: K,
            um: j
        } = M;
        z && invokeArrayFns(z), G.stop(), W && (W.active = !1, ie(K, M, F, N)), j && queuePostRenderEffect(j, F), queuePostRenderEffect(() => {
            M.isUnmounted = !0
        }, F), F && F.pendingBranch && !F.isUnmounted && M.asyncDep && !M.asyncResolved && M.suspenseId === F.pendingId && (F.deps--, F.deps === 0 && F.resolve())
    }, le = (M, F, N, z = !1, G = !1, W = 0) => {
        for (let K = W; K < M.length; K++) ie(M[K], F, N, z, G)
    }, pe = M => M.shapeFlag & 6 ? pe(M.component.subTree) : M.shapeFlag & 128 ? M.suspense.next() : P(M.anchor || M.el), me = (M, F, N) => {
        M == null ? F._vnode && ie(F._vnode, null, null, !0) : d(F._vnode || null, M, F, null, null, null, N), flushPreFlushCbs(), flushPostFlushCbs(), F._vnode = M
    }, de = {
        p: d,
        um: ie,
        m: O,
        r: se,
        mt: Y,
        mc: T,
        pc: A,
        pbc: D,
        n: pe,
        o: e
    };
    let ue, ce;
    return t && ([ue, ce] = t(de)), {
        render: me,
        hydrate: ue,
        createApp: createAppAPI(me, ue)
    }
}

function toggleRecurse({
    effect: e,
    update: t
}, r) {
    e.allowRecurse = t.allowRecurse = r
}

function traverseStaticChildren(e, t, r = !1) {
    const i = e.children,
        s = t.children;
    if (isArray(i) && isArray(s))
        for (let n = 0; n < i.length; n++) {
            const a = i[n];
            let l = s[n];
            l.shapeFlag & 1 && !l.dynamicChildren && ((l.patchFlag <= 0 || l.patchFlag === 32) && (l = s[n] = cloneIfMounted(s[n]), l.el = a.el), r || traverseStaticChildren(a, l)), l.type === Text && (l.el = a.el)
        }
}

function getSequence(e) {
    const t = e.slice(),
        r = [0];
    let i, s, n, a, l;
    const c = e.length;
    for (i = 0; i < c; i++) {
        const g = e[i];
        if (g !== 0) {
            if (s = r[r.length - 1], e[s] < g) {
                t[i] = s, r.push(i);
                continue
            }
            for (n = 0, a = r.length - 1; n < a;) l = n + a >> 1, e[r[l]] < g ? n = l + 1 : a = l;
            g < e[r[n]] && (n > 0 && (t[i] = r[n - 1]), r[n] = i)
        }
    }
    for (n = r.length, a = r[n - 1]; n-- > 0;) r[n] = a, a = t[a];
    return r
}
const isTeleport = e => e.__isTeleport,
    Fragment = Symbol.for("v-fgt"),
    Text = Symbol.for("v-txt"),
    Comment = Symbol.for("v-cmt"),
    Static = Symbol.for("v-stc"),
    blockStack = [];
let currentBlock = null;

function openBlock(e = !1) {
    blockStack.push(currentBlock = e ? null : [])
}

function closeBlock() {
    blockStack.pop(), currentBlock = blockStack[blockStack.length - 1] || null
}
let isBlockTreeEnabled = 1;

function setBlockTracking(e) {
    isBlockTreeEnabled += e
}

function setupBlock(e) {
    return e.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null, closeBlock(), isBlockTreeEnabled > 0 && currentBlock && currentBlock.push(e), e
}

function createElementBlock(e, t, r, i, s, n) {
    return setupBlock(createBaseVNode(e, t, r, i, s, n, !0))
}

function createBlock(e, t, r, i, s) {
    return setupBlock(createVNode(e, t, r, i, s, !0))
}

function isVNode(e) {
    return e ? e.__v_isVNode === !0 : !1
}

function isSameVNodeType(e, t) {
    return e.type === t.type && e.key === t.key
}
const InternalObjectKey = "__vInternal",
    normalizeKey = ({
        key: e
    }) => e ?? null,
    normalizeRef = ({
        ref: e,
        ref_key: t,
        ref_for: r
    }) => (typeof e == "number" && (e = "" + e), e != null ? isString(e) || isRef(e) || isFunction(e) ? {
        i: currentRenderingInstance,
        r: e,
        k: t,
        f: !!r
    } : e : null);

function createBaseVNode(e, t = null, r = null, i = 0, s = null, n = e === Fragment ? 0 : 1, a = !1, l = !1) {
    const c = {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e,
        props: t,
        key: t && normalizeKey(t),
        ref: t && normalizeRef(t),
        scopeId: currentScopeId,
        slotScopeIds: null,
        children: r,
        component: null,
        suspense: null,
        ssContent: null,
        ssFallback: null,
        dirs: null,
        transition: null,
        el: null,
        anchor: null,
        target: null,
        targetAnchor: null,
        staticCount: 0,
        shapeFlag: n,
        patchFlag: i,
        dynamicProps: s,
        dynamicChildren: null,
        appContext: null,
        ctx: currentRenderingInstance
    };
    return l ? (normalizeChildren(c, r), n & 128 && e.normalize(c)) : r && (c.shapeFlag |= isString(r) ? 8 : 16), isBlockTreeEnabled > 0 && !a && currentBlock && (c.patchFlag > 0 || n & 6) && c.patchFlag !== 32 && currentBlock.push(c), c
}
const createVNode = _createVNode;

function _createVNode(e, t = null, r = null, i = 0, s = null, n = !1) {
    if ((!e || e === NULL_DYNAMIC_COMPONENT) && (e = Comment), isVNode(e)) {
        const l = cloneVNode(e, t, !0);
        return r && normalizeChildren(l, r), isBlockTreeEnabled > 0 && !n && currentBlock && (l.shapeFlag & 6 ? currentBlock[currentBlock.indexOf(e)] = l : currentBlock.push(l)), l.patchFlag |= -2, l
    }
    if (isClassComponent(e) && (e = e.__vccOpts), t) {
        t = guardReactiveProps(t);
        let {
            class: l,
            style: c
        } = t;
        l && !isString(l) && (t.class = normalizeClass(l)), isObject(c) && (isProxy(c) && !isArray(c) && (c = extend({}, c)), t.style = normalizeStyle(c))
    }
    const a = isString(e) ? 1 : isSuspense(e) ? 128 : isTeleport(e) ? 64 : isObject(e) ? 4 : isFunction(e) ? 2 : 0;
    return createBaseVNode(e, t, r, i, s, a, n, !0)
}

function guardReactiveProps(e) {
    return e ? isProxy(e) || InternalObjectKey in e ? extend({}, e) : e : null
}

function cloneVNode(e, t, r = !1) {
    const {
        props: i,
        ref: s,
        patchFlag: n,
        children: a
    } = e, l = t ? mergeProps(i || {}, t) : i;
    return {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e.type,
        props: l,
        key: l && normalizeKey(l),
        ref: t && t.ref ? r && s ? isArray(s) ? s.concat(normalizeRef(t)) : [s, normalizeRef(t)] : normalizeRef(t) : s,
        scopeId: e.scopeId,
        slotScopeIds: e.slotScopeIds,
        children: a,
        target: e.target,
        targetAnchor: e.targetAnchor,
        staticCount: e.staticCount,
        shapeFlag: e.shapeFlag,
        patchFlag: t && e.type !== Fragment ? n === -1 ? 16 : n | 16 : n,
        dynamicProps: e.dynamicProps,
        dynamicChildren: e.dynamicChildren,
        appContext: e.appContext,
        dirs: e.dirs,
        transition: e.transition,
        component: e.component,
        suspense: e.suspense,
        ssContent: e.ssContent && cloneVNode(e.ssContent),
        ssFallback: e.ssFallback && cloneVNode(e.ssFallback),
        el: e.el,
        anchor: e.anchor,
        ctx: e.ctx,
        ce: e.ce
    }
}

function createTextVNode(e = " ", t = 0) {
    return createVNode(Text, null, e, t)
}

function createStaticVNode(e, t) {
    const r = createVNode(Static, null, e);
    return r.staticCount = t, r
}

function createCommentVNode(e = "", t = !1) {
    return t ? (openBlock(), createBlock(Comment, null, e)) : createVNode(Comment, null, e)
}

function normalizeVNode(e) {
    return e == null || typeof e == "boolean" ? createVNode(Comment) : isArray(e) ? createVNode(Fragment, null, e.slice()) : typeof e == "object" ? cloneIfMounted(e) : createVNode(Text, null, String(e))
}

function cloneIfMounted(e) {
    return e.el === null && e.patchFlag !== -1 || e.memo ? e : cloneVNode(e)
}

function normalizeChildren(e, t) {
    let r = 0;
    const {
        shapeFlag: i
    } = e;
    if (t == null) t = null;
    else if (isArray(t)) r = 16;
    else if (typeof t == "object")
        if (i & 65) {
            const s = t.default;
            s && (s._c && (s._d = !1), normalizeChildren(e, s()), s._c && (s._d = !0));
            return
        } else {
            r = 32;
            const s = t._;
            !s && !(InternalObjectKey in t) ? t._ctx = currentRenderingInstance : s === 3 && currentRenderingInstance && (currentRenderingInstance.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024))
        }
    else isFunction(t) ? (t = {
        default: t,
        _ctx: currentRenderingInstance
    }, r = 32) : (t = String(t), i & 64 ? (r = 16, t = [createTextVNode(t)]) : r = 8);
    e.children = t, e.shapeFlag |= r
}

function mergeProps(...e) {
    const t = {};
    for (let r = 0; r < e.length; r++) {
        const i = e[r];
        for (const s in i)
            if (s === "class") t.class !== i.class && (t.class = normalizeClass([t.class, i.class]));
            else if (s === "style") t.style = normalizeStyle([t.style, i.style]);
        else if (isOn(s)) {
            const n = t[s],
                a = i[s];
            a && n !== a && !(isArray(n) && n.includes(a)) && (t[s] = n ? [].concat(n, a) : a)
        } else s !== "" && (t[s] = i[s])
    }
    return t
}

function invokeVNodeHook(e, t, r, i = null) {
    callWithAsyncErrorHandling(e, t, 7, [r, i])
}
const emptyAppContext = createAppContext();
let uid = 0;

function createComponentInstance(e, t, r) {
    const i = e.type,
        s = (t ? t.appContext : e.appContext) || emptyAppContext,
        n = {
            uid: uid++,
            vnode: e,
            type: i,
            parent: t,
            appContext: s,
            root: null,
            next: null,
            subTree: null,
            effect: null,
            update: null,
            scope: new EffectScope(!0),
            render: null,
            proxy: null,
            exposed: null,
            exposeProxy: null,
            withProxy: null,
            provides: t ? t.provides : Object.create(s.provides),
            accessCache: null,
            renderCache: [],
            components: null,
            directives: null,
            propsOptions: normalizePropsOptions(i, s),
            emitsOptions: normalizeEmitsOptions(i, s),
            emit: null,
            emitted: null,
            propsDefaults: EMPTY_OBJ,
            inheritAttrs: i.inheritAttrs,
            ctx: EMPTY_OBJ,
            data: EMPTY_OBJ,
            props: EMPTY_OBJ,
            attrs: EMPTY_OBJ,
            slots: EMPTY_OBJ,
            refs: EMPTY_OBJ,
            setupState: EMPTY_OBJ,
            setupContext: null,
            attrsProxy: null,
            slotsProxy: null,
            suspense: r,
            suspenseId: r ? r.pendingId : 0,
            asyncDep: null,
            asyncResolved: !1,
            isMounted: !1,
            isUnmounted: !1,
            isDeactivated: !1,
            bc: null,
            c: null,
            bm: null,
            m: null,
            bu: null,
            u: null,
            um: null,
            bum: null,
            da: null,
            a: null,
            rtg: null,
            rtc: null,
            ec: null,
            sp: null
        };
    return n.ctx = {
        _: n
    }, n.root = t ? t.root : n, n.emit = emit.bind(null, n), e.ce && e.ce(n), n
}
let currentInstance = null,
    internalSetCurrentInstance, globalCurrentInstanceSetters, settersKey = "__VUE_INSTANCE_SETTERS__";
(globalCurrentInstanceSetters = getGlobalThis()[settersKey]) || (globalCurrentInstanceSetters = getGlobalThis()[settersKey] = []), globalCurrentInstanceSetters.push(e => currentInstance = e), internalSetCurrentInstance = e => {
    globalCurrentInstanceSetters.length > 1 ? globalCurrentInstanceSetters.forEach(t => t(e)) : globalCurrentInstanceSetters[0](e)
};
const setCurrentInstance = e => {
        internalSetCurrentInstance(e), e.scope.on()
    },
    unsetCurrentInstance = () => {
        currentInstance && currentInstance.scope.off(), internalSetCurrentInstance(null)
    };

function isStatefulComponent(e) {
    return e.vnode.shapeFlag & 4
}
let isInSSRComponentSetup = !1;

function setupComponent(e, t = !1) {
    isInSSRComponentSetup = t;
    const {
        props: r,
        children: i
    } = e.vnode, s = isStatefulComponent(e);
    initProps(e, r, s, t), initSlots(e, i);
    const n = s ? setupStatefulComponent(e, t) : void 0;
    return isInSSRComponentSetup = !1, n
}

function setupStatefulComponent(e, t) {
    const r = e.type;
    e.accessCache = Object.create(null), e.proxy = markRaw(new Proxy(e.ctx, PublicInstanceProxyHandlers));
    const {
        setup: i
    } = r;
    if (i) {
        const s = e.setupContext = i.length > 1 ? createSetupContext(e) : null;
        setCurrentInstance(e), pauseTracking();
        const n = callWithErrorHandling(i, e, 0, [e.props, s]);
        if (resetTracking(), unsetCurrentInstance(), isPromise(n)) {
            if (n.then(unsetCurrentInstance, unsetCurrentInstance), t) return n.then(a => {
                handleSetupResult(e, a, t)
            }).catch(a => {
                handleError(a, e, 0)
            });
            e.asyncDep = n
        } else handleSetupResult(e, n, t)
    } else finishComponentSetup(e, t)
}

function handleSetupResult(e, t, r) {
    isFunction(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : isObject(t) && (e.setupState = proxyRefs(t)), finishComponentSetup(e, r)
}
let compile;

function finishComponentSetup(e, t, r) {
    const i = e.type;
    if (!e.render) {
        if (!t && compile && !i.render) {
            const s = i.template || resolveMergedOptions(e).template;
            if (s) {
                const {
                    isCustomElement: n,
                    compilerOptions: a
                } = e.appContext.config, {
                    delimiters: l,
                    compilerOptions: c
                } = i, g = extend(extend({
                    isCustomElement: n,
                    delimiters: l
                }, a), c);
                i.render = compile(s, g)
            }
        }
        e.render = i.render || NOOP
    }
    setCurrentInstance(e), pauseTracking(), applyOptions(e), resetTracking(), unsetCurrentInstance()
}

function getAttrsProxy(e) {
    return e.attrsProxy || (e.attrsProxy = new Proxy(e.attrs, {
        get(t, r) {
            return track(e, "get", "$attrs"), t[r]
        }
    }))
}

function createSetupContext(e) {
    const t = r => {
        e.exposed = r || {}
    };
    return {
        get attrs() {
            return getAttrsProxy(e)
        },
        slots: e.slots,
        emit: e.emit,
        expose: t
    }
}

function getExposeProxy(e) {
    if (e.exposed) return e.exposeProxy || (e.exposeProxy = new Proxy(proxyRefs(markRaw(e.exposed)), {
        get(t, r) {
            if (r in t) return t[r];
            if (r in publicPropertiesMap) return publicPropertiesMap[r](e)
        },
        has(t, r) {
            return r in t || r in publicPropertiesMap
        }
    }))
}

function getComponentName(e, t = !0) {
    return isFunction(e) ? e.displayName || e.name : e.name || t && e.__name
}

function isClassComponent(e) {
    return isFunction(e) && "__vccOpts" in e
}
const computed = (e, t) => computed$1(e, t, isInSSRComponentSetup),
    ssrContextKey = Symbol.for("v-scx"),
    useSSRContext = () => inject(ssrContextKey),
    version = "3.3.4",
    svgNS = "http://www.w3.org/2000/svg",
    doc = typeof document < "u" ? document : null,
    templateContainer = doc && doc.createElement("template"),
    nodeOps = {
        insert: (e, t, r) => {
            t.insertBefore(e, r || null)
        },
        remove: e => {
            const t = e.parentNode;
            t && t.removeChild(e)
        },
        createElement: (e, t, r, i) => {
            const s = t ? doc.createElementNS(svgNS, e) : doc.createElement(e, r ? {
                is: r
            } : void 0);
            return e === "select" && i && i.multiple != null && s.setAttribute("multiple", i.multiple), s
        },
        createText: e => doc.createTextNode(e),
        createComment: e => doc.createComment(e),
        setText: (e, t) => {
            e.nodeValue = t
        },
        setElementText: (e, t) => {
            e.textContent = t
        },
        parentNode: e => e.parentNode,
        nextSibling: e => e.nextSibling,
        querySelector: e => doc.querySelector(e),
        setScopeId(e, t) {
            e.setAttribute(t, "")
        },
        insertStaticContent(e, t, r, i, s, n) {
            const a = r ? r.previousSibling : t.lastChild;
            if (s && (s === n || s.nextSibling))
                for (; t.insertBefore(s.cloneNode(!0), r), !(s === n || !(s = s.nextSibling)););
            else {
                templateContainer.innerHTML = i ? `<svg>${e}</svg>` : e;
                const l = templateContainer.content;
                if (i) {
                    const c = l.firstChild;
                    for (; c.firstChild;) l.appendChild(c.firstChild);
                    l.removeChild(c)
                }
                t.insertBefore(l, r)
            }
            return [a ? a.nextSibling : t.firstChild, r ? r.previousSibling : t.lastChild]
        }
    };

function patchClass(e, t, r) {
    const i = e._vtc;
    i && (t = (t ? [t, ...i] : [...i]).join(" ")), t == null ? e.removeAttribute("class") : r ? e.setAttribute("class", t) : e.className = t
}

function patchStyle(e, t, r) {
    const i = e.style,
        s = isString(r);
    if (r && !s) {
        if (t && !isString(t))
            for (const n in t) r[n] == null && setStyle(i, n, "");
        for (const n in r) setStyle(i, n, r[n])
    } else {
        const n = i.display;
        s ? t !== r && (i.cssText = r) : t && e.removeAttribute("style"), "_vod" in e && (i.display = n)
    }
}
const importantRE = /\s*!important$/;

function setStyle(e, t, r) {
    if (isArray(r)) r.forEach(i => setStyle(e, t, i));
    else if (r == null && (r = ""), t.startsWith("--")) e.setProperty(t, r);
    else {
        const i = autoPrefix(e, t);
        importantRE.test(r) ? e.setProperty(hyphenate(i), r.replace(importantRE, ""), "important") : e[i] = r
    }
}
const prefixes = ["Webkit", "Moz", "ms"],
    prefixCache = {};

function autoPrefix(e, t) {
    const r = prefixCache[t];
    if (r) return r;
    let i = camelize(t);
    if (i !== "filter" && i in e) return prefixCache[t] = i;
    i = capitalize(i);
    for (let s = 0; s < prefixes.length; s++) {
        const n = prefixes[s] + i;
        if (n in e) return prefixCache[t] = n
    }
    return t
}
const xlinkNS = "http://www.w3.org/1999/xlink";

function patchAttr(e, t, r, i, s) {
    if (i && t.startsWith("xlink:")) r == null ? e.removeAttributeNS(xlinkNS, t.slice(6, t.length)) : e.setAttributeNS(xlinkNS, t, r);
    else {
        const n = isSpecialBooleanAttr(t);
        r == null || n && !includeBooleanAttr(r) ? e.removeAttribute(t) : e.setAttribute(t, n ? "" : r)
    }
}

function patchDOMProp(e, t, r, i, s, n, a) {
    if (t === "innerHTML" || t === "textContent") {
        i && a(i, s, n), e[t] = r ?? "";
        return
    }
    const l = e.tagName;
    if (t === "value" && l !== "PROGRESS" && !l.includes("-")) {
        e._value = r;
        const g = l === "OPTION" ? e.getAttribute("value") : e.value,
            _ = r ?? "";
        g !== _ && (e.value = _), r == null && e.removeAttribute(t);
        return
    }
    let c = !1;
    if (r === "" || r == null) {
        const g = typeof e[t];
        g === "boolean" ? r = includeBooleanAttr(r) : r == null && g === "string" ? (r = "", c = !0) : g === "number" && (r = 0, c = !0)
    }
    try {
        e[t] = r
    } catch {}
    c && e.removeAttribute(t)
}

function addEventListener(e, t, r, i) {
    e.addEventListener(t, r, i)
}

function removeEventListener(e, t, r, i) {
    e.removeEventListener(t, r, i)
}

function patchEvent(e, t, r, i, s = null) {
    const n = e._vei || (e._vei = {}),
        a = n[t];
    if (i && a) a.value = i;
    else {
        const [l, c] = parseName(t);
        if (i) {
            const g = n[t] = createInvoker(i, s);
            addEventListener(e, l, g, c)
        } else a && (removeEventListener(e, l, a, c), n[t] = void 0)
    }
}
const optionsModifierRE = /(?:Once|Passive|Capture)$/;

function parseName(e) {
    let t;
    if (optionsModifierRE.test(e)) {
        t = {};
        let i;
        for (; i = e.match(optionsModifierRE);) e = e.slice(0, e.length - i[0].length), t[i[0].toLowerCase()] = !0
    }
    return [e[2] === ":" ? e.slice(3) : hyphenate(e.slice(2)), t]
}
let cachedNow = 0;
const p = Promise.resolve(),
    getNow = () => cachedNow || (p.then(() => cachedNow = 0), cachedNow = Date.now());

function createInvoker(e, t) {
    const r = i => {
        if (!i._vts) i._vts = Date.now();
        else if (i._vts <= r.attached) return;
        callWithAsyncErrorHandling(patchStopImmediatePropagation(i, r.value), t, 5, [i])
    };
    return r.value = e, r.attached = getNow(), r
}

function patchStopImmediatePropagation(e, t) {
    if (isArray(t)) {
        const r = e.stopImmediatePropagation;
        return e.stopImmediatePropagation = () => {
            r.call(e), e._stopped = !0
        }, t.map(i => s => !s._stopped && i && i(s))
    } else return t
}
const nativeOnRE = /^on[a-z]/,
    patchProp = (e, t, r, i, s = !1, n, a, l, c) => {
        t === "class" ? patchClass(e, i, s) : t === "style" ? patchStyle(e, r, i) : isOn(t) ? isModelListener(t) || patchEvent(e, t, r, i, a) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : shouldSetAsProp(e, t, i, s)) ? patchDOMProp(e, t, i, n, a, l, c) : (t === "true-value" ? e._trueValue = i : t === "false-value" && (e._falseValue = i), patchAttr(e, t, i, s))
    };

function shouldSetAsProp(e, t, r, i) {
    return i ? !!(t === "innerHTML" || t === "textContent" || t in e && nativeOnRE.test(t) && isFunction(r)) : t === "spellcheck" || t === "draggable" || t === "translate" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA" || nativeOnRE.test(t) && isString(r) ? !1 : t in e
}
const getModelAssigner = e => {
    const t = e.props["onUpdate:modelValue"] || !1;
    return isArray(t) ? r => invokeArrayFns(t, r) : t
};

function onCompositionStart(e) {
    e.target.composing = !0
}

function onCompositionEnd(e) {
    const t = e.target;
    t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")))
}
const vModelText = {
        created(e, {
            modifiers: {
                lazy: t,
                trim: r,
                number: i
            }
        }, s) {
            e._assign = getModelAssigner(s);
            const n = i || s.props && s.props.type === "number";
            addEventListener(e, t ? "change" : "input", a => {
                if (a.target.composing) return;
                let l = e.value;
                r && (l = l.trim()), n && (l = looseToNumber(l)), e._assign(l)
            }), r && addEventListener(e, "change", () => {
                e.value = e.value.trim()
            }), t || (addEventListener(e, "compositionstart", onCompositionStart), addEventListener(e, "compositionend", onCompositionEnd), addEventListener(e, "change", onCompositionEnd))
        },
        mounted(e, {
            value: t
        }) {
            e.value = t ?? ""
        },
        beforeUpdate(e, {
            value: t,
            modifiers: {
                lazy: r,
                trim: i,
                number: s
            }
        }, n) {
            if (e._assign = getModelAssigner(n), e.composing || document.activeElement === e && e.type !== "range" && (r || i && e.value.trim() === t || (s || e.type === "number") && looseToNumber(e.value) === t)) return;
            const a = t ?? "";
            e.value !== a && (e.value = a)
        }
    },
    keyNames = {
        esc: "escape",
        space: " ",
        up: "arrow-up",
        left: "arrow-left",
        right: "arrow-right",
        down: "arrow-down",
        delete: "backspace"
    },
    withKeys = (e, t) => r => {
        if (!("key" in r)) return;
        const i = hyphenate(r.key);
        if (t.some(s => s === i || keyNames[s] === i)) return e(r)
    },
    vShow = {
        beforeMount(e, {
            value: t
        }, {
            transition: r
        }) {
            e._vod = e.style.display === "none" ? "" : e.style.display, r && t ? r.beforeEnter(e) : setDisplay(e, t)
        },
        mounted(e, {
            value: t
        }, {
            transition: r
        }) {
            r && t && r.enter(e)
        },
        updated(e, {
            value: t,
            oldValue: r
        }, {
            transition: i
        }) {
            !t != !r && (i ? t ? (i.beforeEnter(e), setDisplay(e, !0), i.enter(e)) : i.leave(e, () => {
                setDisplay(e, !1)
            }) : setDisplay(e, t))
        },
        beforeUnmount(e, {
            value: t
        }) {
            setDisplay(e, t)
        }
    };

function setDisplay(e, t) {
    e.style.display = t ? e._vod : "none"
}
const rendererOptions = extend({
    patchProp
}, nodeOps);
let renderer;

function ensureRenderer() {
    return renderer || (renderer = createRenderer(rendererOptions))
}
const createApp = (...e) => {
    const t = ensureRenderer().createApp(...e),
        {
            mount: r
        } = t;
    return t.mount = i => {
        const s = normalizeContainer(i);
        if (!s) return;
        const n = t._component;
        !isFunction(n) && !n.render && !n.template && (n.template = s.innerHTML), s.innerHTML = "";
        const a = r(s, !1, s instanceof SVGElement);
        return s instanceof Element && (s.removeAttribute("v-cloak"), s.setAttribute("data-v-app", "")), a
    }, t
};

function normalizeContainer(e) {
    return isString(e) ? document.querySelector(e) : e
}
const _imports_0$4 = "/assets/img-home-go-premium-f6f3d2b2.png";
let flagCcCheck = !1;
const action = e => ({
        init() {
            log.info("[action init]"), this.getServerGroup(), this.watchStoreInit()
        },
        watchStoreMap() {
            return {
                [STORE_USERINFO]: function (t) {
                    log.info("[user update]", t), e.user = t
                },
                [STORE_CONNECTSTATUS]: function (t) {
                    log.info("[connect status update]", t), e.connect = t
                },
                [STORE_SERVERGROUP]: function (t) {
                    e.serverGroup = t
                },
                [STORE_SERVER]: function (t) {
                    e.server = t
                },
                [STORE_BYPASS]: function (t) {
                    e.bypass = t
                },
                [STORE_AUTOPROTECTION]: function (t) {
                    e.autoProtection = t
                },
                [STORE_STABLECONNECT]: function (t) {
                    e.stableConnect = t
                },
                [STORE_KILLSWITCH]: function (t) {
                    e.killSwitch = t
                },
                [STORE_WEBRTC]: function (t) {
                    e.webRtc = t
                },
                [STORE_SETTINGS]: function (t) {
                    e.settings = t
                },
                [STORE_ERROR]: function (t) {
                    e.error = t
                }
            }
        },
        async watchStoreInit() {
            const t = this.watchStoreMap(),
                r = Object.keys(t),
                [i, s] = await store.getList(r);
            i ? log.error("[init error]", i) : r.forEach(n => {
                const a = s[n];
                a && t[n](a)
            }), store.update(n => {
                log.info("[store update]", n), r.forEach(a => {
                    const l = n[a];
                    if (!l) return;
                    const {
                        newValue: c
                    } = l;
                    c && t[a](c)
                })
            })
        },
        toPage(t) {
            e.page = t, t === "home" && (flagCcCheck || this.getCcInfo(), this.updateUserFromRemote())
        },
        async isPrivacyShown() {
            const [t, r] = await store.get(STORE_PRIVACY);
            return !(t || !r || !r.status)
        },
        async agreePrivacy() {
            await store.set(STORE_PRIVACY, {
                status: !0
            }), this.toPage("goPremium")
        },
        disableOtherCrx() {
            this.toPage("home")
        },
        async connectAction() {
            const t = await getConnectServer();
            if (!t) {
                this.connectWithServerId("");
                return
            }
            const {
                Id: r
            } = t;
            this.connectWithServerId(r)
        },
        async connectWithServerId(t) {
            var c, g, _;
            if (!await isProxyCanControlled()) {
                this.toPage("dialogOtherProxy");
                return
            }
            const i = ((c = e.user) == null ? void 0 : c.Id) || "",
                s = ((g = e.user) == null ? void 0 : g.AuthSk) || "",
                n = (_ = e.user) == null ? void 0 : _.IsVip;
            //if (!n && t) {
            //    this.toPage("goPremium");
            //    return
            //}
            const [a, l] = await serverObj.getTargetServer(t, n);
            a.ChildList = null, await setConnectServer(a), this.toPage("home"), await sendMessage("Connect", {
                ipList: l,
                id: i,
                sk: s
            })
        },
        async disconnectAction() {
            await sendMessage("Disconnect")
        },
        getConnectInfo() {
            return store.get(STORE_CONNECT_INFO)
        },
        async updateServerGroup() {
            await sendMessage("UpdateServerGroup")
        },
        async getServerGroup() {
            e.serverGroup = await serverObj.getServerGroup()
        },
        async updateUserFromRemote() {
            var s, n, a;
            const t = (s = e.user) == null ? void 0 : s.Id,
                r = (n = e.user) == null ? void 0 : n.Sk,
                i = (a = e.user) == null ? void 0 : a.DeviceId;
            !t || !r || await sendMessage("UpdateUser", {
                Id: t,
                Sk: r,
                DeviceId: i
            })
        },
        getUser() {
            return getUser()
        },
        async getCcInfo() {
            var a, l;
            flagCcCheck = !0;
            const t = ((a = e.user) == null ? void 0 : a.Id) || "",
                r = ((l = e.user) == null ? void 0 : l.Sk) || "",
                [i, s] = await api.getCcInfo(t, r),
                n = safeParse(s);
            return !i && n.IsLimited ? (e.limitedLocation = !0, !1) : !0
        },
        showSignOutDialog() {
            showError(DIALOG_SIGNOUT)
        },
        async toSignOut() {
            e.user = {}, await setUser({}), await this.disconnectAction(), window.location.reload()
        },
        setBypass(t, r) {
            if (e.connect === CONNECT_CONNECTED) {
                showError(DIALOG_SPLITTUNNEL_CONNECTED);
                return
            }
            return store.set(STORE_BYPASS, {
                status: t,
                list: r
            })
        },
        async setAutProtection(t, r) {
            const [i, s] = await store.get(STORE_FLAG_AUTOPROTECT);
            if (t && (i || s !== "1")) {
                showError(DIALOG_AUTOPROTECT_WARNING);
                return
            }
            return store.set(STORE_AUTOPROTECTION, {
                status: t,
                list: r
            })
        },
        async onAutoProtection(t) {
            return store.set(STORE_AUTOPROTECTION, {
                status: !0,
                list: t
            })
        },
        updateAutoProtectionList(t) {
            return store.set(STORE_AUTOPROTECTION, {
                status: !0,
                list: t
            })
        },
        closeAutProtection() {
            return store.set(STORE_FLAG_AUTOPROTECT, "1")
        },
        setStableConnect(t) {
            return store.set(STORE_STABLECONNECT, {
                status: t
            })
        },
        setKillSwitch(t) {
            if (e.connect === CONNECT_CONNECTED) {
                showError(DIALOG_KILLSWITCH_CONNECTED);
                return
            }
            if (t) {
                showError(DIALOG_KILLSWITCH_SET);
                return
            }
            return store.set(STORE_KILLSWITCH, {
                status: !1
            })
        },
        setKillSwitchOn() {
            return store.set(STORE_KILLSWITCH, {
                status: !0
            })
        },
        setWebRtc(t) {
            return store.set(STORE_WEBRTC, {
                status: t
            })
        },
        toggleNotification() {
            const t = e.settings;
            return t.notification = !t.notification || !1, store.set(STORE_SETTINGS, t)
        },
        async toggleDarkMode() {
            const t = e.settings;
            t.darkMode = !t.darkMode || !1, await store.set(STORE_SETTINGS, t), this.toPage("home")
        },
        getToWebSiteParams() {
            var s, n, a;
            if (!((s = e.user) == null ? void 0 : s.Email)) return "?from=crx";
            const r = (n = e.user) == null ? void 0 : n.Id,
                i = (a = e.user) == null ? void 0 : a.Sk;
            return `?from=crx1&id=${encodeURIComponent(r)}&sk=${encodeURIComponent(i)}`
        },
        toWebSiteSignIn() {
            newUrlTab(`${APIHOST}/login?from=crx`)
        },
        toWebSiteAccount() {
            //var r;
            //if (!((r = e.user) == null ? void 0 : r.Email)) {
            //    this.toWebSiteSignIn();
            //    return
            //}
            //newUrlTab(`${APIHOST}/account${this.getToWebSiteParams()}`)
        },
        toAccountDevice() {
            newUrlTab(`${APIHOST}/account/device-settings`)
        },
        async toWebSitePricing() {
            await this.getCcInfo() && newUrlTab(`${APIHOST}/pricing${this.getToWebSiteParams()}`)
        },
        toWebsiteDnsLeakTest() {
            newUrlTab(`${APIHOST}/dns-leak-test`)
        },
        toWebsiteIpChecker() {
            newUrlTab(`${APIHOST}/ip-address-checker`)
        },
        toWebsitePasswordGenerator() {
            newUrlTab(`${APIHOST}/password-generator`)
        },
        toWebsiteWebRtcLeakTest() {
            newUrlTab(`${APIHOST}/webrtc-leak-test`)
        },
        toPrivacyPolicy() {
            newUrlTab(`${APIHOST}/policy`)
        },
        toTermsOfService() {
            newUrlTab(`${APIHOST}/terms-service`)
        },
        toHelpCenter() {
            newUrlTab(`${APIHOST}/help-center?a=open-livechat`)
        },
        toX() {
            newUrlTab("https://twitter.com/xvpnteam")
        },
        toFacebook() {
            newUrlTab("https://www.facebook.com/xvpnteam")
        },
        toInstagram() {
            newUrlTab("https://www.instagram.com/xvpn_team")
        },
        toRateUs() {
            newUrlTab(`https://chromewebstore.google.com/detail/${chrome.runtime.id}`)
        }
    }),
    stateObj = {
        connect: CONNECT_DISCONNECTED,
        page: "home",
        user: {},
        server: {},
        serverGroup: {},
        bypass: {},
        autoProtection: {},
        stableConnect: {},
        killSwitch: {},
        webRtc: {},
        settings: {},
        error: {},
        limitedLocation: !1
    },
    storeSymbol = Symbol("state"),
    createStore = () => {
        const e = reactive(stateObj),
            t = action(e);
        return t.init(), {
            state: readonly(e),
            ...t
        }
    },
    useStore = () => inject(storeSymbol);

function getDefaultExportFromCjs(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var lottie = {
    exports: {}
};
(function (module) {
    typeof navigator < "u" && function (e, t) {
        module.exports ? module.exports = t(e) : (e.lottie = t(e), e.bodymovin = e.lottie)
    }(window || {}, function (window) {
        var svgNS = "http://www.w3.org/2000/svg",
            locationHref = "",
            initialDefaultFrame = -999999,
            subframeEnabled = !0,
            idPrefix = "",
            expressionsPlugin, isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent),
            bmPow = Math.pow,
            bmSqrt = Math.sqrt,
            bmFloor = Math.floor,
            bmMax = Math.max,
            bmMin = Math.min,
            BMMath = {};
        (function () {
            var e = ["abs", "acos", "acosh", "asin", "asinh", "atan", "atanh", "atan2", "ceil", "cbrt", "expm1", "clz32", "cos", "cosh", "exp", "floor", "fround", "hypot", "imul", "log", "log1p", "log2", "log10", "max", "min", "pow", "random", "round", "sign", "sin", "sinh", "sqrt", "tan", "tanh", "trunc", "E", "LN10", "LN2", "LOG10E", "LOG2E", "PI", "SQRT1_2", "SQRT2"],
                t, r = e.length;
            for (t = 0; t < r; t += 1) BMMath[e[t]] = Math[e[t]]
        })();

        function ProjectInterface() {
            return {}
        }
        BMMath.random = Math.random, BMMath.abs = function (e) {
            var t = typeof e;
            if (t === "object" && e.length) {
                var r = createSizedArray(e.length),
                    i, s = e.length;
                for (i = 0; i < s; i += 1) r[i] = Math.abs(e[i]);
                return r
            }
            return Math.abs(e)
        };
        var defaultCurveSegments = 150,
            degToRads = Math.PI / 180,
            roundCorner = .5519;

        function styleDiv(e) {
            e.style.position = "absolute", e.style.top = 0, e.style.left = 0, e.style.display = "block", e.style.transformOrigin = "0 0", e.style.webkitTransformOrigin = "0 0", e.style.backfaceVisibility = "visible", e.style.webkitBackfaceVisibility = "visible", e.style.transformStyle = "preserve-3d", e.style.webkitTransformStyle = "preserve-3d", e.style.mozTransformStyle = "preserve-3d"
        }

        function BMEnterFrameEvent(e, t, r, i) {
            this.type = e, this.currentTime = t, this.totalTime = r, this.direction = i < 0 ? -1 : 1
        }

        function BMCompleteEvent(e, t) {
            this.type = e, this.direction = t < 0 ? -1 : 1
        }

        function BMCompleteLoopEvent(e, t, r, i) {
            this.type = e, this.currentLoop = r, this.totalLoops = t, this.direction = i < 0 ? -1 : 1
        }

        function BMSegmentStartEvent(e, t, r) {
            this.type = e, this.firstFrame = t, this.totalFrames = r
        }

        function BMDestroyEvent(e, t) {
            this.type = e, this.target = t
        }

        function BMRenderFrameErrorEvent(e, t) {
            this.type = "renderFrameError", this.nativeError = e, this.currentTime = t
        }

        function BMConfigErrorEvent(e) {
            this.type = "configError", this.nativeError = e
        }
        var createElementID = function () {
            var e = 0;
            return function () {
                return e += 1, idPrefix + "__lottie_element_" + e
            }
        }();

        function HSVtoRGB(e, t, r) {
            var i, s, n, a, l, c, g, _;
            switch (a = Math.floor(e * 6), l = e * 6 - a, c = r * (1 - t), g = r * (1 - l * t), _ = r * (1 - (1 - l) * t), a % 6) {
                case 0:
                    i = r, s = _, n = c;
                    break;
                case 1:
                    i = g, s = r, n = c;
                    break;
                case 2:
                    i = c, s = r, n = _;
                    break;
                case 3:
                    i = c, s = g, n = r;
                    break;
                case 4:
                    i = _, s = c, n = r;
                    break;
                case 5:
                    i = r, s = c, n = g;
                    break
            }
            return [i, s, n]
        }

        function RGBtoHSV(e, t, r) {
            var i = Math.max(e, t, r),
                s = Math.min(e, t, r),
                n = i - s,
                a, l = i === 0 ? 0 : n / i,
                c = i / 255;
            switch (i) {
                case s:
                    a = 0;
                    break;
                case e:
                    a = t - r + n * (t < r ? 6 : 0), a /= 6 * n;
                    break;
                case t:
                    a = r - e + n * 2, a /= 6 * n;
                    break;
                case r:
                    a = e - t + n * 4, a /= 6 * n;
                    break
            }
            return [a, l, c]
        }

        function addSaturationToRGB(e, t) {
            var r = RGBtoHSV(e[0] * 255, e[1] * 255, e[2] * 255);
            return r[1] += t, r[1] > 1 ? r[1] = 1 : r[1] <= 0 && (r[1] = 0), HSVtoRGB(r[0], r[1], r[2])
        }

        function addBrightnessToRGB(e, t) {
            var r = RGBtoHSV(e[0] * 255, e[1] * 255, e[2] * 255);
            return r[2] += t, r[2] > 1 ? r[2] = 1 : r[2] < 0 && (r[2] = 0), HSVtoRGB(r[0], r[1], r[2])
        }

        function addHueToRGB(e, t) {
            var r = RGBtoHSV(e[0] * 255, e[1] * 255, e[2] * 255);
            return r[0] += t / 360, r[0] > 1 ? r[0] -= 1 : r[0] < 0 && (r[0] += 1), HSVtoRGB(r[0], r[1], r[2])
        }
        var rgbToHex = function () {
            var e = [],
                t, r;
            for (t = 0; t < 256; t += 1) r = t.toString(16), e[t] = r.length === 1 ? "0" + r : r;
            return function (i, s, n) {
                return i < 0 && (i = 0), s < 0 && (s = 0), n < 0 && (n = 0), "#" + e[i] + e[s] + e[n]
            }
        }();

        function BaseEvent() {}
        BaseEvent.prototype = {
            triggerEvent: function (e, t) {
                if (this._cbs[e])
                    for (var r = this._cbs[e], i = 0; i < r.length; i += 1) r[i](t)
            },
            addEventListener: function (e, t) {
                return this._cbs[e] || (this._cbs[e] = []), this._cbs[e].push(t), (function () {
                    this.removeEventListener(e, t)
                }).bind(this)
            },
            removeEventListener: function (e, t) {
                if (!t) this._cbs[e] = null;
                else if (this._cbs[e]) {
                    for (var r = 0, i = this._cbs[e].length; r < i;) this._cbs[e][r] === t && (this._cbs[e].splice(r, 1), r -= 1, i -= 1), r += 1;
                    this._cbs[e].length || (this._cbs[e] = null)
                }
            }
        };
        var createTypedArray = function () {
            function e(r, i) {
                var s = 0,
                    n = [],
                    a;
                switch (r) {
                    case "int16":
                    case "uint8c":
                        a = 1;
                        break;
                    default:
                        a = 1.1;
                        break
                }
                for (s = 0; s < i; s += 1) n.push(a);
                return n
            }

            function t(r, i) {
                return r === "float32" ? new Float32Array(i) : r === "int16" ? new Int16Array(i) : r === "uint8c" ? new Uint8ClampedArray(i) : e(r, i)
            }
            return typeof Uint8ClampedArray == "function" && typeof Float32Array == "function" ? t : e
        }();

        function createSizedArray(e) {
            return Array.apply(null, {
                length: e
            })
        }

        function createNS(e) {
            return document.createElementNS(svgNS, e)
        }

        function createTag(e) {
            return document.createElement(e)
        }

        function DynamicPropertyContainer() {}
        DynamicPropertyContainer.prototype = {
            addDynamicProperty: function (e) {
                this.dynamicProperties.indexOf(e) === -1 && (this.dynamicProperties.push(e), this.container.addDynamicProperty(this), this._isAnimated = !0)
            },
            iterateDynamicProperties: function () {
                this._mdf = !1;
                var e, t = this.dynamicProperties.length;
                for (e = 0; e < t; e += 1) this.dynamicProperties[e].getValue(), this.dynamicProperties[e]._mdf && (this._mdf = !0)
            },
            initDynamicPropertyContainer: function (e) {
                this.container = e, this.dynamicProperties = [], this._mdf = !1, this._isAnimated = !1
            }
        };
        var getBlendMode = function () {
                var e = {
                    0: "source-over",
                    1: "multiply",
                    2: "screen",
                    3: "overlay",
                    4: "darken",
                    5: "lighten",
                    6: "color-dodge",
                    7: "color-burn",
                    8: "hard-light",
                    9: "soft-light",
                    10: "difference",
                    11: "exclusion",
                    12: "hue",
                    13: "saturation",
                    14: "color",
                    15: "luminosity"
                };
                return function (t) {
                    return e[t] || ""
                }
            }(),
            lineCapEnum = {
                1: "butt",
                2: "round",
                3: "square"
            },
            lineJoinEnum = {
                1: "miter",
                2: "round",
                3: "bevel"
            };
        /*!
         Transformation Matrix v2.0
         (c) Epistemex 2014-2015
         www.epistemex.com
         By Ken Fyrstenberg
         Contributions by leeoniya.
         License: MIT, header required.
         */
        var Matrix = function () {
            var e = Math.cos,
                t = Math.sin,
                r = Math.tan,
                i = Math.round;

            function s() {
                return this.props[0] = 1, this.props[1] = 0, this.props[2] = 0, this.props[3] = 0, this.props[4] = 0, this.props[5] = 1, this.props[6] = 0, this.props[7] = 0, this.props[8] = 0, this.props[9] = 0, this.props[10] = 1, this.props[11] = 0, this.props[12] = 0, this.props[13] = 0, this.props[14] = 0, this.props[15] = 1, this
            }

            function n(I) {
                if (I === 0) return this;
                var A = e(I),
                    R = t(I);
                return this._t(A, -R, 0, 0, R, A, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
            }

            function a(I) {
                if (I === 0) return this;
                var A = e(I),
                    R = t(I);
                return this._t(1, 0, 0, 0, 0, A, -R, 0, 0, R, A, 0, 0, 0, 0, 1)
            }

            function l(I) {
                if (I === 0) return this;
                var A = e(I),
                    R = t(I);
                return this._t(A, 0, R, 0, 0, 1, 0, 0, -R, 0, A, 0, 0, 0, 0, 1)
            }

            function c(I) {
                if (I === 0) return this;
                var A = e(I),
                    R = t(I);
                return this._t(A, -R, 0, 0, R, A, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
            }

            function g(I, A) {
                return this._t(1, A, I, 1, 0, 0)
            }

            function _(I, A) {
                return this.shear(r(I), r(A))
            }

            function E(I, A) {
                var R = e(A),
                    X = t(A);
                return this._t(R, X, 0, 0, -X, R, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(1, 0, 0, 0, r(I), 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(R, -X, 0, 0, X, R, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
            }

            function P(I, A, R) {
                return !R && R !== 0 && (R = 1), I === 1 && A === 1 && R === 1 ? this : this._t(I, 0, 0, 0, 0, A, 0, 0, 0, 0, R, 0, 0, 0, 0, 1)
            }

            function x(I, A, R, X, O, ie, se, oe, fe, le, pe, me, de, ue, ce, M) {
                return this.props[0] = I, this.props[1] = A, this.props[2] = R, this.props[3] = X, this.props[4] = O, this.props[5] = ie, this.props[6] = se, this.props[7] = oe, this.props[8] = fe, this.props[9] = le, this.props[10] = pe, this.props[11] = me, this.props[12] = de, this.props[13] = ue, this.props[14] = ce, this.props[15] = M, this
            }

            function y(I, A, R) {
                return R = R || 0, I !== 0 || A !== 0 || R !== 0 ? this._t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, I, A, R, 1) : this
            }

            function d(I, A, R, X, O, ie, se, oe, fe, le, pe, me, de, ue, ce, M) {
                var F = this.props;
                if (I === 1 && A === 0 && R === 0 && X === 0 && O === 0 && ie === 1 && se === 0 && oe === 0 && fe === 0 && le === 0 && pe === 1 && me === 0) return F[12] = F[12] * I + F[15] * de, F[13] = F[13] * ie + F[15] * ue, F[14] = F[14] * pe + F[15] * ce, F[15] *= M, this._identityCalculated = !1, this;
                var N = F[0],
                    z = F[1],
                    G = F[2],
                    W = F[3],
                    K = F[4],
                    j = F[5],
                    q = F[6],
                    $ = F[7],
                    ee = F[8],
                    J = F[9],
                    Q = F[10],
                    te = F[11],
                    re = F[12],
                    ne = F[13],
                    ae = F[14],
                    he = F[15];
                return F[0] = N * I + z * O + G * fe + W * de, F[1] = N * A + z * ie + G * le + W * ue, F[2] = N * R + z * se + G * pe + W * ce, F[3] = N * X + z * oe + G * me + W * M, F[4] = K * I + j * O + q * fe + $ * de, F[5] = K * A + j * ie + q * le + $ * ue, F[6] = K * R + j * se + q * pe + $ * ce, F[7] = K * X + j * oe + q * me + $ * M, F[8] = ee * I + J * O + Q * fe + te * de, F[9] = ee * A + J * ie + Q * le + te * ue, F[10] = ee * R + J * se + Q * pe + te * ce, F[11] = ee * X + J * oe + Q * me + te * M, F[12] = re * I + ne * O + ae * fe + he * de, F[13] = re * A + ne * ie + ae * le + he * ue, F[14] = re * R + ne * se + ae * pe + he * ce, F[15] = re * X + ne * oe + ae * me + he * M, this._identityCalculated = !1, this
            }

            function b() {
                return this._identityCalculated || (this._identity = !(this.props[0] !== 1 || this.props[1] !== 0 || this.props[2] !== 0 || this.props[3] !== 0 || this.props[4] !== 0 || this.props[5] !== 1 || this.props[6] !== 0 || this.props[7] !== 0 || this.props[8] !== 0 || this.props[9] !== 0 || this.props[10] !== 1 || this.props[11] !== 0 || this.props[12] !== 0 || this.props[13] !== 0 || this.props[14] !== 0 || this.props[15] !== 1), this._identityCalculated = !0), this._identity
            }

            function m(I) {
                for (var A = 0; A < 16;) {
                    if (I.props[A] !== this.props[A]) return !1;
                    A += 1
                }
                return !0
            }

            function o(I) {
                var A;
                for (A = 0; A < 16; A += 1) I.props[A] = this.props[A];
                return I
            }

            function f(I) {
                var A;
                for (A = 0; A < 16; A += 1) this.props[A] = I[A]
            }

            function u(I, A, R) {
                return {
                    x: I * this.props[0] + A * this.props[4] + R * this.props[8] + this.props[12],
                    y: I * this.props[1] + A * this.props[5] + R * this.props[9] + this.props[13],
                    z: I * this.props[2] + A * this.props[6] + R * this.props[10] + this.props[14]
                }
            }

            function S(I, A, R) {
                return I * this.props[0] + A * this.props[4] + R * this.props[8] + this.props[12]
            }

            function k(I, A, R) {
                return I * this.props[1] + A * this.props[5] + R * this.props[9] + this.props[13]
            }

            function C(I, A, R) {
                return I * this.props[2] + A * this.props[6] + R * this.props[10] + this.props[14]
            }

            function T() {
                var I = this.props[0] * this.props[5] - this.props[1] * this.props[4],
                    A = this.props[5] / I,
                    R = -this.props[1] / I,
                    X = -this.props[4] / I,
                    O = this.props[0] / I,
                    ie = (this.props[4] * this.props[13] - this.props[5] * this.props[12]) / I,
                    se = -(this.props[0] * this.props[13] - this.props[1] * this.props[12]) / I,
                    oe = new Matrix;
                return oe.props[0] = A, oe.props[1] = R, oe.props[4] = X, oe.props[5] = O, oe.props[12] = ie, oe.props[13] = se, oe
            }

            function B(I) {
                var A = this.getInverseMatrix();
                return A.applyToPointArray(I[0], I[1], I[2] || 0)
            }

            function D(I) {
                var A, R = I.length,
                    X = [];
                for (A = 0; A < R; A += 1) X[A] = B(I[A]);
                return X
            }

            function H(I, A, R) {
                var X = createTypedArray("float32", 6);
                if (this.isIdentity()) X[0] = I[0], X[1] = I[1], X[2] = A[0], X[3] = A[1], X[4] = R[0], X[5] = R[1];
                else {
                    var O = this.props[0],
                        ie = this.props[1],
                        se = this.props[4],
                        oe = this.props[5],
                        fe = this.props[12],
                        le = this.props[13];
                    X[0] = I[0] * O + I[1] * se + fe, X[1] = I[0] * ie + I[1] * oe + le, X[2] = A[0] * O + A[1] * se + fe, X[3] = A[0] * ie + A[1] * oe + le, X[4] = R[0] * O + R[1] * se + fe, X[5] = R[0] * ie + R[1] * oe + le
                }
                return X
            }

            function L(I, A, R) {
                var X;
                return this.isIdentity() ? X = [I, A, R] : X = [I * this.props[0] + A * this.props[4] + R * this.props[8] + this.props[12], I * this.props[1] + A * this.props[5] + R * this.props[9] + this.props[13], I * this.props[2] + A * this.props[6] + R * this.props[10] + this.props[14]], X
            }

            function U(I, A) {
                if (this.isIdentity()) return I + "," + A;
                var R = this.props;
                return Math.round((I * R[0] + A * R[4] + R[12]) * 100) / 100 + "," + Math.round((I * R[1] + A * R[5] + R[13]) * 100) / 100
            }

            function Y() {
                for (var I = 0, A = this.props, R = "matrix3d(", X = 1e4; I < 16;) R += i(A[I] * X) / X, R += I === 15 ? ")" : ",", I += 1;
                return R
            }

            function Z(I) {
                var A = 1e4;
                return I < 1e-6 && I > 0 || I > -1e-6 && I < 0 ? i(I * A) / A : I
            }

            function V() {
                var I = this.props,
                    A = Z(I[0]),
                    R = Z(I[1]),
                    X = Z(I[4]),
                    O = Z(I[5]),
                    ie = Z(I[12]),
                    se = Z(I[13]);
                return "matrix(" + A + "," + R + "," + X + "," + O + "," + ie + "," + se + ")"
            }
            return function () {
                this.reset = s, this.rotate = n, this.rotateX = a, this.rotateY = l, this.rotateZ = c, this.skew = _, this.skewFromAxis = E, this.shear = g, this.scale = P, this.setTransform = x, this.translate = y, this.transform = d, this.applyToPoint = u, this.applyToX = S, this.applyToY = k, this.applyToZ = C, this.applyToPointArray = L, this.applyToTriplePoints = H, this.applyToPointStringified = U, this.toCSS = Y, this.to2dCSS = V, this.clone = o, this.cloneFromProps = f, this.equals = m, this.inversePoints = D, this.inversePoint = B, this.getInverseMatrix = T, this._t = this.transform, this.isIdentity = b, this._identity = !0, this._identityCalculated = !1, this.props = createTypedArray("float32", 16), this.reset()
            }
        }();
        (function (e, t) {
            var r = this,
                i = 256,
                s = 6,
                n = 52,
                a = "random",
                l = t.pow(i, s),
                c = t.pow(2, n),
                g = c * 2,
                _ = i - 1,
                E;

            function P(f, u, S) {
                var k = [];
                u = u === !0 ? {
                    entropy: !0
                } : u || {};
                var C = b(d(u.entropy ? [f, o(e)] : f === null ? m() : f, 3), k),
                    T = new x(k),
                    B = function () {
                        for (var D = T.g(s), H = l, L = 0; D < c;) D = (D + L) * i, H *= i, L = T.g(1);
                        for (; D >= g;) D /= 2, H /= 2, L >>>= 1;
                        return (D + L) / H
                    };
                return B.int32 = function () {
                    return T.g(4) | 0
                }, B.quick = function () {
                    return T.g(4) / 4294967296
                }, B.double = B, b(o(T.S), e), (u.pass || S || function (D, H, L, U) {
                    return U && (U.S && y(U, T), D.state = function () {
                        return y(T, {})
                    }), L ? (t[a] = D, H) : D
                })(B, C, "global" in u ? u.global : this == t, u.state)
            }
            t["seed" + a] = P;

            function x(f) {
                var u, S = f.length,
                    k = this,
                    C = 0,
                    T = k.i = k.j = 0,
                    B = k.S = [];
                for (S || (f = [S++]); C < i;) B[C] = C++;
                for (C = 0; C < i; C++) B[C] = B[T = _ & T + f[C % S] + (u = B[C])], B[T] = u;
                k.g = function (D) {
                    for (var H, L = 0, U = k.i, Y = k.j, Z = k.S; D--;) H = Z[U = _ & U + 1], L = L * i + Z[_ & (Z[U] = Z[Y = _ & Y + H]) + (Z[Y] = H)];
                    return k.i = U, k.j = Y, L
                }
            }

            function y(f, u) {
                return u.i = f.i, u.j = f.j, u.S = f.S.slice(), u
            }

            function d(f, u) {
                var S = [],
                    k = typeof f,
                    C;
                if (u && k == "object")
                    for (C in f) try {
                        S.push(d(f[C], u - 1))
                    } catch {}
                return S.length ? S : k == "string" ? f : f + "\0"
            }

            function b(f, u) {
                for (var S = f + "", k, C = 0; C < S.length;) u[_ & C] = _ & (k ^= u[_ & C] * 19) + S.charCodeAt(C++);
                return o(u)
            }

            function m() {
                try {
                    var f = new Uint8Array(i);
                    return (r.crypto || r.msCrypto).getRandomValues(f), o(f)
                } catch {
                    var u = r.navigator,
                        S = u && u.plugins;
                    return [+new Date, r, S, r.screen, o(e)]
                }
            }

            function o(f) {
                return String.fromCharCode.apply(0, f)
            }
            b(t.random(), e)
        })([], BMMath);
        var BezierFactory = function () {
            var e = {};
            e.getBezierEasing = r;
            var t = {};

            function r(o, f, u, S, k) {
                var C = k || ("bez_" + o + "_" + f + "_" + u + "_" + S).replace(/\./g, "p");
                if (t[C]) return t[C];
                var T = new m([o, f, u, S]);
                return t[C] = T, T
            }
            var i = 4,
                s = .001,
                n = 1e-7,
                a = 10,
                l = 11,
                c = 1 / (l - 1),
                g = typeof Float32Array == "function";

            function _(o, f) {
                return 1 - 3 * f + 3 * o
            }

            function E(o, f) {
                return 3 * f - 6 * o
            }

            function P(o) {
                return 3 * o
            }

            function x(o, f, u) {
                return ((_(f, u) * o + E(f, u)) * o + P(f)) * o
            }

            function y(o, f, u) {
                return 3 * _(f, u) * o * o + 2 * E(f, u) * o + P(f)
            }

            function d(o, f, u, S, k) {
                var C, T, B = 0;
                do T = f + (u - f) / 2, C = x(T, S, k) - o, C > 0 ? u = T : f = T; while (Math.abs(C) > n && ++B < a);
                return T
            }

            function b(o, f, u, S) {
                for (var k = 0; k < i; ++k) {
                    var C = y(f, u, S);
                    if (C === 0) return f;
                    var T = x(f, u, S) - o;
                    f -= T / C
                }
                return f
            }

            function m(o) {
                this._p = o, this._mSampleValues = g ? new Float32Array(l) : new Array(l), this._precomputed = !1, this.get = this.get.bind(this)
            }
            return m.prototype = {
                get: function (o) {
                    var f = this._p[0],
                        u = this._p[1],
                        S = this._p[2],
                        k = this._p[3];
                    return this._precomputed || this._precompute(), f === u && S === k ? o : o === 0 ? 0 : o === 1 ? 1 : x(this._getTForX(o), u, k)
                },
                _precompute: function () {
                    var o = this._p[0],
                        f = this._p[1],
                        u = this._p[2],
                        S = this._p[3];
                    this._precomputed = !0, (o !== f || u !== S) && this._calcSampleValues()
                },
                _calcSampleValues: function () {
                    for (var o = this._p[0], f = this._p[2], u = 0; u < l; ++u) this._mSampleValues[u] = x(u * c, o, f)
                },
                _getTForX: function (o) {
                    for (var f = this._p[0], u = this._p[2], S = this._mSampleValues, k = 0, C = 1, T = l - 1; C !== T && S[C] <= o; ++C) k += c;
                    --C;
                    var B = (o - S[C]) / (S[C + 1] - S[C]),
                        D = k + B * c,
                        H = y(D, f, u);
                    return H >= s ? b(o, D, f, u) : H === 0 ? D : d(o, k, k + c, f, u)
                }
            }, e
        }();
        (function () {
            for (var e = 0, t = ["ms", "moz", "webkit", "o"], r = 0; r < t.length && !window.requestAnimationFrame; ++r) window.requestAnimationFrame = window[t[r] + "RequestAnimationFrame"], window.cancelAnimationFrame = window[t[r] + "CancelAnimationFrame"] || window[t[r] + "CancelRequestAnimationFrame"];
            window.requestAnimationFrame || (window.requestAnimationFrame = function (i) {
                var s = new Date().getTime(),
                    n = Math.max(0, 16 - (s - e)),
                    a = setTimeout(function () {
                        i(s + n)
                    }, n);
                return e = s + n, a
            }), window.cancelAnimationFrame || (window.cancelAnimationFrame = function (i) {
                clearTimeout(i)
            })
        })();

        function extendPrototype(e, t) {
            var r, i = e.length,
                s;
            for (r = 0; r < i; r += 1) {
                s = e[r].prototype;
                for (var n in s) Object.prototype.hasOwnProperty.call(s, n) && (t.prototype[n] = s[n])
            }
        }

        function getDescriptor(e, t) {
            return Object.getOwnPropertyDescriptor(e, t)
        }

        function createProxyFunction(e) {
            function t() {}
            return t.prototype = e, t
        }

        function bezFunction() {
            var e = Math;

            function t(P, x, y, d, b, m) {
                var o = P * d + x * b + y * m - b * d - m * P - y * x;
                return o > -.001 && o < .001
            }

            function r(P, x, y, d, b, m, o, f, u) {
                if (y === 0 && m === 0 && u === 0) return t(P, x, d, b, o, f);
                var S = e.sqrt(e.pow(d - P, 2) + e.pow(b - x, 2) + e.pow(m - y, 2)),
                    k = e.sqrt(e.pow(o - P, 2) + e.pow(f - x, 2) + e.pow(u - y, 2)),
                    C = e.sqrt(e.pow(o - d, 2) + e.pow(f - b, 2) + e.pow(u - m, 2)),
                    T;
                return S > k ? S > C ? T = S - k - C : T = C - k - S : C > k ? T = C - k - S : T = k - S - C, T > -1e-4 && T < 1e-4
            }
            var i = function () {
                return function (P, x, y, d) {
                    var b = defaultCurveSegments,
                        m, o, f, u, S, k = 0,
                        C, T = [],
                        B = [],
                        D = bezierLengthPool.newElement();
                    for (f = y.length, m = 0; m < b; m += 1) {
                        for (S = m / (b - 1), C = 0, o = 0; o < f; o += 1) u = bmPow(1 - S, 3) * P[o] + 3 * bmPow(1 - S, 2) * S * y[o] + 3 * (1 - S) * bmPow(S, 2) * d[o] + bmPow(S, 3) * x[o], T[o] = u, B[o] !== null && (C += bmPow(T[o] - B[o], 2)), B[o] = T[o];
                        C && (C = bmSqrt(C), k += C), D.percents[m] = S, D.lengths[m] = k
                    }
                    return D.addedLength = k, D
                }
            }();

            function s(P) {
                var x = segmentsLengthPool.newElement(),
                    y = P.c,
                    d = P.v,
                    b = P.o,
                    m = P.i,
                    o, f = P._length,
                    u = x.lengths,
                    S = 0;
                for (o = 0; o < f - 1; o += 1) u[o] = i(d[o], d[o + 1], b[o], m[o + 1]), S += u[o].addedLength;
                return y && f && (u[o] = i(d[o], d[0], b[o], m[0]), S += u[o].addedLength), x.totalLength = S, x
            }

            function n(P) {
                this.segmentLength = 0, this.points = new Array(P)
            }

            function a(P, x) {
                this.partialLength = P, this.point = x
            }
            var l = function () {
                var P = {};
                return function (x, y, d, b) {
                    var m = (x[0] + "_" + x[1] + "_" + y[0] + "_" + y[1] + "_" + d[0] + "_" + d[1] + "_" + b[0] + "_" + b[1]).replace(/\./g, "p");
                    if (!P[m]) {
                        var o = defaultCurveSegments,
                            f, u, S, k, C, T = 0,
                            B, D, H = null;
                        x.length === 2 && (x[0] !== y[0] || x[1] !== y[1]) && t(x[0], x[1], y[0], y[1], x[0] + d[0], x[1] + d[1]) && t(x[0], x[1], y[0], y[1], y[0] + b[0], y[1] + b[1]) && (o = 2);
                        var L = new n(o);
                        for (S = d.length, f = 0; f < o; f += 1) {
                            for (D = createSizedArray(S), C = f / (o - 1), B = 0, u = 0; u < S; u += 1) k = bmPow(1 - C, 3) * x[u] + 3 * bmPow(1 - C, 2) * C * (x[u] + d[u]) + 3 * (1 - C) * bmPow(C, 2) * (y[u] + b[u]) + bmPow(C, 3) * y[u], D[u] = k, H !== null && (B += bmPow(D[u] - H[u], 2));
                            B = bmSqrt(B), T += B, L.points[f] = new a(B, D), H = D
                        }
                        L.segmentLength = T, P[m] = L
                    }
                    return P[m]
                }
            }();

            function c(P, x) {
                var y = x.percents,
                    d = x.lengths,
                    b = y.length,
                    m = bmFloor((b - 1) * P),
                    o = P * x.addedLength,
                    f = 0;
                if (m === b - 1 || m === 0 || o === d[m]) return y[m];
                for (var u = d[m] > o ? -1 : 1, S = !0; S;)
                    if (d[m] <= o && d[m + 1] > o ? (f = (o - d[m]) / (d[m + 1] - d[m]), S = !1) : m += u, m < 0 || m >= b - 1) {
                        if (m === b - 1) return y[m];
                        S = !1
                    } return y[m] + (y[m + 1] - y[m]) * f
            }

            function g(P, x, y, d, b, m) {
                var o = c(b, m),
                    f = 1 - o,
                    u = e.round((f * f * f * P[0] + (o * f * f + f * o * f + f * f * o) * y[0] + (o * o * f + f * o * o + o * f * o) * d[0] + o * o * o * x[0]) * 1e3) / 1e3,
                    S = e.round((f * f * f * P[1] + (o * f * f + f * o * f + f * f * o) * y[1] + (o * o * f + f * o * o + o * f * o) * d[1] + o * o * o * x[1]) * 1e3) / 1e3;
                return [u, S]
            }
            var _ = createTypedArray("float32", 8);

            function E(P, x, y, d, b, m, o) {
                b < 0 ? b = 0 : b > 1 && (b = 1);
                var f = c(b, o);
                m = m > 1 ? 1 : m;
                var u = c(m, o),
                    S, k = P.length,
                    C = 1 - f,
                    T = 1 - u,
                    B = C * C * C,
                    D = f * C * C * 3,
                    H = f * f * C * 3,
                    L = f * f * f,
                    U = C * C * T,
                    Y = f * C * T + C * f * T + C * C * u,
                    Z = f * f * T + C * f * u + f * C * u,
                    V = f * f * u,
                    I = C * T * T,
                    A = f * T * T + C * u * T + C * T * u,
                    R = f * u * T + C * u * u + f * T * u,
                    X = f * u * u,
                    O = T * T * T,
                    ie = u * T * T + T * u * T + T * T * u,
                    se = u * u * T + T * u * u + u * T * u,
                    oe = u * u * u;
                for (S = 0; S < k; S += 1) _[S * 4] = e.round((B * P[S] + D * y[S] + H * d[S] + L * x[S]) * 1e3) / 1e3, _[S * 4 + 1] = e.round((U * P[S] + Y * y[S] + Z * d[S] + V * x[S]) * 1e3) / 1e3, _[S * 4 + 2] = e.round((I * P[S] + A * y[S] + R * d[S] + X * x[S]) * 1e3) / 1e3, _[S * 4 + 3] = e.round((O * P[S] + ie * y[S] + se * d[S] + oe * x[S]) * 1e3) / 1e3;
                return _
            }
            return {
                getSegmentsLength: s,
                getNewSegment: E,
                getPointInSegment: g,
                buildBezierData: l,
                pointOnLine2D: t,
                pointOnLine3D: r
            }
        }
        var bez = bezFunction();

        function dataFunctionManager() {
            function e(P, x, y) {
                var d, b, m = P.length,
                    o, f, u, S;
                for (b = 0; b < m; b += 1)
                    if (d = P[b], "ks" in d && !d.completed) {
                        if (d.completed = !0, d.tt && (P[b - 1].td = d.tt), d.hasMask) {
                            var k = d.masksProperties;
                            for (f = k.length, o = 0; o < f; o += 1)
                                if (k[o].pt.k.i) i(k[o].pt.k);
                                else
                                    for (S = k[o].pt.k.length, u = 0; u < S; u += 1) k[o].pt.k[u].s && i(k[o].pt.k[u].s[0]), k[o].pt.k[u].e && i(k[o].pt.k[u].e[0])
                        }
                        d.ty === 0 ? (d.layers = t(d.refId, x), e(d.layers, x)) : d.ty === 4 ? r(d.shapes) : d.ty === 5 && _(d)
                    }
            }

            function t(P, x) {
                for (var y = 0, d = x.length; y < d;) {
                    if (x[y].id === P) return x[y].layers.__used ? JSON.parse(JSON.stringify(x[y].layers)) : (x[y].layers.__used = !0, x[y].layers);
                    y += 1
                }
                return null
            }

            function r(P) {
                var x, y = P.length,
                    d, b;
                for (x = y - 1; x >= 0; x -= 1)
                    if (P[x].ty === "sh")
                        if (P[x].ks.k.i) i(P[x].ks.k);
                        else
                            for (b = P[x].ks.k.length, d = 0; d < b; d += 1) P[x].ks.k[d].s && i(P[x].ks.k[d].s[0]), P[x].ks.k[d].e && i(P[x].ks.k[d].e[0]);
                else P[x].ty === "gr" && r(P[x].it)
            }

            function i(P) {
                var x, y = P.i.length;
                for (x = 0; x < y; x += 1) P.i[x][0] += P.v[x][0], P.i[x][1] += P.v[x][1], P.o[x][0] += P.v[x][0], P.o[x][1] += P.v[x][1]
            }

            function s(P, x) {
                var y = x ? x.split(".") : [100, 100, 100];
                return P[0] > y[0] ? !0 : y[0] > P[0] ? !1 : P[1] > y[1] ? !0 : y[1] > P[1] ? !1 : P[2] > y[2] ? !0 : y[2] > P[2] ? !1 : null
            }
            var n = function () {
                    var P = [4, 4, 14];

                    function x(d) {
                        var b = d.t.d;
                        d.t.d = {
                            k: [{
                                s: b,
                                t: 0
                            }]
                        }
                    }

                    function y(d) {
                        var b, m = d.length;
                        for (b = 0; b < m; b += 1) d[b].ty === 5 && x(d[b])
                    }
                    return function (d) {
                        if (s(P, d.v) && (y(d.layers), d.assets)) {
                            var b, m = d.assets.length;
                            for (b = 0; b < m; b += 1) d.assets[b].layers && y(d.assets[b].layers)
                        }
                    }
                }(),
                a = function () {
                    var P = [4, 7, 99];
                    return function (x) {
                        if (x.chars && !s(P, x.v)) {
                            var y, d = x.chars.length,
                                b, m, o, f;
                            for (y = 0; y < d; y += 1)
                                if (x.chars[y].data && x.chars[y].data.shapes)
                                    for (f = x.chars[y].data.shapes[0].it, m = f.length, b = 0; b < m; b += 1) o = f[b].ks.k, o.__converted || (i(f[b].ks.k), o.__converted = !0)
                        }
                    }
                }(),
                l = function () {
                    var P = [4, 1, 9];

                    function x(d) {
                        var b, m = d.length,
                            o, f;
                        for (b = 0; b < m; b += 1)
                            if (d[b].ty === "gr") x(d[b].it);
                            else if (d[b].ty === "fl" || d[b].ty === "st")
                            if (d[b].c.k && d[b].c.k[0].i)
                                for (f = d[b].c.k.length, o = 0; o < f; o += 1) d[b].c.k[o].s && (d[b].c.k[o].s[0] /= 255, d[b].c.k[o].s[1] /= 255, d[b].c.k[o].s[2] /= 255, d[b].c.k[o].s[3] /= 255), d[b].c.k[o].e && (d[b].c.k[o].e[0] /= 255, d[b].c.k[o].e[1] /= 255, d[b].c.k[o].e[2] /= 255, d[b].c.k[o].e[3] /= 255);
                            else d[b].c.k[0] /= 255, d[b].c.k[1] /= 255, d[b].c.k[2] /= 255, d[b].c.k[3] /= 255
                    }

                    function y(d) {
                        var b, m = d.length;
                        for (b = 0; b < m; b += 1) d[b].ty === 4 && x(d[b].shapes)
                    }
                    return function (d) {
                        if (s(P, d.v) && (y(d.layers), d.assets)) {
                            var b, m = d.assets.length;
                            for (b = 0; b < m; b += 1) d.assets[b].layers && y(d.assets[b].layers)
                        }
                    }
                }(),
                c = function () {
                    var P = [4, 4, 18];

                    function x(d) {
                        var b, m = d.length,
                            o, f;
                        for (b = m - 1; b >= 0; b -= 1)
                            if (d[b].ty === "sh")
                                if (d[b].ks.k.i) d[b].ks.k.c = d[b].closed;
                                else
                                    for (f = d[b].ks.k.length, o = 0; o < f; o += 1) d[b].ks.k[o].s && (d[b].ks.k[o].s[0].c = d[b].closed), d[b].ks.k[o].e && (d[b].ks.k[o].e[0].c = d[b].closed);
                        else d[b].ty === "gr" && x(d[b].it)
                    }

                    function y(d) {
                        var b, m, o = d.length,
                            f, u, S, k;
                        for (m = 0; m < o; m += 1) {
                            if (b = d[m], b.hasMask) {
                                var C = b.masksProperties;
                                for (u = C.length, f = 0; f < u; f += 1)
                                    if (C[f].pt.k.i) C[f].pt.k.c = C[f].cl;
                                    else
                                        for (k = C[f].pt.k.length, S = 0; S < k; S += 1) C[f].pt.k[S].s && (C[f].pt.k[S].s[0].c = C[f].cl), C[f].pt.k[S].e && (C[f].pt.k[S].e[0].c = C[f].cl)
                            }
                            b.ty === 4 && x(b.shapes)
                        }
                    }
                    return function (d) {
                        if (s(P, d.v) && (y(d.layers), d.assets)) {
                            var b, m = d.assets.length;
                            for (b = 0; b < m; b += 1) d.assets[b].layers && y(d.assets[b].layers)
                        }
                    }
                }();

            function g(P, x) {
                P.__complete || (l(P), n(P), a(P), c(P), e(P.layers, P.assets), P.__complete = !0)
            }

            function _(P) {
                P.t.a.length === 0 && !("m" in P.t.p) && (P.singleShape = !0)
            }
            var E = {};
            return E.completeData = g, E.checkColors = l, E.checkChars = a, E.checkShapes = c, E.completeLayers = e, E
        }
        var dataManager = dataFunctionManager();

        function getFontProperties(e) {
            for (var t = e.fStyle ? e.fStyle.split(" ") : [], r = "normal", i = "normal", s = t.length, n, a = 0; a < s; a += 1) switch (n = t[a].toLowerCase(), n) {
                case "italic":
                    i = "italic";
                    break;
                case "bold":
                    r = "700";
                    break;
                case "black":
                    r = "900";
                    break;
                case "medium":
                    r = "500";
                    break;
                case "regular":
                case "normal":
                    r = "400";
                    break;
                case "light":
                case "thin":
                    r = "200";
                    break
            }
            return {
                style: i,
                weight: e.fWeight || r
            }
        }
        var FontManager = function () {
                var e = 5e3,
                    t = {
                        w: 0,
                        size: 0,
                        shapes: []
                    },
                    r = [];
                r = r.concat([2304, 2305, 2306, 2307, 2362, 2363, 2364, 2364, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2387, 2388, 2389, 2390, 2391, 2402, 2403]);
                var i = ["d83cdffb", "d83cdffc", "d83cdffd", "d83cdffe", "d83cdfff"],
                    s = [65039, 8205];

                function n(u) {
                    var S = u.split(","),
                        k, C = S.length,
                        T = [];
                    for (k = 0; k < C; k += 1) S[k] !== "sans-serif" && S[k] !== "monospace" && T.push(S[k]);
                    return T.join(",")
                }

                function a(u, S) {
                    var k = createTag("span");
                    k.setAttribute("aria-hidden", !0), k.style.fontFamily = S;
                    var C = createTag("span");
                    C.innerText = "giItT1WQy@!-/#", k.style.position = "absolute", k.style.left = "-10000px", k.style.top = "-10000px", k.style.fontSize = "300px", k.style.fontVariant = "normal", k.style.fontStyle = "normal", k.style.fontWeight = "normal", k.style.letterSpacing = "0", k.appendChild(C), document.body.appendChild(k);
                    var T = C.offsetWidth;
                    return C.style.fontFamily = n(u) + ", " + S, {
                        node: C,
                        w: T,
                        parent: k
                    }
                }

                function l() {
                    var u, S = this.fonts.length,
                        k, C, T = S;
                    for (u = 0; u < S; u += 1) this.fonts[u].loaded ? T -= 1 : this.fonts[u].fOrigin === "n" || this.fonts[u].origin === 0 ? this.fonts[u].loaded = !0 : (k = this.fonts[u].monoCase.node, C = this.fonts[u].monoCase.w, k.offsetWidth !== C ? (T -= 1, this.fonts[u].loaded = !0) : (k = this.fonts[u].sansCase.node, C = this.fonts[u].sansCase.w, k.offsetWidth !== C && (T -= 1, this.fonts[u].loaded = !0)), this.fonts[u].loaded && (this.fonts[u].sansCase.parent.parentNode.removeChild(this.fonts[u].sansCase.parent), this.fonts[u].monoCase.parent.parentNode.removeChild(this.fonts[u].monoCase.parent)));
                    T !== 0 && Date.now() - this.initTime < e ? setTimeout(this.checkLoadedFontsBinded, 20) : setTimeout(this.setIsLoadedBinded, 10)
                }

                function c(u, S) {
                    var k = createNS("text");
                    k.style.fontSize = "100px";
                    var C = getFontProperties(S);
                    k.setAttribute("font-family", S.fFamily), k.setAttribute("font-style", C.style), k.setAttribute("font-weight", C.weight), k.textContent = "1", S.fClass ? (k.style.fontFamily = "inherit", k.setAttribute("class", S.fClass)) : k.style.fontFamily = S.fFamily, u.appendChild(k);
                    var T = createTag("canvas").getContext("2d");
                    return T.font = S.fWeight + " " + S.fStyle + " 100px " + S.fFamily, k
                }

                function g(u, S) {
                    if (!u) {
                        this.isLoaded = !0;
                        return
                    }
                    if (this.chars) {
                        this.isLoaded = !0, this.fonts = u.list;
                        return
                    }
                    var k = u.list,
                        C, T = k.length,
                        B = T;
                    for (C = 0; C < T; C += 1) {
                        var D = !0,
                            H, L;
                        if (k[C].loaded = !1, k[C].monoCase = a(k[C].fFamily, "monospace"), k[C].sansCase = a(k[C].fFamily, "sans-serif"), !k[C].fPath) k[C].loaded = !0, B -= 1;
                        else if (k[C].fOrigin === "p" || k[C].origin === 3) {
                            if (H = document.querySelectorAll('style[f-forigin="p"][f-family="' + k[C].fFamily + '"], style[f-origin="3"][f-family="' + k[C].fFamily + '"]'), H.length > 0 && (D = !1), D) {
                                var U = createTag("style");
                                U.setAttribute("f-forigin", k[C].fOrigin), U.setAttribute("f-origin", k[C].origin), U.setAttribute("f-family", k[C].fFamily), U.type = "text/css", U.innerText = "@font-face {font-family: " + k[C].fFamily + "; font-style: normal; src: url('" + k[C].fPath + "');}", S.appendChild(U)
                            }
                        } else if (k[C].fOrigin === "g" || k[C].origin === 1) {
                            for (H = document.querySelectorAll('link[f-forigin="g"], link[f-origin="1"]'), L = 0; L < H.length; L += 1) H[L].href.indexOf(k[C].fPath) !== -1 && (D = !1);
                            if (D) {
                                var Y = createTag("link");
                                Y.setAttribute("f-forigin", k[C].fOrigin), Y.setAttribute("f-origin", k[C].origin), Y.type = "text/css", Y.rel = "stylesheet", Y.href = k[C].fPath, document.body.appendChild(Y)
                            }
                        } else if (k[C].fOrigin === "t" || k[C].origin === 2) {
                            for (H = document.querySelectorAll('script[f-forigin="t"], script[f-origin="2"]'), L = 0; L < H.length; L += 1) k[C].fPath === H[L].src && (D = !1);
                            if (D) {
                                var Z = createTag("link");
                                Z.setAttribute("f-forigin", k[C].fOrigin), Z.setAttribute("f-origin", k[C].origin), Z.setAttribute("rel", "stylesheet"), Z.setAttribute("href", k[C].fPath), S.appendChild(Z)
                            }
                        }
                        k[C].helper = c(S, k[C]), k[C].cache = {}, this.fonts.push(k[C])
                    }
                    B === 0 ? this.isLoaded = !0 : setTimeout(this.checkLoadedFonts.bind(this), 100)
                }

                function _(u) {
                    if (u) {
                        this.chars || (this.chars = []);
                        var S, k = u.length,
                            C, T = this.chars.length,
                            B;
                        for (S = 0; S < k; S += 1) {
                            for (C = 0, B = !1; C < T;) this.chars[C].style === u[S].style && this.chars[C].fFamily === u[S].fFamily && this.chars[C].ch === u[S].ch && (B = !0), C += 1;
                            B || (this.chars.push(u[S]), T += 1)
                        }
                    }
                }

                function E(u, S, k) {
                    for (var C = 0, T = this.chars.length; C < T;) {
                        if (this.chars[C].ch === u && this.chars[C].style === S && this.chars[C].fFamily === k) return this.chars[C];
                        C += 1
                    }
                    return (typeof u == "string" && u.charCodeAt(0) !== 13 || !u) && console && console.warn && !this._warned && (this._warned = !0, console.warn("Missing character from exported characters list: ", u, S, k)), t
                }

                function P(u, S, k) {
                    var C = this.getFontByName(S),
                        T = u.charCodeAt(0);
                    if (!C.cache[T + 1]) {
                        var B = C.helper;
                        if (u === " ") {
                            B.textContent = "|" + u + "|";
                            var D = B.getComputedTextLength();
                            B.textContent = "||";
                            var H = B.getComputedTextLength();
                            C.cache[T + 1] = (D - H) / 100
                        } else B.textContent = u, C.cache[T + 1] = B.getComputedTextLength() / 100
                    }
                    return C.cache[T + 1] * k
                }

                function x(u) {
                    for (var S = 0, k = this.fonts.length; S < k;) {
                        if (this.fonts[S].fName === u) return this.fonts[S];
                        S += 1
                    }
                    return this.fonts[0]
                }

                function y(u, S) {
                    var k = u.toString(16) + S.toString(16);
                    return i.indexOf(k) !== -1
                }

                function d(u, S) {
                    return S ? u === s[0] && S === s[1] : u === s[1]
                }

                function b(u) {
                    return r.indexOf(u) !== -1
                }

                function m() {
                    this.isLoaded = !0
                }
                var o = function () {
                    this.fonts = [], this.chars = null, this.typekitLoaded = 0, this.isLoaded = !1, this._warned = !1, this.initTime = Date.now(), this.setIsLoadedBinded = this.setIsLoaded.bind(this), this.checkLoadedFontsBinded = this.checkLoadedFonts.bind(this)
                };
                o.isModifier = y, o.isZeroWidthJoiner = d, o.isCombinedCharacter = b;
                var f = {
                    addChars: _,
                    addFonts: g,
                    getCharData: E,
                    getFontByName: x,
                    measureText: P,
                    checkLoadedFonts: l,
                    setIsLoaded: m
                };
                return o.prototype = f, o
            }(),
            PropertyFactory = function () {
                var e = initialDefaultFrame,
                    t = Math.abs;

                function r(b, m) {
                    var o = this.offsetTime,
                        f;
                    this.propType === "multidimensional" && (f = createTypedArray("float32", this.pv.length));
                    for (var u = m.lastIndex, S = u, k = this.keyframes.length - 1, C = !0, T, B; C;) {
                        if (T = this.keyframes[S], B = this.keyframes[S + 1], S === k - 1 && b >= B.t - o) {
                            T.h && (T = B), u = 0;
                            break
                        }
                        if (B.t - o > b) {
                            u = S;
                            break
                        }
                        S < k - 1 ? S += 1 : (u = 0, C = !1)
                    }
                    var D, H, L, U, Y, Z, V = B.t - o,
                        I = T.t - o,
                        A;
                    if (T.to) {
                        T.bezierData || (T.bezierData = bez.buildBezierData(T.s, B.s || T.e, T.to, T.ti));
                        var R = T.bezierData;
                        if (b >= V || b < I) {
                            var X = b >= V ? R.points.length - 1 : 0;
                            for (H = R.points[X].point.length, D = 0; D < H; D += 1) f[D] = R.points[X].point[D]
                        } else {
                            T.__fnct ? Z = T.__fnct : (Z = BezierFactory.getBezierEasing(T.o.x, T.o.y, T.i.x, T.i.y, T.n).get, T.__fnct = Z), L = Z((b - I) / (V - I));
                            var O = R.segmentLength * L,
                                ie, se = m.lastFrame < b && m._lastKeyframeIndex === S ? m._lastAddedLength : 0;
                            for (Y = m.lastFrame < b && m._lastKeyframeIndex === S ? m._lastPoint : 0, C = !0, U = R.points.length; C;) {
                                if (se += R.points[Y].partialLength, O === 0 || L === 0 || Y === R.points.length - 1) {
                                    for (H = R.points[Y].point.length, D = 0; D < H; D += 1) f[D] = R.points[Y].point[D];
                                    break
                                } else if (O >= se && O < se + R.points[Y + 1].partialLength) {
                                    for (ie = (O - se) / R.points[Y + 1].partialLength, H = R.points[Y].point.length, D = 0; D < H; D += 1) f[D] = R.points[Y].point[D] + (R.points[Y + 1].point[D] - R.points[Y].point[D]) * ie;
                                    break
                                }
                                Y < U - 1 ? Y += 1 : C = !1
                            }
                            m._lastPoint = Y, m._lastAddedLength = se - R.points[Y].partialLength, m._lastKeyframeIndex = S
                        }
                    } else {
                        var oe, fe, le, pe, me;
                        if (k = T.s.length, A = B.s || T.e, this.sh && T.h !== 1)
                            if (b >= V) f[0] = A[0], f[1] = A[1], f[2] = A[2];
                            else if (b <= I) f[0] = T.s[0], f[1] = T.s[1], f[2] = T.s[2];
                        else {
                            var de = n(T.s),
                                ue = n(A),
                                ce = (b - I) / (V - I);
                            s(f, i(de, ue, ce))
                        } else
                            for (S = 0; S < k; S += 1) T.h !== 1 && (b >= V ? L = 1 : b < I ? L = 0 : (T.o.x.constructor === Array ? (T.__fnct || (T.__fnct = []), T.__fnct[S] ? Z = T.__fnct[S] : (oe = typeof T.o.x[S] > "u" ? T.o.x[0] : T.o.x[S], fe = typeof T.o.y[S] > "u" ? T.o.y[0] : T.o.y[S], le = typeof T.i.x[S] > "u" ? T.i.x[0] : T.i.x[S], pe = typeof T.i.y[S] > "u" ? T.i.y[0] : T.i.y[S], Z = BezierFactory.getBezierEasing(oe, fe, le, pe).get, T.__fnct[S] = Z)) : T.__fnct ? Z = T.__fnct : (oe = T.o.x, fe = T.o.y, le = T.i.x, pe = T.i.y, Z = BezierFactory.getBezierEasing(oe, fe, le, pe).get, T.__fnct = Z), L = Z((b - I) / (V - I)))), A = B.s || T.e, me = T.h === 1 ? T.s[S] : T.s[S] + (A[S] - T.s[S]) * L, this.propType === "multidimensional" ? f[S] = me : f = me
                    }
                    return m.lastIndex = u, f
                }

                function i(b, m, o) {
                    var f = [],
                        u = b[0],
                        S = b[1],
                        k = b[2],
                        C = b[3],
                        T = m[0],
                        B = m[1],
                        D = m[2],
                        H = m[3],
                        L, U, Y, Z, V;
                    return U = u * T + S * B + k * D + C * H, U < 0 && (U = -U, T = -T, B = -B, D = -D, H = -H), 1 - U > 1e-6 ? (L = Math.acos(U), Y = Math.sin(L), Z = Math.sin((1 - o) * L) / Y, V = Math.sin(o * L) / Y) : (Z = 1 - o, V = o), f[0] = Z * u + V * T, f[1] = Z * S + V * B, f[2] = Z * k + V * D, f[3] = Z * C + V * H, f
                }

                function s(b, m) {
                    var o = m[0],
                        f = m[1],
                        u = m[2],
                        S = m[3],
                        k = Math.atan2(2 * f * S - 2 * o * u, 1 - 2 * f * f - 2 * u * u),
                        C = Math.asin(2 * o * f + 2 * u * S),
                        T = Math.atan2(2 * o * S - 2 * f * u, 1 - 2 * o * o - 2 * u * u);
                    b[0] = k / degToRads, b[1] = C / degToRads, b[2] = T / degToRads
                }

                function n(b) {
                    var m = b[0] * degToRads,
                        o = b[1] * degToRads,
                        f = b[2] * degToRads,
                        u = Math.cos(m / 2),
                        S = Math.cos(o / 2),
                        k = Math.cos(f / 2),
                        C = Math.sin(m / 2),
                        T = Math.sin(o / 2),
                        B = Math.sin(f / 2),
                        D = u * S * k - C * T * B,
                        H = C * T * k + u * S * B,
                        L = C * S * k + u * T * B,
                        U = u * T * k - C * S * B;
                    return [H, L, U, D]
                }

                function a() {
                    var b = this.comp.renderedFrame - this.offsetTime,
                        m = this.keyframes[0].t - this.offsetTime,
                        o = this.keyframes[this.keyframes.length - 1].t - this.offsetTime;
                    if (!(b === this._caching.lastFrame || this._caching.lastFrame !== e && (this._caching.lastFrame >= o && b >= o || this._caching.lastFrame < m && b < m))) {
                        this._caching.lastFrame >= b && (this._caching._lastKeyframeIndex = -1, this._caching.lastIndex = 0);
                        var f = this.interpolateValue(b, this._caching);
                        this.pv = f
                    }
                    return this._caching.lastFrame = b, this.pv
                }

                function l(b) {
                    var m;
                    if (this.propType === "unidimensional") m = b * this.mult, t(this.v - m) > 1e-5 && (this.v = m, this._mdf = !0);
                    else
                        for (var o = 0, f = this.v.length; o < f;) m = b[o] * this.mult, t(this.v[o] - m) > 1e-5 && (this.v[o] = m, this._mdf = !0), o += 1
                }

                function c() {
                    if (!(this.elem.globalData.frameId === this.frameId || !this.effectsSequence.length)) {
                        if (this.lock) {
                            this.setVValue(this.pv);
                            return
                        }
                        this.lock = !0, this._mdf = this._isFirstFrame;
                        var b, m = this.effectsSequence.length,
                            o = this.kf ? this.pv : this.data.k;
                        for (b = 0; b < m; b += 1) o = this.effectsSequence[b](o);
                        this.setVValue(o), this._isFirstFrame = !1, this.lock = !1, this.frameId = this.elem.globalData.frameId
                    }
                }

                function g(b) {
                    this.effectsSequence.push(b), this.container.addDynamicProperty(this)
                }

                function _(b, m, o, f) {
                    this.propType = "unidimensional", this.mult = o || 1, this.data = m, this.v = o ? m.k * o : m.k, this.pv = m.k, this._mdf = !1, this.elem = b, this.container = f, this.comp = b.comp, this.k = !1, this.kf = !1, this.vel = 0, this.effectsSequence = [], this._isFirstFrame = !0, this.getValue = c, this.setVValue = l, this.addEffect = g
                }

                function E(b, m, o, f) {
                    this.propType = "multidimensional", this.mult = o || 1, this.data = m, this._mdf = !1, this.elem = b, this.container = f, this.comp = b.comp, this.k = !1, this.kf = !1, this.frameId = -1;
                    var u, S = m.k.length;
                    for (this.v = createTypedArray("float32", S), this.pv = createTypedArray("float32", S), this.vel = createTypedArray("float32", S), u = 0; u < S; u += 1) this.v[u] = m.k[u] * this.mult, this.pv[u] = m.k[u];
                    this._isFirstFrame = !0, this.effectsSequence = [], this.getValue = c, this.setVValue = l, this.addEffect = g
                }

                function P(b, m, o, f) {
                    this.propType = "unidimensional", this.keyframes = m.k, this.offsetTime = b.data.st, this.frameId = -1, this._caching = {
                        lastFrame: e,
                        lastIndex: 0,
                        value: 0,
                        _lastKeyframeIndex: -1
                    }, this.k = !0, this.kf = !0, this.data = m, this.mult = o || 1, this.elem = b, this.container = f, this.comp = b.comp, this.v = e, this.pv = e, this._isFirstFrame = !0, this.getValue = c, this.setVValue = l, this.interpolateValue = r, this.effectsSequence = [a.bind(this)], this.addEffect = g
                }

                function x(b, m, o, f) {
                    this.propType = "multidimensional";
                    var u, S = m.k.length,
                        k, C, T, B;
                    for (u = 0; u < S - 1; u += 1) m.k[u].to && m.k[u].s && m.k[u + 1] && m.k[u + 1].s && (k = m.k[u].s, C = m.k[u + 1].s, T = m.k[u].to, B = m.k[u].ti, (k.length === 2 && !(k[0] === C[0] && k[1] === C[1]) && bez.pointOnLine2D(k[0], k[1], C[0], C[1], k[0] + T[0], k[1] + T[1]) && bez.pointOnLine2D(k[0], k[1], C[0], C[1], C[0] + B[0], C[1] + B[1]) || k.length === 3 && !(k[0] === C[0] && k[1] === C[1] && k[2] === C[2]) && bez.pointOnLine3D(k[0], k[1], k[2], C[0], C[1], C[2], k[0] + T[0], k[1] + T[1], k[2] + T[2]) && bez.pointOnLine3D(k[0], k[1], k[2], C[0], C[1], C[2], C[0] + B[0], C[1] + B[1], C[2] + B[2])) && (m.k[u].to = null, m.k[u].ti = null), k[0] === C[0] && k[1] === C[1] && T[0] === 0 && T[1] === 0 && B[0] === 0 && B[1] === 0 && (k.length === 2 || k[2] === C[2] && T[2] === 0 && B[2] === 0) && (m.k[u].to = null, m.k[u].ti = null));
                    this.effectsSequence = [a.bind(this)], this.data = m, this.keyframes = m.k, this.offsetTime = b.data.st, this.k = !0, this.kf = !0, this._isFirstFrame = !0, this.mult = o || 1, this.elem = b, this.container = f, this.comp = b.comp, this.getValue = c, this.setVValue = l, this.interpolateValue = r, this.frameId = -1;
                    var D = m.k[0].s.length;
                    for (this.v = createTypedArray("float32", D), this.pv = createTypedArray("float32", D), u = 0; u < D; u += 1) this.v[u] = e, this.pv[u] = e;
                    this._caching = {
                        lastFrame: e,
                        lastIndex: 0,
                        value: createTypedArray("float32", D)
                    }, this.addEffect = g
                }

                function y(b, m, o, f, u) {
                    var S;
                    if (!m.k.length) S = new _(b, m, f, u);
                    else if (typeof m.k[0] == "number") S = new E(b, m, f, u);
                    else switch (o) {
                        case 0:
                            S = new P(b, m, f, u);
                            break;
                        case 1:
                            S = new x(b, m, f, u);
                            break
                    }
                    return S.effectsSequence.length && u.addDynamicProperty(S), S
                }
                var d = {
                    getProp: y
                };
                return d
            }(),
            TransformPropertyFactory = function () {
                var e = [0, 0];

                function t(c) {
                    var g = this._mdf;
                    this.iterateDynamicProperties(), this._mdf = this._mdf || g, this.a && c.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.s && c.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && c.skewFromAxis(-this.sk.v, this.sa.v), this.r ? c.rotate(-this.r.v) : c.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.data.p.s ? this.data.p.z ? c.translate(this.px.v, this.py.v, -this.pz.v) : c.translate(this.px.v, this.py.v, 0) : c.translate(this.p.v[0], this.p.v[1], -this.p.v[2])
                }

                function r(c) {
                    if (this.elem.globalData.frameId !== this.frameId) {
                        if (this._isDirty && (this.precalculateMatrix(), this._isDirty = !1), this.iterateDynamicProperties(), this._mdf || c) {
                            var g;
                            if (this.v.cloneFromProps(this.pre.props), this.appliedTransformations < 1 && this.v.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations < 2 && this.v.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && this.appliedTransformations < 3 && this.v.skewFromAxis(-this.sk.v, this.sa.v), this.r && this.appliedTransformations < 4 ? this.v.rotate(-this.r.v) : !this.r && this.appliedTransformations < 4 && this.v.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.autoOriented) {
                                var _, E;
                                if (g = this.elem.globalData.frameRate, this.p && this.p.keyframes && this.p.getValueAtTime) this.p._caching.lastFrame + this.p.offsetTime <= this.p.keyframes[0].t ? (_ = this.p.getValueAtTime((this.p.keyframes[0].t + .01) / g, 0), E = this.p.getValueAtTime(this.p.keyframes[0].t / g, 0)) : this.p._caching.lastFrame + this.p.offsetTime >= this.p.keyframes[this.p.keyframes.length - 1].t ? (_ = this.p.getValueAtTime(this.p.keyframes[this.p.keyframes.length - 1].t / g, 0), E = this.p.getValueAtTime((this.p.keyframes[this.p.keyframes.length - 1].t - .05) / g, 0)) : (_ = this.p.pv, E = this.p.getValueAtTime((this.p._caching.lastFrame + this.p.offsetTime - .01) / g, this.p.offsetTime));
                                else if (this.px && this.px.keyframes && this.py.keyframes && this.px.getValueAtTime && this.py.getValueAtTime) {
                                    _ = [], E = [];
                                    var P = this.px,
                                        x = this.py;
                                    P._caching.lastFrame + P.offsetTime <= P.keyframes[0].t ? (_[0] = P.getValueAtTime((P.keyframes[0].t + .01) / g, 0), _[1] = x.getValueAtTime((x.keyframes[0].t + .01) / g, 0), E[0] = P.getValueAtTime(P.keyframes[0].t / g, 0), E[1] = x.getValueAtTime(x.keyframes[0].t / g, 0)) : P._caching.lastFrame + P.offsetTime >= P.keyframes[P.keyframes.length - 1].t ? (_[0] = P.getValueAtTime(P.keyframes[P.keyframes.length - 1].t / g, 0), _[1] = x.getValueAtTime(x.keyframes[x.keyframes.length - 1].t / g, 0), E[0] = P.getValueAtTime((P.keyframes[P.keyframes.length - 1].t - .01) / g, 0), E[1] = x.getValueAtTime((x.keyframes[x.keyframes.length - 1].t - .01) / g, 0)) : (_ = [P.pv, x.pv], E[0] = P.getValueAtTime((P._caching.lastFrame + P.offsetTime - .01) / g, P.offsetTime), E[1] = x.getValueAtTime((x._caching.lastFrame + x.offsetTime - .01) / g, x.offsetTime))
                                } else E = e, _ = E;
                                this.v.rotate(-Math.atan2(_[1] - E[1], _[0] - E[0]))
                            }
                            this.data.p && this.data.p.s ? this.data.p.z ? this.v.translate(this.px.v, this.py.v, -this.pz.v) : this.v.translate(this.px.v, this.py.v, 0) : this.v.translate(this.p.v[0], this.p.v[1], -this.p.v[2])
                        }
                        this.frameId = this.elem.globalData.frameId
                    }
                }

                function i() {
                    if (!this.a.k) this.pre.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations = 1;
                    else return;
                    if (!this.s.effectsSequence.length) this.pre.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.appliedTransformations = 2;
                    else return;
                    if (this.sk)
                        if (!this.sk.effectsSequence.length && !this.sa.effectsSequence.length) this.pre.skewFromAxis(-this.sk.v, this.sa.v), this.appliedTransformations = 3;
                        else return;
                    this.r ? this.r.effectsSequence.length || (this.pre.rotate(-this.r.v), this.appliedTransformations = 4) : !this.rz.effectsSequence.length && !this.ry.effectsSequence.length && !this.rx.effectsSequence.length && !this.or.effectsSequence.length && (this.pre.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.appliedTransformations = 4)
                }

                function s() {}

                function n(c) {
                    this._addDynamicProperty(c), this.elem.addDynamicProperty(c), this._isDirty = !0
                }

                function a(c, g, _) {
                    if (this.elem = c, this.frameId = -1, this.propType = "transform", this.data = g, this.v = new Matrix, this.pre = new Matrix, this.appliedTransformations = 0, this.initDynamicPropertyContainer(_ || c), g.p && g.p.s ? (this.px = PropertyFactory.getProp(c, g.p.x, 0, 0, this), this.py = PropertyFactory.getProp(c, g.p.y, 0, 0, this), g.p.z && (this.pz = PropertyFactory.getProp(c, g.p.z, 0, 0, this))) : this.p = PropertyFactory.getProp(c, g.p || {
                            k: [0, 0, 0]
                        }, 1, 0, this), g.rx) {
                        if (this.rx = PropertyFactory.getProp(c, g.rx, 0, degToRads, this), this.ry = PropertyFactory.getProp(c, g.ry, 0, degToRads, this), this.rz = PropertyFactory.getProp(c, g.rz, 0, degToRads, this), g.or.k[0].ti) {
                            var E, P = g.or.k.length;
                            for (E = 0; E < P; E += 1) g.or.k[E].to = null, g.or.k[E].ti = null
                        }
                        this.or = PropertyFactory.getProp(c, g.or, 1, degToRads, this), this.or.sh = !0
                    } else this.r = PropertyFactory.getProp(c, g.r || {
                        k: 0
                    }, 0, degToRads, this);
                    g.sk && (this.sk = PropertyFactory.getProp(c, g.sk, 0, degToRads, this), this.sa = PropertyFactory.getProp(c, g.sa, 0, degToRads, this)), this.a = PropertyFactory.getProp(c, g.a || {
                        k: [0, 0, 0]
                    }, 1, 0, this), this.s = PropertyFactory.getProp(c, g.s || {
                        k: [100, 100, 100]
                    }, 1, .01, this), g.o ? this.o = PropertyFactory.getProp(c, g.o, 0, .01, c) : this.o = {
                        _mdf: !1,
                        v: 1
                    }, this._isDirty = !0, this.dynamicProperties.length || this.getValue(!0)
                }
                a.prototype = {
                    applyToMatrix: t,
                    getValue: r,
                    precalculateMatrix: i,
                    autoOrient: s
                }, extendPrototype([DynamicPropertyContainer], a), a.prototype.addDynamicProperty = n, a.prototype._addDynamicProperty = DynamicPropertyContainer.prototype.addDynamicProperty;

                function l(c, g, _) {
                    return new a(c, g, _)
                }
                return {
                    getTransformProperty: l
                }
            }();

        function ShapePath() {
            this.c = !1, this._length = 0, this._maxLength = 8, this.v = createSizedArray(this._maxLength), this.o = createSizedArray(this._maxLength), this.i = createSizedArray(this._maxLength)
        }
        ShapePath.prototype.setPathData = function (e, t) {
            this.c = e, this.setLength(t);
            for (var r = 0; r < t;) this.v[r] = pointPool.newElement(), this.o[r] = pointPool.newElement(), this.i[r] = pointPool.newElement(), r += 1
        }, ShapePath.prototype.setLength = function (e) {
            for (; this._maxLength < e;) this.doubleArrayLength();
            this._length = e
        }, ShapePath.prototype.doubleArrayLength = function () {
            this.v = this.v.concat(createSizedArray(this._maxLength)), this.i = this.i.concat(createSizedArray(this._maxLength)), this.o = this.o.concat(createSizedArray(this._maxLength)), this._maxLength *= 2
        }, ShapePath.prototype.setXYAt = function (e, t, r, i, s) {
            var n;
            switch (this._length = Math.max(this._length, i + 1), this._length >= this._maxLength && this.doubleArrayLength(), r) {
                case "v":
                    n = this.v;
                    break;
                case "i":
                    n = this.i;
                    break;
                case "o":
                    n = this.o;
                    break;
                default:
                    n = [];
                    break
            }(!n[i] || n[i] && !s) && (n[i] = pointPool.newElement()), n[i][0] = e, n[i][1] = t
        }, ShapePath.prototype.setTripleAt = function (e, t, r, i, s, n, a, l) {
            this.setXYAt(e, t, "v", a, l), this.setXYAt(r, i, "o", a, l), this.setXYAt(s, n, "i", a, l)
        }, ShapePath.prototype.reverse = function () {
            var e = new ShapePath;
            e.setPathData(this.c, this._length);
            var t = this.v,
                r = this.o,
                i = this.i,
                s = 0;
            this.c && (e.setTripleAt(t[0][0], t[0][1], i[0][0], i[0][1], r[0][0], r[0][1], 0, !1), s = 1);
            var n = this._length - 1,
                a = this._length,
                l;
            for (l = s; l < a; l += 1) e.setTripleAt(t[n][0], t[n][1], i[n][0], i[n][1], r[n][0], r[n][1], l, !1), n -= 1;
            return e
        };
        var ShapePropertyFactory = function () {
                var e = -999999;

                function t(m, o, f) {
                    var u = f.lastIndex,
                        S, k, C, T, B, D, H, L, U, Y = this.keyframes;
                    if (m < Y[0].t - this.offsetTime) S = Y[0].s[0], C = !0, u = 0;
                    else if (m >= Y[Y.length - 1].t - this.offsetTime) S = Y[Y.length - 1].s ? Y[Y.length - 1].s[0] : Y[Y.length - 2].e[0], C = !0;
                    else {
                        for (var Z = u, V = Y.length - 1, I = !0, A, R; I && (A = Y[Z], R = Y[Z + 1], !(R.t - this.offsetTime > m));) Z < V - 1 ? Z += 1 : I = !1;
                        if (C = A.h === 1, u = Z, !C) {
                            if (m >= R.t - this.offsetTime) L = 1;
                            else if (m < A.t - this.offsetTime) L = 0;
                            else {
                                var X;
                                A.__fnct ? X = A.__fnct : (X = BezierFactory.getBezierEasing(A.o.x, A.o.y, A.i.x, A.i.y).get, A.__fnct = X), L = X((m - (A.t - this.offsetTime)) / (R.t - this.offsetTime - (A.t - this.offsetTime)))
                            }
                            k = R.s ? R.s[0] : A.e[0]
                        }
                        S = A.s[0]
                    }
                    for (D = o._length, H = S.i[0].length, f.lastIndex = u, T = 0; T < D; T += 1)
                        for (B = 0; B < H; B += 1) U = C ? S.i[T][B] : S.i[T][B] + (k.i[T][B] - S.i[T][B]) * L, o.i[T][B] = U, U = C ? S.o[T][B] : S.o[T][B] + (k.o[T][B] - S.o[T][B]) * L, o.o[T][B] = U, U = C ? S.v[T][B] : S.v[T][B] + (k.v[T][B] - S.v[T][B]) * L, o.v[T][B] = U
                }

                function r() {
                    var m = this.comp.renderedFrame - this.offsetTime,
                        o = this.keyframes[0].t - this.offsetTime,
                        f = this.keyframes[this.keyframes.length - 1].t - this.offsetTime,
                        u = this._caching.lastFrame;
                    return u !== e && (u < o && m < o || u > f && m > f) || (this._caching.lastIndex = u < m ? this._caching.lastIndex : 0, this.interpolateShape(m, this.pv, this._caching)), this._caching.lastFrame = m, this.pv
                }

                function i() {
                    this.paths = this.localShapeCollection
                }

                function s(m, o) {
                    if (m._length !== o._length || m.c !== o.c) return !1;
                    var f, u = m._length;
                    for (f = 0; f < u; f += 1)
                        if (m.v[f][0] !== o.v[f][0] || m.v[f][1] !== o.v[f][1] || m.o[f][0] !== o.o[f][0] || m.o[f][1] !== o.o[f][1] || m.i[f][0] !== o.i[f][0] || m.i[f][1] !== o.i[f][1]) return !1;
                    return !0
                }

                function n(m) {
                    s(this.v, m) || (this.v = shapePool.clone(m), this.localShapeCollection.releaseShapes(), this.localShapeCollection.addShape(this.v), this._mdf = !0, this.paths = this.localShapeCollection)
                }

                function a() {
                    if (this.elem.globalData.frameId !== this.frameId) {
                        if (!this.effectsSequence.length) {
                            this._mdf = !1;
                            return
                        }
                        if (this.lock) {
                            this.setVValue(this.pv);
                            return
                        }
                        this.lock = !0, this._mdf = !1;
                        var m;
                        this.kf ? m = this.pv : this.data.ks ? m = this.data.ks.k : m = this.data.pt.k;
                        var o, f = this.effectsSequence.length;
                        for (o = 0; o < f; o += 1) m = this.effectsSequence[o](m);
                        this.setVValue(m), this.lock = !1, this.frameId = this.elem.globalData.frameId
                    }
                }

                function l(m, o, f) {
                    this.propType = "shape", this.comp = m.comp, this.container = m, this.elem = m, this.data = o, this.k = !1, this.kf = !1, this._mdf = !1;
                    var u = f === 3 ? o.pt.k : o.ks.k;
                    this.v = shapePool.clone(u), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.reset = i, this.effectsSequence = []
                }

                function c(m) {
                    this.effectsSequence.push(m), this.container.addDynamicProperty(this)
                }
                l.prototype.interpolateShape = t, l.prototype.getValue = a, l.prototype.setVValue = n, l.prototype.addEffect = c;

                function g(m, o, f) {
                    this.propType = "shape", this.comp = m.comp, this.elem = m, this.container = m, this.offsetTime = m.data.st, this.keyframes = f === 3 ? o.pt.k : o.ks.k, this.k = !0, this.kf = !0;
                    var u = this.keyframes[0].s[0].i.length;
                    this.v = shapePool.newElement(), this.v.setPathData(this.keyframes[0].s[0].c, u), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.lastFrame = e, this.reset = i, this._caching = {
                        lastFrame: e,
                        lastIndex: 0
                    }, this.effectsSequence = [r.bind(this)]
                }
                g.prototype.getValue = a, g.prototype.interpolateShape = t, g.prototype.setVValue = n, g.prototype.addEffect = c;
                var _ = function () {
                        var m = roundCorner;

                        function o(f, u) {
                            this.v = shapePool.newElement(), this.v.setPathData(!0, 4), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.localShapeCollection.addShape(this.v), this.d = u.d, this.elem = f, this.comp = f.comp, this.frameId = -1, this.initDynamicPropertyContainer(f), this.p = PropertyFactory.getProp(f, u.p, 1, 0, this), this.s = PropertyFactory.getProp(f, u.s, 1, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertEllToPath())
                        }
                        return o.prototype = {
                            reset: i,
                            getValue: function () {
                                this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertEllToPath())
                            },
                            convertEllToPath: function () {
                                var f = this.p.v[0],
                                    u = this.p.v[1],
                                    S = this.s.v[0] / 2,
                                    k = this.s.v[1] / 2,
                                    C = this.d !== 3,
                                    T = this.v;
                                T.v[0][0] = f, T.v[0][1] = u - k, T.v[1][0] = C ? f + S : f - S, T.v[1][1] = u, T.v[2][0] = f, T.v[2][1] = u + k, T.v[3][0] = C ? f - S : f + S, T.v[3][1] = u, T.i[0][0] = C ? f - S * m : f + S * m, T.i[0][1] = u - k, T.i[1][0] = C ? f + S : f - S, T.i[1][1] = u - k * m, T.i[2][0] = C ? f + S * m : f - S * m, T.i[2][1] = u + k, T.i[3][0] = C ? f - S : f + S, T.i[3][1] = u + k * m, T.o[0][0] = C ? f + S * m : f - S * m, T.o[0][1] = u - k, T.o[1][0] = C ? f + S : f - S, T.o[1][1] = u + k * m, T.o[2][0] = C ? f - S * m : f + S * m, T.o[2][1] = u + k, T.o[3][0] = C ? f - S : f + S, T.o[3][1] = u - k * m
                            }
                        }, extendPrototype([DynamicPropertyContainer], o), o
                    }(),
                    E = function () {
                        function m(o, f) {
                            this.v = shapePool.newElement(), this.v.setPathData(!0, 0), this.elem = o, this.comp = o.comp, this.data = f, this.frameId = -1, this.d = f.d, this.initDynamicPropertyContainer(o), f.sy === 1 ? (this.ir = PropertyFactory.getProp(o, f.ir, 0, 0, this), this.is = PropertyFactory.getProp(o, f.is, 0, .01, this), this.convertToPath = this.convertStarToPath) : this.convertToPath = this.convertPolygonToPath, this.pt = PropertyFactory.getProp(o, f.pt, 0, 0, this), this.p = PropertyFactory.getProp(o, f.p, 1, 0, this), this.r = PropertyFactory.getProp(o, f.r, 0, degToRads, this), this.or = PropertyFactory.getProp(o, f.or, 0, 0, this), this.os = PropertyFactory.getProp(o, f.os, 0, .01, this), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertToPath())
                        }
                        return m.prototype = {
                            reset: i,
                            getValue: function () {
                                this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertToPath())
                            },
                            convertStarToPath: function () {
                                var o = Math.floor(this.pt.v) * 2,
                                    f = Math.PI * 2 / o,
                                    u = !0,
                                    S = this.or.v,
                                    k = this.ir.v,
                                    C = this.os.v,
                                    T = this.is.v,
                                    B = 2 * Math.PI * S / (o * 2),
                                    D = 2 * Math.PI * k / (o * 2),
                                    H, L, U, Y, Z = -Math.PI / 2;
                                Z += this.r.v;
                                var V = this.data.d === 3 ? -1 : 1;
                                for (this.v._length = 0, H = 0; H < o; H += 1) {
                                    L = u ? S : k, U = u ? C : T, Y = u ? B : D;
                                    var I = L * Math.cos(Z),
                                        A = L * Math.sin(Z),
                                        R = I === 0 && A === 0 ? 0 : A / Math.sqrt(I * I + A * A),
                                        X = I === 0 && A === 0 ? 0 : -I / Math.sqrt(I * I + A * A);
                                    I += +this.p.v[0], A += +this.p.v[1], this.v.setTripleAt(I, A, I - R * Y * U * V, A - X * Y * U * V, I + R * Y * U * V, A + X * Y * U * V, H, !0), u = !u, Z += f * V
                                }
                            },
                            convertPolygonToPath: function () {
                                var o = Math.floor(this.pt.v),
                                    f = Math.PI * 2 / o,
                                    u = this.or.v,
                                    S = this.os.v,
                                    k = 2 * Math.PI * u / (o * 4),
                                    C, T = -Math.PI * .5,
                                    B = this.data.d === 3 ? -1 : 1;
                                for (T += this.r.v, this.v._length = 0, C = 0; C < o; C += 1) {
                                    var D = u * Math.cos(T),
                                        H = u * Math.sin(T),
                                        L = D === 0 && H === 0 ? 0 : H / Math.sqrt(D * D + H * H),
                                        U = D === 0 && H === 0 ? 0 : -D / Math.sqrt(D * D + H * H);
                                    D += +this.p.v[0], H += +this.p.v[1], this.v.setTripleAt(D, H, D - L * k * S * B, H - U * k * S * B, D + L * k * S * B, H + U * k * S * B, C, !0), T += f * B
                                }
                                this.paths.length = 0, this.paths[0] = this.v
                            }
                        }, extendPrototype([DynamicPropertyContainer], m), m
                    }(),
                    P = function () {
                        function m(o, f) {
                            this.v = shapePool.newElement(), this.v.c = !0, this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.elem = o, this.comp = o.comp, this.frameId = -1, this.d = f.d, this.initDynamicPropertyContainer(o), this.p = PropertyFactory.getProp(o, f.p, 1, 0, this), this.s = PropertyFactory.getProp(o, f.s, 1, 0, this), this.r = PropertyFactory.getProp(o, f.r, 0, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertRectToPath())
                        }
                        return m.prototype = {
                            convertRectToPath: function () {
                                var o = this.p.v[0],
                                    f = this.p.v[1],
                                    u = this.s.v[0] / 2,
                                    S = this.s.v[1] / 2,
                                    k = bmMin(u, S, this.r.v),
                                    C = k * (1 - roundCorner);
                                this.v._length = 0, this.d === 2 || this.d === 1 ? (this.v.setTripleAt(o + u, f - S + k, o + u, f - S + k, o + u, f - S + C, 0, !0), this.v.setTripleAt(o + u, f + S - k, o + u, f + S - C, o + u, f + S - k, 1, !0), k !== 0 ? (this.v.setTripleAt(o + u - k, f + S, o + u - k, f + S, o + u - C, f + S, 2, !0), this.v.setTripleAt(o - u + k, f + S, o - u + C, f + S, o - u + k, f + S, 3, !0), this.v.setTripleAt(o - u, f + S - k, o - u, f + S - k, o - u, f + S - C, 4, !0), this.v.setTripleAt(o - u, f - S + k, o - u, f - S + C, o - u, f - S + k, 5, !0), this.v.setTripleAt(o - u + k, f - S, o - u + k, f - S, o - u + C, f - S, 6, !0), this.v.setTripleAt(o + u - k, f - S, o + u - C, f - S, o + u - k, f - S, 7, !0)) : (this.v.setTripleAt(o - u, f + S, o - u + C, f + S, o - u, f + S, 2), this.v.setTripleAt(o - u, f - S, o - u, f - S + C, o - u, f - S, 3))) : (this.v.setTripleAt(o + u, f - S + k, o + u, f - S + C, o + u, f - S + k, 0, !0), k !== 0 ? (this.v.setTripleAt(o + u - k, f - S, o + u - k, f - S, o + u - C, f - S, 1, !0), this.v.setTripleAt(o - u + k, f - S, o - u + C, f - S, o - u + k, f - S, 2, !0), this.v.setTripleAt(o - u, f - S + k, o - u, f - S + k, o - u, f - S + C, 3, !0), this.v.setTripleAt(o - u, f + S - k, o - u, f + S - C, o - u, f + S - k, 4, !0), this.v.setTripleAt(o - u + k, f + S, o - u + k, f + S, o - u + C, f + S, 5, !0), this.v.setTripleAt(o + u - k, f + S, o + u - C, f + S, o + u - k, f + S, 6, !0), this.v.setTripleAt(o + u, f + S - k, o + u, f + S - k, o + u, f + S - C, 7, !0)) : (this.v.setTripleAt(o - u, f - S, o - u + C, f - S, o - u, f - S, 1, !0), this.v.setTripleAt(o - u, f + S, o - u, f + S - C, o - u, f + S, 2, !0), this.v.setTripleAt(o + u, f + S, o + u - C, f + S, o + u, f + S, 3, !0)))
                            },
                            getValue: function () {
                                this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertRectToPath())
                            },
                            reset: i
                        }, extendPrototype([DynamicPropertyContainer], m), m
                    }();

                function x(m, o, f) {
                    var u;
                    if (f === 3 || f === 4) {
                        var S = f === 3 ? o.pt : o.ks,
                            k = S.k;
                        k.length ? u = new g(m, o, f) : u = new l(m, o, f)
                    } else f === 5 ? u = new P(m, o) : f === 6 ? u = new _(m, o) : f === 7 && (u = new E(m, o));
                    return u.k && m.addDynamicProperty(u), u
                }

                function y() {
                    return l
                }

                function d() {
                    return g
                }
                var b = {};
                return b.getShapeProp = x, b.getConstructorFunction = y, b.getKeyframedConstructorFunction = d, b
            }(),
            ShapeModifiers = function () {
                var e = {},
                    t = {};
                e.registerModifier = r, e.getModifier = i;

                function r(s, n) {
                    t[s] || (t[s] = n)
                }

                function i(s, n, a) {
                    return new t[s](n, a)
                }
                return e
            }();

        function ShapeModifier() {}
        ShapeModifier.prototype.initModifierProperties = function () {}, ShapeModifier.prototype.addShapeToModifier = function () {}, ShapeModifier.prototype.addShape = function (e) {
            if (!this.closed) {
                e.sh.container.addDynamicProperty(e.sh);
                var t = {
                    shape: e.sh,
                    data: e,
                    localShapeCollection: shapeCollectionPool.newShapeCollection()
                };
                this.shapes.push(t), this.addShapeToModifier(t), this._isAnimated && e.setAsAnimated()
            }
        }, ShapeModifier.prototype.init = function (e, t) {
            this.shapes = [], this.elem = e, this.initDynamicPropertyContainer(e), this.initModifierProperties(e, t), this.frameId = initialDefaultFrame, this.closed = !1, this.k = !1, this.dynamicProperties.length ? this.k = !0 : this.getValue(!0)
        }, ShapeModifier.prototype.processKeys = function () {
            this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties())
        }, extendPrototype([DynamicPropertyContainer], ShapeModifier);

        function TrimModifier() {}
        extendPrototype([ShapeModifier], TrimModifier), TrimModifier.prototype.initModifierProperties = function (e, t) {
            this.s = PropertyFactory.getProp(e, t.s, 0, .01, this), this.e = PropertyFactory.getProp(e, t.e, 0, .01, this), this.o = PropertyFactory.getProp(e, t.o, 0, 0, this), this.sValue = 0, this.eValue = 0, this.getValue = this.processKeys, this.m = t.m, this._isAnimated = !!this.s.effectsSequence.length || !!this.e.effectsSequence.length || !!this.o.effectsSequence.length
        }, TrimModifier.prototype.addShapeToModifier = function (e) {
            e.pathsData = []
        }, TrimModifier.prototype.calculateShapeEdges = function (e, t, r, i, s) {
            var n = [];
            t <= 1 ? n.push({
                s: e,
                e: t
            }) : e >= 1 ? n.push({
                s: e - 1,
                e: t - 1
            }) : (n.push({
                s: e,
                e: 1
            }), n.push({
                s: 0,
                e: t - 1
            }));
            var a = [],
                l, c = n.length,
                g;
            for (l = 0; l < c; l += 1)
                if (g = n[l], !(g.e * s < i || g.s * s > i + r)) {
                    var _, E;
                    g.s * s <= i ? _ = 0 : _ = (g.s * s - i) / r, g.e * s >= i + r ? E = 1 : E = (g.e * s - i) / r, a.push([_, E])
                } return a.length || a.push([0, 0]), a
        }, TrimModifier.prototype.releasePathsData = function (e) {
            var t, r = e.length;
            for (t = 0; t < r; t += 1) segmentsLengthPool.release(e[t]);
            return e.length = 0, e
        }, TrimModifier.prototype.processShapes = function (e) {
            var t, r;
            if (this._mdf || e) {
                var i = this.o.v % 360 / 360;
                if (i < 0 && (i += 1), this.s.v > 1 ? t = 1 + i : this.s.v < 0 ? t = 0 + i : t = this.s.v + i, this.e.v > 1 ? r = 1 + i : this.e.v < 0 ? r = 0 + i : r = this.e.v + i, t > r) {
                    var s = t;
                    t = r, r = s
                }
                t = Math.round(t * 1e4) * 1e-4, r = Math.round(r * 1e4) * 1e-4, this.sValue = t, this.eValue = r
            } else t = this.sValue, r = this.eValue;
            var n, a, l = this.shapes.length,
                c, g, _, E, P, x = 0;
            if (r === t)
                for (a = 0; a < l; a += 1) this.shapes[a].localShapeCollection.releaseShapes(), this.shapes[a].shape._mdf = !0, this.shapes[a].shape.paths = this.shapes[a].localShapeCollection, this._mdf && (this.shapes[a].pathsData.length = 0);
            else if (r === 1 && t === 0 || r === 0 && t === 1) {
                if (this._mdf)
                    for (a = 0; a < l; a += 1) this.shapes[a].pathsData.length = 0, this.shapes[a].shape._mdf = !0
            } else {
                var y = [],
                    d, b;
                for (a = 0; a < l; a += 1)
                    if (d = this.shapes[a], !d.shape._mdf && !this._mdf && !e && this.m !== 2) d.shape.paths = d.localShapeCollection;
                    else {
                        if (n = d.shape.paths, g = n._length, P = 0, !d.shape._mdf && d.pathsData.length) P = d.totalShapeLength;
                        else {
                            for (_ = this.releasePathsData(d.pathsData), c = 0; c < g; c += 1) E = bez.getSegmentsLength(n.shapes[c]), _.push(E), P += E.totalLength;
                            d.totalShapeLength = P, d.pathsData = _
                        }
                        x += P, d.shape._mdf = !0
                    } var m = t,
                    o = r,
                    f = 0,
                    u;
                for (a = l - 1; a >= 0; a -= 1)
                    if (d = this.shapes[a], d.shape._mdf) {
                        for (b = d.localShapeCollection, b.releaseShapes(), this.m === 2 && l > 1 ? (u = this.calculateShapeEdges(t, r, d.totalShapeLength, f, x), f += d.totalShapeLength) : u = [[m, o]], g = u.length, c = 0; c < g; c += 1) {
                            m = u[c][0], o = u[c][1], y.length = 0, o <= 1 ? y.push({
                                s: d.totalShapeLength * m,
                                e: d.totalShapeLength * o
                            }) : m >= 1 ? y.push({
                                s: d.totalShapeLength * (m - 1),
                                e: d.totalShapeLength * (o - 1)
                            }) : (y.push({
                                s: d.totalShapeLength * m,
                                e: d.totalShapeLength
                            }), y.push({
                                s: 0,
                                e: d.totalShapeLength * (o - 1)
                            }));
                            var S = this.addShapes(d, y[0]);
                            if (y[0].s !== y[0].e) {
                                if (y.length > 1) {
                                    var k = d.shape.paths.shapes[d.shape.paths._length - 1];
                                    if (k.c) {
                                        var C = S.pop();
                                        this.addPaths(S, b), S = this.addShapes(d, y[1], C)
                                    } else this.addPaths(S, b), S = this.addShapes(d, y[1])
                                }
                                this.addPaths(S, b)
                            }
                        }
                        d.shape.paths = b
                    }
            }
        }, TrimModifier.prototype.addPaths = function (e, t) {
            var r, i = e.length;
            for (r = 0; r < i; r += 1) t.addShape(e[r])
        }, TrimModifier.prototype.addSegment = function (e, t, r, i, s, n, a) {
            s.setXYAt(t[0], t[1], "o", n), s.setXYAt(r[0], r[1], "i", n + 1), a && s.setXYAt(e[0], e[1], "v", n), s.setXYAt(i[0], i[1], "v", n + 1)
        }, TrimModifier.prototype.addSegmentFromArray = function (e, t, r, i) {
            t.setXYAt(e[1], e[5], "o", r), t.setXYAt(e[2], e[6], "i", r + 1), i && t.setXYAt(e[0], e[4], "v", r), t.setXYAt(e[3], e[7], "v", r + 1)
        }, TrimModifier.prototype.addShapes = function (e, t, r) {
            var i = e.pathsData,
                s = e.shape.paths.shapes,
                n, a = e.shape.paths._length,
                l, c, g = 0,
                _, E, P, x, y = [],
                d, b = !0;
            for (r ? (E = r._length, d = r._length) : (r = shapePool.newElement(), E = 0, d = 0), y.push(r), n = 0; n < a; n += 1) {
                for (P = i[n].lengths, r.c = s[n].c, c = s[n].c ? P.length : P.length + 1, l = 1; l < c; l += 1)
                    if (_ = P[l - 1], g + _.addedLength < t.s) g += _.addedLength, r.c = !1;
                    else if (g > t.e) {
                    r.c = !1;
                    break
                } else t.s <= g && t.e >= g + _.addedLength ? (this.addSegment(s[n].v[l - 1], s[n].o[l - 1], s[n].i[l], s[n].v[l], r, E, b), b = !1) : (x = bez.getNewSegment(s[n].v[l - 1], s[n].v[l], s[n].o[l - 1], s[n].i[l], (t.s - g) / _.addedLength, (t.e - g) / _.addedLength, P[l - 1]), this.addSegmentFromArray(x, r, E, b), b = !1, r.c = !1), g += _.addedLength, E += 1;
                if (s[n].c && P.length) {
                    if (_ = P[l - 1], g <= t.e) {
                        var m = P[l - 1].addedLength;
                        t.s <= g && t.e >= g + m ? (this.addSegment(s[n].v[l - 1], s[n].o[l - 1], s[n].i[0], s[n].v[0], r, E, b), b = !1) : (x = bez.getNewSegment(s[n].v[l - 1], s[n].v[0], s[n].o[l - 1], s[n].i[0], (t.s - g) / m, (t.e - g) / m, P[l - 1]), this.addSegmentFromArray(x, r, E, b), b = !1, r.c = !1)
                    } else r.c = !1;
                    g += _.addedLength, E += 1
                }
                if (r._length && (r.setXYAt(r.v[d][0], r.v[d][1], "i", d), r.setXYAt(r.v[r._length - 1][0], r.v[r._length - 1][1], "o", r._length - 1)), g > t.e) break;
                n < a - 1 && (r = shapePool.newElement(), b = !0, y.push(r), E = 0)
            }
            return y
        }, ShapeModifiers.registerModifier("tm", TrimModifier);

        function RoundCornersModifier() {}
        extendPrototype([ShapeModifier], RoundCornersModifier), RoundCornersModifier.prototype.initModifierProperties = function (e, t) {
            this.getValue = this.processKeys, this.rd = PropertyFactory.getProp(e, t.r, 0, null, this), this._isAnimated = !!this.rd.effectsSequence.length
        }, RoundCornersModifier.prototype.processPath = function (e, t) {
            var r = shapePool.newElement();
            r.c = e.c;
            var i, s = e._length,
                n, a, l, c, g, _, E = 0,
                P, x, y, d, b, m;
            for (i = 0; i < s; i += 1) n = e.v[i], l = e.o[i], a = e.i[i], n[0] === l[0] && n[1] === l[1] && n[0] === a[0] && n[1] === a[1] ? (i === 0 || i === s - 1) && !e.c ? (r.setTripleAt(n[0], n[1], l[0], l[1], a[0], a[1], E), E += 1) : (i === 0 ? c = e.v[s - 1] : c = e.v[i - 1], g = Math.sqrt(Math.pow(n[0] - c[0], 2) + Math.pow(n[1] - c[1], 2)), _ = g ? Math.min(g / 2, t) / g : 0, b = n[0] + (c[0] - n[0]) * _, P = b, m = n[1] - (n[1] - c[1]) * _, x = m, y = P - (P - n[0]) * roundCorner, d = x - (x - n[1]) * roundCorner, r.setTripleAt(P, x, y, d, b, m, E), E += 1, i === s - 1 ? c = e.v[0] : c = e.v[i + 1], g = Math.sqrt(Math.pow(n[0] - c[0], 2) + Math.pow(n[1] - c[1], 2)), _ = g ? Math.min(g / 2, t) / g : 0, y = n[0] + (c[0] - n[0]) * _, P = y, d = n[1] + (c[1] - n[1]) * _, x = d, b = P - (P - n[0]) * roundCorner, m = x - (x - n[1]) * roundCorner, r.setTripleAt(P, x, y, d, b, m, E), E += 1) : (r.setTripleAt(e.v[i][0], e.v[i][1], e.o[i][0], e.o[i][1], e.i[i][0], e.i[i][1], E), E += 1);
            return r
        }, RoundCornersModifier.prototype.processShapes = function (e) {
            var t, r, i = this.shapes.length,
                s, n, a = this.rd.v;
            if (a !== 0) {
                var l, c;
                for (r = 0; r < i; r += 1) {
                    if (l = this.shapes[r], c = l.localShapeCollection, !(!l.shape._mdf && !this._mdf && !e))
                        for (c.releaseShapes(), l.shape._mdf = !0, t = l.shape.paths.shapes, n = l.shape.paths._length, s = 0; s < n; s += 1) c.addShape(this.processPath(t[s], a));
                    l.shape.paths = l.localShapeCollection
                }
            }
            this.dynamicProperties.length || (this._mdf = !1)
        }, ShapeModifiers.registerModifier("rd", RoundCornersModifier);

        function PuckerAndBloatModifier() {}
        extendPrototype([ShapeModifier], PuckerAndBloatModifier), PuckerAndBloatModifier.prototype.initModifierProperties = function (e, t) {
            this.getValue = this.processKeys, this.amount = PropertyFactory.getProp(e, t.a, 0, null, this), this._isAnimated = !!this.amount.effectsSequence.length
        }, PuckerAndBloatModifier.prototype.processPath = function (e, t) {
            var r = t / 100,
                i = [0, 0],
                s = e._length,
                n = 0;
            for (n = 0; n < s; n += 1) i[0] += e.v[n][0], i[1] += e.v[n][1];
            i[0] /= s, i[1] /= s;
            var a = shapePool.newElement();
            a.c = e.c;
            var l, c, g, _, E, P;
            for (n = 0; n < s; n += 1) l = e.v[n][0] + (i[0] - e.v[n][0]) * r, c = e.v[n][1] + (i[1] - e.v[n][1]) * r, g = e.o[n][0] + (i[0] - e.o[n][0]) * -r, _ = e.o[n][1] + (i[1] - e.o[n][1]) * -r, E = e.i[n][0] + (i[0] - e.i[n][0]) * -r, P = e.i[n][1] + (i[1] - e.i[n][1]) * -r, a.setTripleAt(l, c, g, _, E, P, n);
            return a
        }, PuckerAndBloatModifier.prototype.processShapes = function (e) {
            var t, r, i = this.shapes.length,
                s, n, a = this.amount.v;
            if (a !== 0) {
                var l, c;
                for (r = 0; r < i; r += 1) {
                    if (l = this.shapes[r], c = l.localShapeCollection, !(!l.shape._mdf && !this._mdf && !e))
                        for (c.releaseShapes(), l.shape._mdf = !0, t = l.shape.paths.shapes, n = l.shape.paths._length, s = 0; s < n; s += 1) c.addShape(this.processPath(t[s], a));
                    l.shape.paths = l.localShapeCollection
                }
            }
            this.dynamicProperties.length || (this._mdf = !1)
        }, ShapeModifiers.registerModifier("pb", PuckerAndBloatModifier);

        function RepeaterModifier() {}
        extendPrototype([ShapeModifier], RepeaterModifier), RepeaterModifier.prototype.initModifierProperties = function (e, t) {
            this.getValue = this.processKeys, this.c = PropertyFactory.getProp(e, t.c, 0, null, this), this.o = PropertyFactory.getProp(e, t.o, 0, null, this), this.tr = TransformPropertyFactory.getTransformProperty(e, t.tr, this), this.so = PropertyFactory.getProp(e, t.tr.so, 0, .01, this), this.eo = PropertyFactory.getProp(e, t.tr.eo, 0, .01, this), this.data = t, this.dynamicProperties.length || this.getValue(!0), this._isAnimated = !!this.dynamicProperties.length, this.pMatrix = new Matrix, this.rMatrix = new Matrix, this.sMatrix = new Matrix, this.tMatrix = new Matrix, this.matrix = new Matrix
        }, RepeaterModifier.prototype.applyTransforms = function (e, t, r, i, s, n) {
            var a = n ? -1 : 1,
                l = i.s.v[0] + (1 - i.s.v[0]) * (1 - s),
                c = i.s.v[1] + (1 - i.s.v[1]) * (1 - s);
            e.translate(i.p.v[0] * a * s, i.p.v[1] * a * s, i.p.v[2]), t.translate(-i.a.v[0], -i.a.v[1], i.a.v[2]), t.rotate(-i.r.v * a * s), t.translate(i.a.v[0], i.a.v[1], i.a.v[2]), r.translate(-i.a.v[0], -i.a.v[1], i.a.v[2]), r.scale(n ? 1 / l : l, n ? 1 / c : c), r.translate(i.a.v[0], i.a.v[1], i.a.v[2])
        }, RepeaterModifier.prototype.init = function (e, t, r, i) {
            for (this.elem = e, this.arr = t, this.pos = r, this.elemsData = i, this._currentCopies = 0, this._elements = [], this._groups = [], this.frameId = -1, this.initDynamicPropertyContainer(e), this.initModifierProperties(e, t[r]); r > 0;) r -= 1, this._elements.unshift(t[r]);
            this.dynamicProperties.length ? this.k = !0 : this.getValue(!0)
        }, RepeaterModifier.prototype.resetElements = function (e) {
            var t, r = e.length;
            for (t = 0; t < r; t += 1) e[t]._processed = !1, e[t].ty === "gr" && this.resetElements(e[t].it)
        }, RepeaterModifier.prototype.cloneElements = function (e) {
            var t = JSON.parse(JSON.stringify(e));
            return this.resetElements(t), t
        }, RepeaterModifier.prototype.changeGroupRender = function (e, t) {
            var r, i = e.length;
            for (r = 0; r < i; r += 1) e[r]._render = t, e[r].ty === "gr" && this.changeGroupRender(e[r].it, t)
        }, RepeaterModifier.prototype.processShapes = function (e) {
            var t, r, i, s, n, a = !1;
            if (this._mdf || e) {
                var l = Math.ceil(this.c.v);
                if (this._groups.length < l) {
                    for (; this._groups.length < l;) {
                        var c = {
                            it: this.cloneElements(this._elements),
                            ty: "gr"
                        };
                        c.it.push({
                            a: {
                                a: 0,
                                ix: 1,
                                k: [0, 0]
                            },
                            nm: "Transform",
                            o: {
                                a: 0,
                                ix: 7,
                                k: 100
                            },
                            p: {
                                a: 0,
                                ix: 2,
                                k: [0, 0]
                            },
                            r: {
                                a: 1,
                                ix: 6,
                                k: [{
                                    s: 0,
                                    e: 0,
                                    t: 0
                                }, {
                                    s: 0,
                                    e: 0,
                                    t: 1
                                }]
                            },
                            s: {
                                a: 0,
                                ix: 3,
                                k: [100, 100]
                            },
                            sa: {
                                a: 0,
                                ix: 5,
                                k: 0
                            },
                            sk: {
                                a: 0,
                                ix: 4,
                                k: 0
                            },
                            ty: "tr"
                        }), this.arr.splice(0, 0, c), this._groups.splice(0, 0, c), this._currentCopies += 1
                    }
                    this.elem.reloadShapes(), a = !0
                }
                n = 0;
                var g;
                for (i = 0; i <= this._groups.length - 1; i += 1) {
                    if (g = n < l, this._groups[i]._render = g, this.changeGroupRender(this._groups[i].it, g), !g) {
                        var _ = this.elemsData[i].it,
                            E = _[_.length - 1];
                        E.transform.op.v !== 0 ? (E.transform.op._mdf = !0, E.transform.op.v = 0) : E.transform.op._mdf = !1
                    }
                    n += 1
                }
                this._currentCopies = l;
                var P = this.o.v,
                    x = P % 1,
                    y = P > 0 ? Math.floor(P) : Math.ceil(P),
                    d = this.pMatrix.props,
                    b = this.rMatrix.props,
                    m = this.sMatrix.props;
                this.pMatrix.reset(), this.rMatrix.reset(), this.sMatrix.reset(), this.tMatrix.reset(), this.matrix.reset();
                var o = 0;
                if (P > 0) {
                    for (; o < y;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), o += 1;
                    x && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, x, !1), o += x)
                } else if (P < 0) {
                    for (; o > y;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !0), o -= 1;
                    x && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, -x, !0), o -= x)
                }
                i = this.data.m === 1 ? 0 : this._currentCopies - 1, s = this.data.m === 1 ? 1 : -1, n = this._currentCopies;
                for (var f, u; n;) {
                    if (t = this.elemsData[i].it, r = t[t.length - 1].transform.mProps.v.props, u = r.length, t[t.length - 1].transform.mProps._mdf = !0, t[t.length - 1].transform.op._mdf = !0, t[t.length - 1].transform.op.v = this._currentCopies === 1 ? this.so.v : this.so.v + (this.eo.v - this.so.v) * (i / (this._currentCopies - 1)), o !== 0) {
                        for ((i !== 0 && s === 1 || i !== this._currentCopies - 1 && s === -1) && this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), this.matrix.transform(b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15]), this.matrix.transform(m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]), this.matrix.transform(d[0], d[1], d[2], d[3], d[4], d[5], d[6], d[7], d[8], d[9], d[10], d[11], d[12], d[13], d[14], d[15]), f = 0; f < u; f += 1) r[f] = this.matrix.props[f];
                        this.matrix.reset()
                    } else
                        for (this.matrix.reset(), f = 0; f < u; f += 1) r[f] = this.matrix.props[f];
                    o += 1, n -= 1, i += s
                }
            } else
                for (n = this._currentCopies, i = 0, s = 1; n;) t = this.elemsData[i].it, r = t[t.length - 1].transform.mProps.v.props, t[t.length - 1].transform.mProps._mdf = !1, t[t.length - 1].transform.op._mdf = !1, n -= 1, i += s;
            return a
        }, RepeaterModifier.prototype.addShape = function () {}, ShapeModifiers.registerModifier("rp", RepeaterModifier);

        function ShapeCollection() {
            this._length = 0, this._maxLength = 4, this.shapes = createSizedArray(this._maxLength)
        }
        ShapeCollection.prototype.addShape = function (e) {
            this._length === this._maxLength && (this.shapes = this.shapes.concat(createSizedArray(this._maxLength)), this._maxLength *= 2), this.shapes[this._length] = e, this._length += 1
        }, ShapeCollection.prototype.releaseShapes = function () {
            var e;
            for (e = 0; e < this._length; e += 1) shapePool.release(this.shapes[e]);
            this._length = 0
        };

        function DashProperty(e, t, r, i) {
            this.elem = e, this.frameId = -1, this.dataProps = createSizedArray(t.length), this.renderer = r, this.k = !1, this.dashStr = "", this.dashArray = createTypedArray("float32", t.length ? t.length - 1 : 0), this.dashoffset = createTypedArray("float32", 1), this.initDynamicPropertyContainer(i);
            var s, n = t.length || 0,
                a;
            for (s = 0; s < n; s += 1) a = PropertyFactory.getProp(e, t[s].v, 0, 0, this), this.k = a.k || this.k, this.dataProps[s] = {
                n: t[s].n,
                p: a
            };
            this.k || this.getValue(!0), this._isAnimated = this.k
        }
        DashProperty.prototype.getValue = function (e) {
            if (!(this.elem.globalData.frameId === this.frameId && !e) && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf = this._mdf || e, this._mdf)) {
                var t = 0,
                    r = this.dataProps.length;
                for (this.renderer === "svg" && (this.dashStr = ""), t = 0; t < r; t += 1) this.dataProps[t].n !== "o" ? this.renderer === "svg" ? this.dashStr += " " + this.dataProps[t].p.v : this.dashArray[t] = this.dataProps[t].p.v : this.dashoffset[0] = this.dataProps[t].p.v
            }
        }, extendPrototype([DynamicPropertyContainer], DashProperty);

        function GradientProperty(e, t, r) {
            this.data = t, this.c = createTypedArray("uint8c", t.p * 4);
            var i = t.k.k[0].s ? t.k.k[0].s.length - t.p * 4 : t.k.k.length - t.p * 4;
            this.o = createTypedArray("float32", i), this._cmdf = !1, this._omdf = !1, this._collapsable = this.checkCollapsable(), this._hasOpacity = i, this.initDynamicPropertyContainer(r), this.prop = PropertyFactory.getProp(e, t.k, 1, null, this), this.k = this.prop.k, this.getValue(!0)
        }
        GradientProperty.prototype.comparePoints = function (e, t) {
            for (var r = 0, i = this.o.length / 2, s; r < i;) {
                if (s = Math.abs(e[r * 4] - e[t * 4 + r * 2]), s > .01) return !1;
                r += 1
            }
            return !0
        }, GradientProperty.prototype.checkCollapsable = function () {
            if (this.o.length / 2 !== this.c.length / 4) return !1;
            if (this.data.k.k[0].s)
                for (var e = 0, t = this.data.k.k.length; e < t;) {
                    if (!this.comparePoints(this.data.k.k[e].s, this.data.p)) return !1;
                    e += 1
                } else if (!this.comparePoints(this.data.k.k, this.data.p)) return !1;
            return !0
        }, GradientProperty.prototype.getValue = function (e) {
            if (this.prop.getValue(), this._mdf = !1, this._cmdf = !1, this._omdf = !1, this.prop._mdf || e) {
                var t, r = this.data.p * 4,
                    i, s;
                for (t = 0; t < r; t += 1) i = t % 4 === 0 ? 100 : 255, s = Math.round(this.prop.v[t] * i), this.c[t] !== s && (this.c[t] = s, this._cmdf = !e);
                if (this.o.length)
                    for (r = this.prop.v.length, t = this.data.p * 4; t < r; t += 1) i = t % 2 === 0 ? 100 : 1, s = t % 2 === 0 ? Math.round(this.prop.v[t] * 100) : this.prop.v[t], this.o[t - this.data.p * 4] !== s && (this.o[t - this.data.p * 4] = s, this._omdf = !e);
                this._mdf = !e
            }
        }, extendPrototype([DynamicPropertyContainer], GradientProperty);
        var buildShapeString = function (e, t, r, i) {
                if (t === 0) return "";
                var s = e.o,
                    n = e.i,
                    a = e.v,
                    l, c = " M" + i.applyToPointStringified(a[0][0], a[0][1]);
                for (l = 1; l < t; l += 1) c += " C" + i.applyToPointStringified(s[l - 1][0], s[l - 1][1]) + " " + i.applyToPointStringified(n[l][0], n[l][1]) + " " + i.applyToPointStringified(a[l][0], a[l][1]);
                return r && t && (c += " C" + i.applyToPointStringified(s[l - 1][0], s[l - 1][1]) + " " + i.applyToPointStringified(n[0][0], n[0][1]) + " " + i.applyToPointStringified(a[0][0], a[0][1]), c += "z"), c
            },
            audioControllerFactory = function () {
                function e(t) {
                    this.audios = [], this.audioFactory = t, this._volume = 1, this._isMuted = !1
                }
                return e.prototype = {
                        addAudio: function (t) {
                            this.audios.push(t)
                        },
                        pause: function () {
                            var t, r = this.audios.length;
                            for (t = 0; t < r; t += 1) this.audios[t].pause()
                        },
                        resume: function () {
                            var t, r = this.audios.length;
                            for (t = 0; t < r; t += 1) this.audios[t].resume()
                        },
                        setRate: function (t) {
                            var r, i = this.audios.length;
                            for (r = 0; r < i; r += 1) this.audios[r].setRate(t)
                        },
                        createAudio: function (t) {
                            return this.audioFactory ? this.audioFactory(t) : Howl ? new Howl({
                                src: [t]
                            }) : {
                                isPlaying: !1,
                                play: function () {
                                    this.isPlaying = !0
                                },
                                seek: function () {
                                    this.isPlaying = !1
                                },
                                playing: function () {},
                                rate: function () {},
                                setVolume: function () {}
                            }
                        },
                        setAudioFactory: function (t) {
                            this.audioFactory = t
                        },
                        setVolume: function (t) {
                            this._volume = t, this._updateVolume()
                        },
                        mute: function () {
                            this._isMuted = !0, this._updateVolume()
                        },
                        unmute: function () {
                            this._isMuted = !1, this._updateVolume()
                        },
                        getVolume: function () {
                            return this._volume
                        },
                        _updateVolume: function () {
                            var t, r = this.audios.length;
                            for (t = 0; t < r; t += 1) this.audios[t].volume(this._volume * (this._isMuted ? 0 : 1))
                        }
                    },
                    function () {
                        return new e
                    }
            }(),
            ImagePreloader = function () {
                var e = function () {
                    var m = createTag("canvas");
                    m.width = 1, m.height = 1;
                    var o = m.getContext("2d");
                    return o.fillStyle = "rgba(0,0,0,0)", o.fillRect(0, 0, 1, 1), m
                }();

                function t() {
                    this.loadedAssets += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null)
                }

                function r() {
                    this.loadedFootagesCount += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null)
                }

                function i(m, o, f) {
                    var u = "";
                    if (m.e) u = m.p;
                    else if (o) {
                        var S = m.p;
                        S.indexOf("images/") !== -1 && (S = S.split("/")[1]), u = o + S
                    } else u = f, u += m.u ? m.u : "", u += m.p;
                    return u
                }

                function s(m) {
                    var o = 0,
                        f = setInterval((function () {
                            var u = m.getBBox();
                            (u.width || o > 500) && (this._imageLoaded(), clearInterval(f)), o += 1
                        }).bind(this), 50)
                }

                function n(m) {
                    var o = i(m, this.assetsPath, this.path),
                        f = createNS("image");
                    isSafari ? this.testImageLoaded(f) : f.addEventListener("load", this._imageLoaded, !1), f.addEventListener("error", (function () {
                        u.img = e, this._imageLoaded()
                    }).bind(this), !1), f.setAttributeNS("http://www.w3.org/1999/xlink", "href", o), this._elementHelper.append ? this._elementHelper.append(f) : this._elementHelper.appendChild(f);
                    var u = {
                        img: f,
                        assetData: m
                    };
                    return u
                }

                function a(m) {
                    var o = i(m, this.assetsPath, this.path),
                        f = createTag("img");
                    f.crossOrigin = "anonymous", f.addEventListener("load", this._imageLoaded, !1), f.addEventListener("error", (function () {
                        u.img = e, this._imageLoaded()
                    }).bind(this), !1), f.src = o;
                    var u = {
                        img: f,
                        assetData: m
                    };
                    return u
                }

                function l(m) {
                    var o = {
                            assetData: m
                        },
                        f = i(m, this.assetsPath, this.path);
                    return assetLoader.load(f, (function (u) {
                        o.img = u, this._footageLoaded()
                    }).bind(this), (function () {
                        o.img = {}, this._footageLoaded()
                    }).bind(this)), o
                }

                function c(m, o) {
                    this.imagesLoadedCb = o;
                    var f, u = m.length;
                    for (f = 0; f < u; f += 1) m[f].layers || (!m[f].t || m[f].t === "seq" ? (this.totalImages += 1, this.images.push(this._createImageData(m[f]))) : m[f].t === 3 && (this.totalFootages += 1, this.images.push(this.createFootageData(m[f]))))
                }

                function g(m) {
                    this.path = m || ""
                }

                function _(m) {
                    this.assetsPath = m || ""
                }

                function E(m) {
                    for (var o = 0, f = this.images.length; o < f;) {
                        if (this.images[o].assetData === m) return this.images[o].img;
                        o += 1
                    }
                    return null
                }

                function P() {
                    this.imagesLoadedCb = null, this.images.length = 0
                }

                function x() {
                    return this.totalImages === this.loadedAssets
                }

                function y() {
                    return this.totalFootages === this.loadedFootagesCount
                }

                function d(m, o) {
                    m === "svg" ? (this._elementHelper = o, this._createImageData = this.createImageData.bind(this)) : this._createImageData = this.createImgData.bind(this)
                }

                function b() {
                    this._imageLoaded = t.bind(this), this._footageLoaded = r.bind(this), this.testImageLoaded = s.bind(this), this.createFootageData = l.bind(this), this.assetsPath = "", this.path = "", this.totalImages = 0, this.totalFootages = 0, this.loadedAssets = 0, this.loadedFootagesCount = 0, this.imagesLoadedCb = null, this.images = []
                }
                return b.prototype = {
                    loadAssets: c,
                    setAssetsPath: _,
                    setPath: g,
                    loadedImages: x,
                    loadedFootages: y,
                    destroy: P,
                    getAsset: E,
                    createImgData: a,
                    createImageData: n,
                    imageLoaded: t,
                    footageLoaded: r,
                    setCacheType: d
                }, b
            }(),
            featureSupport = function () {
                var e = {
                    maskType: !0
                };
                return (/MSIE 10/i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /Edge\/\d./i.test(navigator.userAgent)) && (e.maskType = !1), e
            }(),
            filtersFactory = function () {
                var e = {};
                e.createFilter = t, e.createAlphaToLuminanceFilter = r;

                function t(i, s) {
                    var n = createNS("filter");
                    return n.setAttribute("id", i), s !== !0 && (n.setAttribute("filterUnits", "objectBoundingBox"), n.setAttribute("x", "0%"), n.setAttribute("y", "0%"), n.setAttribute("width", "100%"), n.setAttribute("height", "100%")), n
                }

                function r() {
                    var i = createNS("feColorMatrix");
                    return i.setAttribute("type", "matrix"), i.setAttribute("color-interpolation-filters", "sRGB"), i.setAttribute("values", "0 0 0 1 0  0 0 0 1 0  0 0 0 1 0  0 0 0 1 1"), i
                }
                return e
            }(),
            assetLoader = function () {
                function e(r) {
                    return r.response && typeof r.response == "object" ? r.response : r.response && typeof r.response == "string" ? JSON.parse(r.response) : r.responseText ? JSON.parse(r.responseText) : null
                }

                function t(r, i, s) {
                    var n, a = new XMLHttpRequest;
                    try {
                        a.responseType = "json"
                    } catch {}
                    a.onreadystatechange = function () {
                        if (a.readyState === 4)
                            if (a.status === 200) n = e(a), i(n);
                            else try {
                                n = e(a), i(n)
                            } catch (l) {
                                s && s(l)
                            }
                    }, a.open("GET", r, !0), a.send()
                }
                return {
                    load: t
                }
            }();

        function TextAnimatorProperty(e, t, r) {
            this._isFirstFrame = !0, this._hasMaskedPath = !1, this._frameId = -1, this._textData = e, this._renderType = t, this._elem = r, this._animatorsData = createSizedArray(this._textData.a.length), this._pathData = {}, this._moreOptions = {
                alignment: {}
            }, this.renderedLetters = [], this.lettersChangedFlag = !1, this.initDynamicPropertyContainer(r)
        }
        TextAnimatorProperty.prototype.searchProperties = function () {
            var e, t = this._textData.a.length,
                r, i = PropertyFactory.getProp;
            for (e = 0; e < t; e += 1) r = this._textData.a[e], this._animatorsData[e] = new TextAnimatorDataProperty(this._elem, r, this);
            this._textData.p && "m" in this._textData.p ? (this._pathData = {
                f: i(this._elem, this._textData.p.f, 0, 0, this),
                l: i(this._elem, this._textData.p.l, 0, 0, this),
                r: this._textData.p.r,
                m: this._elem.maskManager.getMaskProperty(this._textData.p.m)
            }, this._hasMaskedPath = !0) : this._hasMaskedPath = !1, this._moreOptions.alignment = i(this._elem, this._textData.m.a, 1, 0, this)
        }, TextAnimatorProperty.prototype.getMeasures = function (e, t) {
            if (this.lettersChangedFlag = t, !(!this._mdf && !this._isFirstFrame && !t && (!this._hasMaskedPath || !this._pathData.m._mdf))) {
                this._isFirstFrame = !1;
                var r = this._moreOptions.alignment.v,
                    i = this._animatorsData,
                    s = this._textData,
                    n = this.mHelper,
                    a = this._renderType,
                    l = this.renderedLetters.length,
                    c, g, _, E, P = e.l,
                    x, y, d, b, m, o, f, u, S, k, C, T, B, D, H;
                if (this._hasMaskedPath) {
                    if (H = this._pathData.m, !this._pathData.n || this._pathData._mdf) {
                        var L = H.v;
                        this._pathData.r && (L = L.reverse()), x = {
                            tLength: 0,
                            segments: []
                        }, E = L._length - 1;
                        var U;
                        for (T = 0, _ = 0; _ < E; _ += 1) U = bez.buildBezierData(L.v[_], L.v[_ + 1], [L.o[_][0] - L.v[_][0], L.o[_][1] - L.v[_][1]], [L.i[_ + 1][0] - L.v[_ + 1][0], L.i[_ + 1][1] - L.v[_ + 1][1]]), x.tLength += U.segmentLength, x.segments.push(U), T += U.segmentLength;
                        _ = E, H.v.c && (U = bez.buildBezierData(L.v[_], L.v[0], [L.o[_][0] - L.v[_][0], L.o[_][1] - L.v[_][1]], [L.i[0][0] - L.v[0][0], L.i[0][1] - L.v[0][1]]), x.tLength += U.segmentLength, x.segments.push(U), T += U.segmentLength), this._pathData.pi = x
                    }
                    if (x = this._pathData.pi, y = this._pathData.f.v, f = 0, o = 1, b = 0, m = !0, k = x.segments, y < 0 && H.v.c)
                        for (x.tLength < Math.abs(y) && (y = -Math.abs(y) % x.tLength), f = k.length - 1, S = k[f].points, o = S.length - 1; y < 0;) y += S[o].partialLength, o -= 1, o < 0 && (f -= 1, S = k[f].points, o = S.length - 1);
                    S = k[f].points, u = S[o - 1], d = S[o], C = d.partialLength
                }
                E = P.length, c = 0, g = 0;
                var Y = e.finalSize * 1.2 * .714,
                    Z = !0,
                    V, I, A, R, X;
                R = i.length;
                var O, ie = -1,
                    se, oe, fe, le = y,
                    pe = f,
                    me = o,
                    de = -1,
                    ue, ce, M, F, N, z, G, W, K = "",
                    j = this.defaultPropsArray,
                    q;
                if (e.j === 2 || e.j === 1) {
                    var $ = 0,
                        ee = 0,
                        J = e.j === 2 ? -.5 : -1,
                        Q = 0,
                        te = !0;
                    for (_ = 0; _ < E; _ += 1)
                        if (P[_].n) {
                            for ($ && ($ += ee); Q < _;) P[Q].animatorJustifyOffset = $, Q += 1;
                            $ = 0, te = !0
                        } else {
                            for (A = 0; A < R; A += 1) V = i[A].a, V.t.propType && (te && e.j === 2 && (ee += V.t.v * J), I = i[A].s, O = I.getMult(P[_].anIndexes[A], s.a[A].s.totalChars), O.length ? $ += V.t.v * O[0] * J : $ += V.t.v * O * J);
                            te = !1
                        } for ($ && ($ += ee); Q < _;) P[Q].animatorJustifyOffset = $, Q += 1
                }
                for (_ = 0; _ < E; _ += 1) {
                    if (n.reset(), ue = 1, P[_].n) c = 0, g += e.yOffset, g += Z ? 1 : 0, y = le, Z = !1, this._hasMaskedPath && (f = pe, o = me, S = k[f].points, u = S[o - 1], d = S[o], C = d.partialLength, b = 0), K = "", W = "", z = "", q = "", j = this.defaultPropsArray;
                    else {
                        if (this._hasMaskedPath) {
                            if (de !== P[_].line) {
                                switch (e.j) {
                                    case 1:
                                        y += T - e.lineWidths[P[_].line];
                                        break;
                                    case 2:
                                        y += (T - e.lineWidths[P[_].line]) / 2;
                                        break
                                }
                                de = P[_].line
                            }
                            ie !== P[_].ind && (P[ie] && (y += P[ie].extra), y += P[_].an / 2, ie = P[_].ind), y += r[0] * P[_].an * .005;
                            var re = 0;
                            for (A = 0; A < R; A += 1) V = i[A].a, V.p.propType && (I = i[A].s, O = I.getMult(P[_].anIndexes[A], s.a[A].s.totalChars), O.length ? re += V.p.v[0] * O[0] : re += V.p.v[0] * O), V.a.propType && (I = i[A].s, O = I.getMult(P[_].anIndexes[A], s.a[A].s.totalChars), O.length ? re += V.a.v[0] * O[0] : re += V.a.v[0] * O);
                            for (m = !0; m;) b + C >= y + re || !S ? (B = (y + re - b) / d.partialLength, oe = u.point[0] + (d.point[0] - u.point[0]) * B, fe = u.point[1] + (d.point[1] - u.point[1]) * B, n.translate(-r[0] * P[_].an * .005, -(r[1] * Y) * .01), m = !1) : S && (b += d.partialLength, o += 1, o >= S.length && (o = 0, f += 1, k[f] ? S = k[f].points : H.v.c ? (o = 0, f = 0, S = k[f].points) : (b -= d.partialLength, S = null)), S && (u = d, d = S[o], C = d.partialLength));
                            se = P[_].an / 2 - P[_].add, n.translate(-se, 0, 0)
                        } else se = P[_].an / 2 - P[_].add, n.translate(-se, 0, 0), n.translate(-r[0] * P[_].an * .005, -r[1] * Y * .01, 0);
                        for (A = 0; A < R; A += 1) V = i[A].a, V.t.propType && (I = i[A].s, O = I.getMult(P[_].anIndexes[A], s.a[A].s.totalChars), (c !== 0 || e.j !== 0) && (this._hasMaskedPath ? O.length ? y += V.t.v * O[0] : y += V.t.v * O : O.length ? c += V.t.v * O[0] : c += V.t.v * O));
                        for (e.strokeWidthAnim && (M = e.sw || 0), e.strokeColorAnim && (e.sc ? ce = [e.sc[0], e.sc[1], e.sc[2]] : ce = [0, 0, 0]), e.fillColorAnim && e.fc && (F = [e.fc[0], e.fc[1], e.fc[2]]), A = 0; A < R; A += 1) V = i[A].a, V.a.propType && (I = i[A].s, O = I.getMult(P[_].anIndexes[A], s.a[A].s.totalChars), O.length ? n.translate(-V.a.v[0] * O[0], -V.a.v[1] * O[1], V.a.v[2] * O[2]) : n.translate(-V.a.v[0] * O, -V.a.v[1] * O, V.a.v[2] * O));
                        for (A = 0; A < R; A += 1) V = i[A].a, V.s.propType && (I = i[A].s, O = I.getMult(P[_].anIndexes[A], s.a[A].s.totalChars), O.length ? n.scale(1 + (V.s.v[0] - 1) * O[0], 1 + (V.s.v[1] - 1) * O[1], 1) : n.scale(1 + (V.s.v[0] - 1) * O, 1 + (V.s.v[1] - 1) * O, 1));
                        for (A = 0; A < R; A += 1) {
                            if (V = i[A].a, I = i[A].s, O = I.getMult(P[_].anIndexes[A], s.a[A].s.totalChars), V.sk.propType && (O.length ? n.skewFromAxis(-V.sk.v * O[0], V.sa.v * O[1]) : n.skewFromAxis(-V.sk.v * O, V.sa.v * O)), V.r.propType && (O.length ? n.rotateZ(-V.r.v * O[2]) : n.rotateZ(-V.r.v * O)), V.ry.propType && (O.length ? n.rotateY(V.ry.v * O[1]) : n.rotateY(V.ry.v * O)), V.rx.propType && (O.length ? n.rotateX(V.rx.v * O[0]) : n.rotateX(V.rx.v * O)), V.o.propType && (O.length ? ue += (V.o.v * O[0] - ue) * O[0] : ue += (V.o.v * O - ue) * O), e.strokeWidthAnim && V.sw.propType && (O.length ? M += V.sw.v * O[0] : M += V.sw.v * O), e.strokeColorAnim && V.sc.propType)
                                for (N = 0; N < 3; N += 1) O.length ? ce[N] += (V.sc.v[N] - ce[N]) * O[0] : ce[N] += (V.sc.v[N] - ce[N]) * O;
                            if (e.fillColorAnim && e.fc) {
                                if (V.fc.propType)
                                    for (N = 0; N < 3; N += 1) O.length ? F[N] += (V.fc.v[N] - F[N]) * O[0] : F[N] += (V.fc.v[N] - F[N]) * O;
                                V.fh.propType && (O.length ? F = addHueToRGB(F, V.fh.v * O[0]) : F = addHueToRGB(F, V.fh.v * O)), V.fs.propType && (O.length ? F = addSaturationToRGB(F, V.fs.v * O[0]) : F = addSaturationToRGB(F, V.fs.v * O)), V.fb.propType && (O.length ? F = addBrightnessToRGB(F, V.fb.v * O[0]) : F = addBrightnessToRGB(F, V.fb.v * O))
                            }
                        }
                        for (A = 0; A < R; A += 1) V = i[A].a, V.p.propType && (I = i[A].s, O = I.getMult(P[_].anIndexes[A], s.a[A].s.totalChars), this._hasMaskedPath ? O.length ? n.translate(0, V.p.v[1] * O[0], -V.p.v[2] * O[1]) : n.translate(0, V.p.v[1] * O, -V.p.v[2] * O) : O.length ? n.translate(V.p.v[0] * O[0], V.p.v[1] * O[1], -V.p.v[2] * O[2]) : n.translate(V.p.v[0] * O, V.p.v[1] * O, -V.p.v[2] * O));
                        if (e.strokeWidthAnim && (z = M < 0 ? 0 : M), e.strokeColorAnim && (G = "rgb(" + Math.round(ce[0] * 255) + "," + Math.round(ce[1] * 255) + "," + Math.round(ce[2] * 255) + ")"), e.fillColorAnim && e.fc && (W = "rgb(" + Math.round(F[0] * 255) + "," + Math.round(F[1] * 255) + "," + Math.round(F[2] * 255) + ")"), this._hasMaskedPath) {
                            if (n.translate(0, -e.ls), n.translate(0, r[1] * Y * .01 + g, 0), s.p.p) {
                                D = (d.point[1] - u.point[1]) / (d.point[0] - u.point[0]);
                                var ne = Math.atan(D) * 180 / Math.PI;
                                d.point[0] < u.point[0] && (ne += 180), n.rotate(-ne * Math.PI / 180)
                            }
                            n.translate(oe, fe, 0), y -= r[0] * P[_].an * .005, P[_ + 1] && ie !== P[_ + 1].ind && (y += P[_].an / 2, y += e.tr * .001 * e.finalSize)
                        } else {
                            switch (n.translate(c, g, 0), e.ps && n.translate(e.ps[0], e.ps[1] + e.ascent, 0), e.j) {
                                case 1:
                                    n.translate(P[_].animatorJustifyOffset + e.justifyOffset + (e.boxWidth - e.lineWidths[P[_].line]), 0, 0);
                                    break;
                                case 2:
                                    n.translate(P[_].animatorJustifyOffset + e.justifyOffset + (e.boxWidth - e.lineWidths[P[_].line]) / 2, 0, 0);
                                    break
                            }
                            n.translate(0, -e.ls), n.translate(se, 0, 0), n.translate(r[0] * P[_].an * .005, r[1] * Y * .01, 0), c += P[_].l + e.tr * .001 * e.finalSize
                        }
                        a === "html" ? K = n.toCSS() : a === "svg" ? K = n.to2dCSS() : j = [n.props[0], n.props[1], n.props[2], n.props[3], n.props[4], n.props[5], n.props[6], n.props[7], n.props[8], n.props[9], n.props[10], n.props[11], n.props[12], n.props[13], n.props[14], n.props[15]], q = ue
                    }
                    l <= _ ? (X = new LetterProps(q, z, G, W, K, j), this.renderedLetters.push(X), l += 1, this.lettersChangedFlag = !0) : (X = this.renderedLetters[_], this.lettersChangedFlag = X.update(q, z, G, W, K, j) || this.lettersChangedFlag)
                }
            }
        }, TextAnimatorProperty.prototype.getValue = function () {
            this._elem.globalData.frameId !== this._frameId && (this._frameId = this._elem.globalData.frameId, this.iterateDynamicProperties())
        }, TextAnimatorProperty.prototype.mHelper = new Matrix, TextAnimatorProperty.prototype.defaultPropsArray = [], extendPrototype([DynamicPropertyContainer], TextAnimatorProperty);

        function TextAnimatorDataProperty(e, t, r) {
            var i = {
                    propType: !1
                },
                s = PropertyFactory.getProp,
                n = t.a;
            this.a = {
                r: n.r ? s(e, n.r, 0, degToRads, r) : i,
                rx: n.rx ? s(e, n.rx, 0, degToRads, r) : i,
                ry: n.ry ? s(e, n.ry, 0, degToRads, r) : i,
                sk: n.sk ? s(e, n.sk, 0, degToRads, r) : i,
                sa: n.sa ? s(e, n.sa, 0, degToRads, r) : i,
                s: n.s ? s(e, n.s, 1, .01, r) : i,
                a: n.a ? s(e, n.a, 1, 0, r) : i,
                o: n.o ? s(e, n.o, 0, .01, r) : i,
                p: n.p ? s(e, n.p, 1, 0, r) : i,
                sw: n.sw ? s(e, n.sw, 0, 0, r) : i,
                sc: n.sc ? s(e, n.sc, 1, 0, r) : i,
                fc: n.fc ? s(e, n.fc, 1, 0, r) : i,
                fh: n.fh ? s(e, n.fh, 0, 0, r) : i,
                fs: n.fs ? s(e, n.fs, 0, .01, r) : i,
                fb: n.fb ? s(e, n.fb, 0, .01, r) : i,
                t: n.t ? s(e, n.t, 0, 0, r) : i
            }, this.s = TextSelectorProp.getTextSelectorProp(e, t.s, r), this.s.t = t.s.t
        }

        function LetterProps(e, t, r, i, s, n) {
            this.o = e, this.sw = t, this.sc = r, this.fc = i, this.m = s, this.p = n, this._mdf = {
                o: !0,
                sw: !!t,
                sc: !!r,
                fc: !!i,
                m: !0,
                p: !0
            }
        }
        LetterProps.prototype.update = function (e, t, r, i, s, n) {
            this._mdf.o = !1, this._mdf.sw = !1, this._mdf.sc = !1, this._mdf.fc = !1, this._mdf.m = !1, this._mdf.p = !1;
            var a = !1;
            return this.o !== e && (this.o = e, this._mdf.o = !0, a = !0), this.sw !== t && (this.sw = t, this._mdf.sw = !0, a = !0), this.sc !== r && (this.sc = r, this._mdf.sc = !0, a = !0), this.fc !== i && (this.fc = i, this._mdf.fc = !0, a = !0), this.m !== s && (this.m = s, this._mdf.m = !0, a = !0), n.length && (this.p[0] !== n[0] || this.p[1] !== n[1] || this.p[4] !== n[4] || this.p[5] !== n[5] || this.p[12] !== n[12] || this.p[13] !== n[13]) && (this.p = n, this._mdf.p = !0, a = !0), a
        };

        function TextProperty(e, t) {
            this._frameId = initialDefaultFrame, this.pv = "", this.v = "", this.kf = !1, this._isFirstFrame = !0, this._mdf = !1, this.data = t, this.elem = e, this.comp = this.elem.comp, this.keysIndex = 0, this.canResize = !1, this.minimumFontSize = 1, this.effectsSequence = [], this.currentData = {
                ascent: 0,
                boxWidth: this.defaultBoxWidth,
                f: "",
                fStyle: "",
                fWeight: "",
                fc: "",
                j: "",
                justifyOffset: "",
                l: [],
                lh: 0,
                lineWidths: [],
                ls: "",
                of: "",
                s: "",
                sc: "",
                sw: 0,
                t: 0,
                tr: 0,
                sz: 0,
                ps: null,
                fillColorAnim: !1,
                strokeColorAnim: !1,
                strokeWidthAnim: !1,
                yOffset: 0,
                finalSize: 0,
                finalText: [],
                finalLineHeight: 0,
                __complete: !1
            }, this.copyData(this.currentData, this.data.d.k[0].s), this.searchProperty() || this.completeTextData(this.currentData)
        }
        TextProperty.prototype.defaultBoxWidth = [0, 0], TextProperty.prototype.copyData = function (e, t) {
            for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            return e
        }, TextProperty.prototype.setCurrentData = function (e) {
            e.__complete || this.completeTextData(e), this.currentData = e, this.currentData.boxWidth = this.currentData.boxWidth || this.defaultBoxWidth, this._mdf = !0
        }, TextProperty.prototype.searchProperty = function () {
            return this.searchKeyframes()
        }, TextProperty.prototype.searchKeyframes = function () {
            return this.kf = this.data.d.k.length > 1, this.kf && this.addEffect(this.getKeyframeValue.bind(this)), this.kf
        }, TextProperty.prototype.addEffect = function (e) {
            this.effectsSequence.push(e), this.elem.addDynamicProperty(this)
        }, TextProperty.prototype.getValue = function (e) {
            if (!((this.elem.globalData.frameId === this.frameId || !this.effectsSequence.length) && !e)) {
                this.currentData.t = this.data.d.k[this.keysIndex].s.t;
                var t = this.currentData,
                    r = this.keysIndex;
                if (this.lock) {
                    this.setCurrentData(this.currentData);
                    return
                }
                this.lock = !0, this._mdf = !1;
                var i, s = this.effectsSequence.length,
                    n = e || this.data.d.k[this.keysIndex].s;
                for (i = 0; i < s; i += 1) r !== this.keysIndex ? n = this.effectsSequence[i](n, n.t) : n = this.effectsSequence[i](this.currentData, n.t);
                t !== n && this.setCurrentData(n), this.v = this.currentData, this.pv = this.v, this.lock = !1, this.frameId = this.elem.globalData.frameId
            }
        }, TextProperty.prototype.getKeyframeValue = function () {
            for (var e = this.data.d.k, t = this.elem.comp.renderedFrame, r = 0, i = e.length; r <= i - 1 && !(r === i - 1 || e[r + 1].t > t);) r += 1;
            return this.keysIndex !== r && (this.keysIndex = r), this.data.d.k[this.keysIndex].s
        }, TextProperty.prototype.buildFinalText = function (e) {
            for (var t = [], r = 0, i = e.length, s, n, a = !1; r < i;) s = e.charCodeAt(r), FontManager.isCombinedCharacter(s) ? t[t.length - 1] += e.charAt(r) : s >= 55296 && s <= 56319 ? (n = e.charCodeAt(r + 1), n >= 56320 && n <= 57343 ? (a || FontManager.isModifier(s, n) ? (t[t.length - 1] += e.substr(r, 2), a = !1) : t.push(e.substr(r, 2)), r += 1) : t.push(e.charAt(r))) : s > 56319 ? (n = e.charCodeAt(r + 1), FontManager.isZeroWidthJoiner(s, n) ? (a = !0, t[t.length - 1] += e.substr(r, 2), r += 1) : t.push(e.charAt(r))) : FontManager.isZeroWidthJoiner(s) ? (t[t.length - 1] += e.charAt(r), a = !0) : t.push(e.charAt(r)), r += 1;
            return t
        }, TextProperty.prototype.completeTextData = function (e) {
            e.__complete = !0;
            var t = this.elem.globalData.fontManager,
                r = this.data,
                i = [],
                s, n, a, l = 0,
                c, g = r.m.g,
                _ = 0,
                E = 0,
                P = 0,
                x = [],
                y = 0,
                d = 0,
                b, m, o = t.getFontByName(e.f),
                f, u = 0,
                S = getFontProperties(o);
            e.fWeight = S.weight, e.fStyle = S.style, e.finalSize = e.s, e.finalText = this.buildFinalText(e.t), n = e.finalText.length, e.finalLineHeight = e.lh;
            var k = e.tr / 1e3 * e.finalSize,
                C;
            if (e.sz)
                for (var T = !0, B = e.sz[0], D = e.sz[1], H, L; T;) {
                    L = this.buildFinalText(e.t), H = 0, y = 0, n = L.length, k = e.tr / 1e3 * e.finalSize;
                    var U = -1;
                    for (s = 0; s < n; s += 1) C = L[s].charCodeAt(0), a = !1, L[s] === " " ? U = s : (C === 13 || C === 3) && (y = 0, a = !0, H += e.finalLineHeight || e.finalSize * 1.2), t.chars ? (f = t.getCharData(L[s], o.fStyle, o.fFamily), u = a ? 0 : f.w * e.finalSize / 100) : u = t.measureText(L[s], e.f, e.finalSize), y + u > B && L[s] !== " " ? (U === -1 ? n += 1 : s = U, H += e.finalLineHeight || e.finalSize * 1.2, L.splice(s, U === s ? 1 : 0, "\r"), U = -1, y = 0) : (y += u, y += k);
                    H += o.ascent * e.finalSize / 100, this.canResize && e.finalSize > this.minimumFontSize && D < H ? (e.finalSize -= 1, e.finalLineHeight = e.finalSize * e.lh / e.s) : (e.finalText = L, n = e.finalText.length, T = !1)
                }
            y = -k, u = 0;
            var Y = 0,
                Z;
            for (s = 0; s < n; s += 1)
                if (a = !1, Z = e.finalText[s], C = Z.charCodeAt(0), C === 13 || C === 3 ? (Y = 0, x.push(y), d = y > d ? y : d, y = -2 * k, c = "", a = !0, P += 1) : c = Z, t.chars ? (f = t.getCharData(Z, o.fStyle, t.getFontByName(e.f).fFamily), u = a ? 0 : f.w * e.finalSize / 100) : u = t.measureText(c, e.f, e.finalSize), Z === " " ? Y += u + k : (y += u + k + Y, Y = 0), i.push({
                        l: u,
                        an: u,
                        add: _,
                        n: a,
                        anIndexes: [],
                        val: c,
                        line: P,
                        animatorJustifyOffset: 0
                    }), g == 2) {
                    if (_ += u, c === "" || c === " " || s === n - 1) {
                        for ((c === "" || c === " ") && (_ -= u); E <= s;) i[E].an = _, i[E].ind = l, i[E].extra = u, E += 1;
                        l += 1, _ = 0
                    }
                } else if (g == 3) {
                if (_ += u, c === "" || s === n - 1) {
                    for (c === "" && (_ -= u); E <= s;) i[E].an = _, i[E].ind = l, i[E].extra = u, E += 1;
                    _ = 0, l += 1
                }
            } else i[l].ind = l, i[l].extra = 0, l += 1;
            if (e.l = i, d = y > d ? y : d, x.push(y), e.sz) e.boxWidth = e.sz[0], e.justifyOffset = 0;
            else switch (e.boxWidth = d, e.j) {
                case 1:
                    e.justifyOffset = -e.boxWidth;
                    break;
                case 2:
                    e.justifyOffset = -e.boxWidth / 2;
                    break;
                default:
                    e.justifyOffset = 0
            }
            e.lineWidths = x;
            var V = r.a,
                I, A;
            m = V.length;
            var R, X, O = [];
            for (b = 0; b < m; b += 1) {
                for (I = V[b], I.a.sc && (e.strokeColorAnim = !0), I.a.sw && (e.strokeWidthAnim = !0), (I.a.fc || I.a.fh || I.a.fs || I.a.fb) && (e.fillColorAnim = !0), X = 0, R = I.s.b, s = 0; s < n; s += 1) A = i[s], A.anIndexes[b] = X, (R == 1 && A.val !== "" || R == 2 && A.val !== "" && A.val !== " " || R == 3 && (A.n || A.val == " " || s == n - 1) || R == 4 && (A.n || s == n - 1)) && (I.s.rn === 1 && O.push(X), X += 1);
                r.a[b].s.totalChars = X;
                var ie = -1,
                    se;
                if (I.s.rn === 1)
                    for (s = 0; s < n; s += 1) A = i[s], ie != A.anIndexes[b] && (ie = A.anIndexes[b], se = O.splice(Math.floor(Math.random() * O.length), 1)[0]), A.anIndexes[b] = se
            }
            e.yOffset = e.finalLineHeight || e.finalSize * 1.2, e.ls = e.ls || 0, e.ascent = o.ascent * e.finalSize / 100
        }, TextProperty.prototype.updateDocumentData = function (e, t) {
            t = t === void 0 ? this.keysIndex : t;
            var r = this.copyData({}, this.data.d.k[t].s);
            r = this.copyData(r, e), this.data.d.k[t].s = r, this.recalculate(t), this.elem.addDynamicProperty(this)
        }, TextProperty.prototype.recalculate = function (e) {
            var t = this.data.d.k[e].s;
            t.__complete = !1, this.keysIndex = 0, this._isFirstFrame = !0, this.getValue(t)
        }, TextProperty.prototype.canResizeFont = function (e) {
            this.canResize = e, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this)
        }, TextProperty.prototype.setMinimumFontSize = function (e) {
            this.minimumFontSize = Math.floor(e) || 1, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this)
        };
        var TextSelectorProp = function () {
                var e = Math.max,
                    t = Math.min,
                    r = Math.floor;

                function i(n, a) {
                    this._currentTextLength = -1, this.k = !1, this.data = a, this.elem = n, this.comp = n.comp, this.finalS = 0, this.finalE = 0, this.initDynamicPropertyContainer(n), this.s = PropertyFactory.getProp(n, a.s || {
                        k: 0
                    }, 0, 0, this), "e" in a ? this.e = PropertyFactory.getProp(n, a.e, 0, 0, this) : this.e = {
                        v: 100
                    }, this.o = PropertyFactory.getProp(n, a.o || {
                        k: 0
                    }, 0, 0, this), this.xe = PropertyFactory.getProp(n, a.xe || {
                        k: 0
                    }, 0, 0, this), this.ne = PropertyFactory.getProp(n, a.ne || {
                        k: 0
                    }, 0, 0, this), this.a = PropertyFactory.getProp(n, a.a, 0, .01, this), this.dynamicProperties.length || this.getValue()
                }
                i.prototype = {
                    getMult: function (n) {
                        this._currentTextLength !== this.elem.textProperty.currentData.l.length && this.getValue();
                        var a = 0,
                            l = 0,
                            c = 1,
                            g = 1;
                        this.ne.v > 0 ? a = this.ne.v / 100 : l = -this.ne.v / 100, this.xe.v > 0 ? c = 1 - this.xe.v / 100 : g = 1 + this.xe.v / 100;
                        var _ = BezierFactory.getBezierEasing(a, l, c, g).get,
                            E = 0,
                            P = this.finalS,
                            x = this.finalE,
                            y = this.data.sh;
                        if (y === 2) x === P ? E = n >= x ? 1 : 0 : E = e(0, t(.5 / (x - P) + (n - P) / (x - P), 1)), E = _(E);
                        else if (y === 3) x === P ? E = n >= x ? 0 : 1 : E = 1 - e(0, t(.5 / (x - P) + (n - P) / (x - P), 1)), E = _(E);
                        else if (y === 4) x === P ? E = 0 : (E = e(0, t(.5 / (x - P) + (n - P) / (x - P), 1)), E < .5 ? E *= 2 : E = 1 - 2 * (E - .5)), E = _(E);
                        else if (y === 5) {
                            if (x === P) E = 0;
                            else {
                                var d = x - P;
                                n = t(e(0, n + .5 - P), x - P);
                                var b = -d / 2 + n,
                                    m = d / 2;
                                E = Math.sqrt(1 - b * b / (m * m))
                            }
                            E = _(E)
                        } else y === 6 ? (x === P ? E = 0 : (n = t(e(0, n + .5 - P), x - P), E = (1 + Math.cos(Math.PI + Math.PI * 2 * n / (x - P))) / 2), E = _(E)) : (n >= r(P) && (n - P < 0 ? E = e(0, t(t(x, 1) - (P - n), 1)) : E = e(0, t(x - n, 1))), E = _(E));
                        return E * this.a.v
                    },
                    getValue: function (n) {
                        this.iterateDynamicProperties(), this._mdf = n || this._mdf, this._currentTextLength = this.elem.textProperty.currentData.l.length || 0, n && this.data.r === 2 && (this.e.v = this._currentTextLength);
                        var a = this.data.r === 2 ? 1 : 100 / this.data.totalChars,
                            l = this.o.v / a,
                            c = this.s.v / a + l,
                            g = this.e.v / a + l;
                        if (c > g) {
                            var _ = c;
                            c = g, g = _
                        }
                        this.finalS = c, this.finalE = g
                    }
                }, extendPrototype([DynamicPropertyContainer], i);

                function s(n, a, l) {
                    return new i(n, a)
                }
                return {
                    getTextSelectorProp: s
                }
            }(),
            poolFactory = function () {
                return function (e, t, r) {
                    var i = 0,
                        s = e,
                        n = createSizedArray(s),
                        a = {
                            newElement: l,
                            release: c
                        };

                    function l() {
                        var g;
                        return i ? (i -= 1, g = n[i]) : g = t(), g
                    }

                    function c(g) {
                        i === s && (n = pooling.double(n), s *= 2), r && r(g), n[i] = g, i += 1
                    }
                    return a
                }
            }(),
            pooling = function () {
                function e(t) {
                    return t.concat(createSizedArray(t.length))
                }
                return {
                    double: e
                }
            }(),
            pointPool = function () {
                function e() {
                    return createTypedArray("float32", 2)
                }
                return poolFactory(8, e)
            }(),
            shapePool = function () {
                function e() {
                    return new ShapePath
                }

                function t(s) {
                    var n = s._length,
                        a;
                    for (a = 0; a < n; a += 1) pointPool.release(s.v[a]), pointPool.release(s.i[a]), pointPool.release(s.o[a]), s.v[a] = null, s.i[a] = null, s.o[a] = null;
                    s._length = 0, s.c = !1
                }

                function r(s) {
                    var n = i.newElement(),
                        a, l = s._length === void 0 ? s.v.length : s._length;
                    for (n.setLength(l), n.c = s.c, a = 0; a < l; a += 1) n.setTripleAt(s.v[a][0], s.v[a][1], s.o[a][0], s.o[a][1], s.i[a][0], s.i[a][1], a);
                    return n
                }
                var i = poolFactory(4, e, t);
                return i.clone = r, i
            }(),
            shapeCollectionPool = function () {
                var e = {
                        newShapeCollection: s,
                        release: n
                    },
                    t = 0,
                    r = 4,
                    i = createSizedArray(r);

                function s() {
                    var a;
                    return t ? (t -= 1, a = i[t]) : a = new ShapeCollection, a
                }

                function n(a) {
                    var l, c = a._length;
                    for (l = 0; l < c; l += 1) shapePool.release(a.shapes[l]);
                    a._length = 0, t === r && (i = pooling.double(i), r *= 2), i[t] = a, t += 1
                }
                return e
            }(),
            segmentsLengthPool = function () {
                function e() {
                    return {
                        lengths: [],
                        totalLength: 0
                    }
                }

                function t(r) {
                    var i, s = r.lengths.length;
                    for (i = 0; i < s; i += 1) bezierLengthPool.release(r.lengths[i]);
                    r.lengths.length = 0
                }
                return poolFactory(8, e, t)
            }(),
            bezierLengthPool = function () {
                function e() {
                    return {
                        addedLength: 0,
                        percents: createTypedArray("float32", defaultCurveSegments),
                        lengths: createTypedArray("float32", defaultCurveSegments)
                    }
                }
                return poolFactory(8, e)
            }(),
            markerParser = function () {
                function e(t) {
                    for (var r = t.split(`\r
`), i = {}, s, n = 0, a = 0; a < r.length; a += 1) s = r[a].split(":"), s.length === 2 && (i[s[0]] = s[1].trim(), n += 1);
                    if (n === 0) throw new Error;
                    return i
                }
                return function (t) {
                    for (var r = [], i = 0; i < t.length; i += 1) {
                        var s = t[i],
                            n = {
                                time: s.tm,
                                duration: s.dr
                            };
                        try {
                            n.payload = JSON.parse(t[i].cm)
                        } catch {
                            try {
                                n.payload = e(t[i].cm)
                            } catch {
                                n.payload = {
                                    name: t[i]
                                }
                            }
                        }
                        r.push(n)
                    }
                    return r
                }
            }();

        function BaseRenderer() {}
        BaseRenderer.prototype.checkLayers = function (e) {
            var t, r = this.layers.length,
                i;
            for (this.completeLayers = !0, t = r - 1; t >= 0; t -= 1) this.elements[t] || (i = this.layers[t], i.ip - i.st <= e - this.layers[t].st && i.op - i.st > e - this.layers[t].st && this.buildItem(t)), this.completeLayers = this.elements[t] ? this.completeLayers : !1;
            this.checkPendingElements()
        }, BaseRenderer.prototype.createItem = function (e) {
            switch (e.ty) {
                case 2:
                    return this.createImage(e);
                case 0:
                    return this.createComp(e);
                case 1:
                    return this.createSolid(e);
                case 3:
                    return this.createNull(e);
                case 4:
                    return this.createShape(e);
                case 5:
                    return this.createText(e);
                case 6:
                    return this.createAudio(e);
                case 13:
                    return this.createCamera(e);
                case 15:
                    return this.createFootage(e);
                default:
                    return this.createNull(e)
            }
        }, BaseRenderer.prototype.createCamera = function () {
            throw new Error("You're using a 3d camera. Try the html renderer.")
        }, BaseRenderer.prototype.createAudio = function (e) {
            return new AudioElement(e, this.globalData, this)
        }, BaseRenderer.prototype.createFootage = function (e) {
            return new FootageElement(e, this.globalData, this)
        }, BaseRenderer.prototype.buildAllItems = function () {
            var e, t = this.layers.length;
            for (e = 0; e < t; e += 1) this.buildItem(e);
            this.checkPendingElements()
        }, BaseRenderer.prototype.includeLayers = function (e) {
            this.completeLayers = !1;
            var t, r = e.length,
                i, s = this.layers.length;
            for (t = 0; t < r; t += 1)
                for (i = 0; i < s;) {
                    if (this.layers[i].id === e[t].id) {
                        this.layers[i] = e[t];
                        break
                    }
                    i += 1
                }
        }, BaseRenderer.prototype.setProjectInterface = function (e) {
            this.globalData.projectInterface = e
        }, BaseRenderer.prototype.initItems = function () {
            this.globalData.progressiveLoad || this.buildAllItems()
        }, BaseRenderer.prototype.buildElementParenting = function (e, t, r) {
            for (var i = this.elements, s = this.layers, n = 0, a = s.length; n < a;) s[n].ind == t && (!i[n] || i[n] === !0 ? (this.buildItem(n), this.addPendingElement(e)) : (r.push(i[n]), i[n].setAsParent(), s[n].parent !== void 0 ? this.buildElementParenting(e, s[n].parent, r) : e.setHierarchy(r))), n += 1
        }, BaseRenderer.prototype.addPendingElement = function (e) {
            this.pendingElements.push(e)
        }, BaseRenderer.prototype.searchExtraCompositions = function (e) {
            var t, r = e.length;
            for (t = 0; t < r; t += 1)
                if (e[t].xt) {
                    var i = this.createComp(e[t]);
                    i.initExpressions(), this.globalData.projectInterface.registerComposition(i)
                }
        }, BaseRenderer.prototype.setupGlobalData = function (e, t) {
            this.globalData.fontManager = new FontManager, this.globalData.fontManager.addChars(e.chars), this.globalData.fontManager.addFonts(e.fonts, t), this.globalData.getAssetData = this.animationItem.getAssetData.bind(this.animationItem), this.globalData.getAssetsPath = this.animationItem.getAssetsPath.bind(this.animationItem), this.globalData.imageLoader = this.animationItem.imagePreloader, this.globalData.audioController = this.animationItem.audioController, this.globalData.frameId = 0, this.globalData.frameRate = e.fr, this.globalData.nm = e.nm, this.globalData.compSize = {
                w: e.w,
                h: e.h
            }
        };

        function SVGRenderer(e, t) {
            this.animationItem = e, this.layers = null, this.renderedFrame = -1, this.svgElement = createNS("svg");
            var r = "";
            if (t && t.title) {
                var i = createNS("title"),
                    s = createElementID();
                i.setAttribute("id", s), i.textContent = t.title, this.svgElement.appendChild(i), r += s
            }
            if (t && t.description) {
                var n = createNS("desc"),
                    a = createElementID();
                n.setAttribute("id", a), n.textContent = t.description, this.svgElement.appendChild(n), r += " " + a
            }
            r && this.svgElement.setAttribute("aria-labelledby", r);
            var l = createNS("defs");
            this.svgElement.appendChild(l);
            var c = createNS("g");
            this.svgElement.appendChild(c), this.layerElement = c, this.renderConfig = {
                preserveAspectRatio: t && t.preserveAspectRatio || "xMidYMid meet",
                imagePreserveAspectRatio: t && t.imagePreserveAspectRatio || "xMidYMid slice",
                progressiveLoad: t && t.progressiveLoad || !1,
                hideOnTransparent: !(t && t.hideOnTransparent === !1),
                viewBoxOnly: t && t.viewBoxOnly || !1,
                viewBoxSize: t && t.viewBoxSize || !1,
                className: t && t.className || "",
                id: t && t.id || "",
                focusable: t && t.focusable,
                filterSize: {
                    width: t && t.filterSize && t.filterSize.width || "100%",
                    height: t && t.filterSize && t.filterSize.height || "100%",
                    x: t && t.filterSize && t.filterSize.x || "0%",
                    y: t && t.filterSize && t.filterSize.y || "0%"
                }
            }, this.globalData = {
                _mdf: !1,
                frameNum: -1,
                defs: l,
                renderConfig: this.renderConfig
            }, this.elements = [], this.pendingElements = [], this.destroyed = !1, this.rendererType = "svg"
        }
        extendPrototype([BaseRenderer], SVGRenderer), SVGRenderer.prototype.createNull = function (e) {
            return new NullElement(e, this.globalData, this)
        }, SVGRenderer.prototype.createShape = function (e) {
            return new SVGShapeElement(e, this.globalData, this)
        }, SVGRenderer.prototype.createText = function (e) {
            return new SVGTextLottieElement(e, this.globalData, this)
        }, SVGRenderer.prototype.createImage = function (e) {
            return new IImageElement(e, this.globalData, this)
        }, SVGRenderer.prototype.createComp = function (e) {
            return new SVGCompElement(e, this.globalData, this)
        }, SVGRenderer.prototype.createSolid = function (e) {
            return new ISolidElement(e, this.globalData, this)
        }, SVGRenderer.prototype.configAnimation = function (e) {
            this.svgElement.setAttribute("xmlns", "http://www.w3.org/2000/svg"), this.renderConfig.viewBoxSize ? this.svgElement.setAttribute("viewBox", this.renderConfig.viewBoxSize) : this.svgElement.setAttribute("viewBox", "0 0 " + e.w + " " + e.h), this.renderConfig.viewBoxOnly || (this.svgElement.setAttribute("width", e.w), this.svgElement.setAttribute("height", e.h), this.svgElement.style.width = "100%", this.svgElement.style.height = "100%", this.svgElement.style.transform = "translate3d(0,0,0)"), this.renderConfig.className && this.svgElement.setAttribute("class", this.renderConfig.className), this.renderConfig.id && this.svgElement.setAttribute("id", this.renderConfig.id), this.renderConfig.focusable !== void 0 && this.svgElement.setAttribute("focusable", this.renderConfig.focusable), this.svgElement.setAttribute("preserveAspectRatio", this.renderConfig.preserveAspectRatio), this.animationItem.wrapper.appendChild(this.svgElement);
            var t = this.globalData.defs;
            this.setupGlobalData(e, t), this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.data = e;
            var r = createNS("clipPath"),
                i = createNS("rect");
            i.setAttribute("width", e.w), i.setAttribute("height", e.h), i.setAttribute("x", 0), i.setAttribute("y", 0);
            var s = createElementID();
            r.setAttribute("id", s), r.appendChild(i), this.layerElement.setAttribute("clip-path", "url(" + locationHref + "#" + s + ")"), t.appendChild(r), this.layers = e.layers, this.elements = createSizedArray(e.layers.length)
        }, SVGRenderer.prototype.destroy = function () {
            this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), this.layerElement = null, this.globalData.defs = null;
            var e, t = this.layers ? this.layers.length : 0;
            for (e = 0; e < t; e += 1) this.elements[e] && this.elements[e].destroy();
            this.elements.length = 0, this.destroyed = !0, this.animationItem = null
        }, SVGRenderer.prototype.updateContainerSize = function () {}, SVGRenderer.prototype.buildItem = function (e) {
            var t = this.elements;
            if (!(t[e] || this.layers[e].ty === 99)) {
                t[e] = !0;
                var r = this.createItem(this.layers[e]);
                t[e] = r, expressionsPlugin && (this.layers[e].ty === 0 && this.globalData.projectInterface.registerComposition(r), r.initExpressions()), this.appendElementInPos(r, e), this.layers[e].tt && (!this.elements[e - 1] || this.elements[e - 1] === !0 ? (this.buildItem(e - 1), this.addPendingElement(r)) : r.setMatte(t[e - 1].layerId))
            }
        }, SVGRenderer.prototype.checkPendingElements = function () {
            for (; this.pendingElements.length;) {
                var e = this.pendingElements.pop();
                if (e.checkParenting(), e.data.tt)
                    for (var t = 0, r = this.elements.length; t < r;) {
                        if (this.elements[t] === e) {
                            e.setMatte(this.elements[t - 1].layerId);
                            break
                        }
                        t += 1
                    }
            }
        }, SVGRenderer.prototype.renderFrame = function (e) {
            if (!(this.renderedFrame === e || this.destroyed)) {
                e === null ? e = this.renderedFrame : this.renderedFrame = e, this.globalData.frameNum = e, this.globalData.frameId += 1, this.globalData.projectInterface.currentFrame = e, this.globalData._mdf = !1;
                var t, r = this.layers.length;
                for (this.completeLayers || this.checkLayers(e), t = r - 1; t >= 0; t -= 1)(this.completeLayers || this.elements[t]) && this.elements[t].prepareFrame(e - this.layers[t].st);
                if (this.globalData._mdf)
                    for (t = 0; t < r; t += 1)(this.completeLayers || this.elements[t]) && this.elements[t].renderFrame()
            }
        }, SVGRenderer.prototype.appendElementInPos = function (e, t) {
            var r = e.getBaseElement();
            if (r) {
                for (var i = 0, s; i < t;) this.elements[i] && this.elements[i] !== !0 && this.elements[i].getBaseElement() && (s = this.elements[i].getBaseElement()), i += 1;
                s ? this.layerElement.insertBefore(r, s) : this.layerElement.appendChild(r)
            }
        }, SVGRenderer.prototype.hide = function () {
            this.layerElement.style.display = "none"
        }, SVGRenderer.prototype.show = function () {
            this.layerElement.style.display = "block"
        };

        function CanvasRenderer(e, t) {
            this.animationItem = e, this.renderConfig = {
                clearCanvas: t && t.clearCanvas !== void 0 ? t.clearCanvas : !0,
                context: t && t.context || null,
                progressiveLoad: t && t.progressiveLoad || !1,
                preserveAspectRatio: t && t.preserveAspectRatio || "xMidYMid meet",
                imagePreserveAspectRatio: t && t.imagePreserveAspectRatio || "xMidYMid slice",
                className: t && t.className || "",
                id: t && t.id || ""
            }, this.renderConfig.dpr = t && t.dpr || 1, this.animationItem.wrapper && (this.renderConfig.dpr = t && t.dpr || window.devicePixelRatio || 1), this.renderedFrame = -1, this.globalData = {
                frameNum: -1,
                _mdf: !1,
                renderConfig: this.renderConfig,
                currentGlobalAlpha: -1
            }, this.contextData = new CVContextData, this.elements = [], this.pendingElements = [], this.transformMat = new Matrix, this.completeLayers = !1, this.rendererType = "canvas"
        }
        extendPrototype([BaseRenderer], CanvasRenderer), CanvasRenderer.prototype.createShape = function (e) {
            return new CVShapeElement(e, this.globalData, this)
        }, CanvasRenderer.prototype.createText = function (e) {
            return new CVTextElement(e, this.globalData, this)
        }, CanvasRenderer.prototype.createImage = function (e) {
            return new CVImageElement(e, this.globalData, this)
        }, CanvasRenderer.prototype.createComp = function (e) {
            return new CVCompElement(e, this.globalData, this)
        }, CanvasRenderer.prototype.createSolid = function (e) {
            return new CVSolidElement(e, this.globalData, this)
        }, CanvasRenderer.prototype.createNull = SVGRenderer.prototype.createNull, CanvasRenderer.prototype.ctxTransform = function (e) {
            if (!(e[0] === 1 && e[1] === 0 && e[4] === 0 && e[5] === 1 && e[12] === 0 && e[13] === 0)) {
                if (!this.renderConfig.clearCanvas) {
                    this.canvasContext.transform(e[0], e[1], e[4], e[5], e[12], e[13]);
                    return
                }
                this.transformMat.cloneFromProps(e);
                var t = this.contextData.cTr.props;
                this.transformMat.transform(t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], t[9], t[10], t[11], t[12], t[13], t[14], t[15]), this.contextData.cTr.cloneFromProps(this.transformMat.props);
                var r = this.contextData.cTr.props;
                this.canvasContext.setTransform(r[0], r[1], r[4], r[5], r[12], r[13])
            }
        }, CanvasRenderer.prototype.ctxOpacity = function (e) {
            if (!this.renderConfig.clearCanvas) {
                this.canvasContext.globalAlpha *= e < 0 ? 0 : e, this.globalData.currentGlobalAlpha = this.contextData.cO;
                return
            }
            this.contextData.cO *= e < 0 ? 0 : e, this.globalData.currentGlobalAlpha !== this.contextData.cO && (this.canvasContext.globalAlpha = this.contextData.cO, this.globalData.currentGlobalAlpha = this.contextData.cO)
        }, CanvasRenderer.prototype.reset = function () {
            if (!this.renderConfig.clearCanvas) {
                this.canvasContext.restore();
                return
            }
            this.contextData.reset()
        }, CanvasRenderer.prototype.save = function (e) {
            if (!this.renderConfig.clearCanvas) {
                this.canvasContext.save();
                return
            }
            e && this.canvasContext.save();
            var t = this.contextData.cTr.props;
            this.contextData._length <= this.contextData.cArrPos && this.contextData.duplicate();
            var r, i = this.contextData.saved[this.contextData.cArrPos];
            for (r = 0; r < 16; r += 1) i[r] = t[r];
            this.contextData.savedOp[this.contextData.cArrPos] = this.contextData.cO, this.contextData.cArrPos += 1
        }, CanvasRenderer.prototype.restore = function (e) {
            if (!this.renderConfig.clearCanvas) {
                this.canvasContext.restore();
                return
            }
            e && (this.canvasContext.restore(), this.globalData.blendMode = "source-over"), this.contextData.cArrPos -= 1;
            var t = this.contextData.saved[this.contextData.cArrPos],
                r, i = this.contextData.cTr.props;
            for (r = 0; r < 16; r += 1) i[r] = t[r];
            this.canvasContext.setTransform(t[0], t[1], t[4], t[5], t[12], t[13]), t = this.contextData.savedOp[this.contextData.cArrPos], this.contextData.cO = t, this.globalData.currentGlobalAlpha !== t && (this.canvasContext.globalAlpha = t, this.globalData.currentGlobalAlpha = t)
        }, CanvasRenderer.prototype.configAnimation = function (e) {
            if (this.animationItem.wrapper) {
                this.animationItem.container = createTag("canvas");
                var t = this.animationItem.container.style;
                t.width = "100%", t.height = "100%";
                var r = "0px 0px 0px";
                t.transformOrigin = r, t.mozTransformOrigin = r, t.webkitTransformOrigin = r, t["-webkit-transform"] = r, this.animationItem.wrapper.appendChild(this.animationItem.container), this.canvasContext = this.animationItem.container.getContext("2d"), this.renderConfig.className && this.animationItem.container.setAttribute("class", this.renderConfig.className), this.renderConfig.id && this.animationItem.container.setAttribute("id", this.renderConfig.id)
            } else this.canvasContext = this.renderConfig.context;
            this.data = e, this.layers = e.layers, this.transformCanvas = {
                w: e.w,
                h: e.h,
                sx: 0,
                sy: 0,
                tx: 0,
                ty: 0
            }, this.setupGlobalData(e, document.body), this.globalData.canvasContext = this.canvasContext, this.globalData.renderer = this, this.globalData.isDashed = !1, this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.globalData.transformCanvas = this.transformCanvas, this.elements = createSizedArray(e.layers.length), this.updateContainerSize()
        }, CanvasRenderer.prototype.updateContainerSize = function () {
            this.reset();
            var e, t;
            this.animationItem.wrapper && this.animationItem.container ? (e = this.animationItem.wrapper.offsetWidth, t = this.animationItem.wrapper.offsetHeight, this.animationItem.container.setAttribute("width", e * this.renderConfig.dpr), this.animationItem.container.setAttribute("height", t * this.renderConfig.dpr)) : (e = this.canvasContext.canvas.width * this.renderConfig.dpr, t = this.canvasContext.canvas.height * this.renderConfig.dpr);
            var r, i;
            if (this.renderConfig.preserveAspectRatio.indexOf("meet") !== -1 || this.renderConfig.preserveAspectRatio.indexOf("slice") !== -1) {
                var s = this.renderConfig.preserveAspectRatio.split(" "),
                    n = s[1] || "meet",
                    a = s[0] || "xMidYMid",
                    l = a.substr(0, 4),
                    c = a.substr(4);
                r = e / t, i = this.transformCanvas.w / this.transformCanvas.h, i > r && n === "meet" || i < r && n === "slice" ? (this.transformCanvas.sx = e / (this.transformCanvas.w / this.renderConfig.dpr), this.transformCanvas.sy = e / (this.transformCanvas.w / this.renderConfig.dpr)) : (this.transformCanvas.sx = t / (this.transformCanvas.h / this.renderConfig.dpr), this.transformCanvas.sy = t / (this.transformCanvas.h / this.renderConfig.dpr)), l === "xMid" && (i < r && n === "meet" || i > r && n === "slice") ? this.transformCanvas.tx = (e - this.transformCanvas.w * (t / this.transformCanvas.h)) / 2 * this.renderConfig.dpr : l === "xMax" && (i < r && n === "meet" || i > r && n === "slice") ? this.transformCanvas.tx = (e - this.transformCanvas.w * (t / this.transformCanvas.h)) * this.renderConfig.dpr : this.transformCanvas.tx = 0, c === "YMid" && (i > r && n === "meet" || i < r && n === "slice") ? this.transformCanvas.ty = (t - this.transformCanvas.h * (e / this.transformCanvas.w)) / 2 * this.renderConfig.dpr : c === "YMax" && (i > r && n === "meet" || i < r && n === "slice") ? this.transformCanvas.ty = (t - this.transformCanvas.h * (e / this.transformCanvas.w)) * this.renderConfig.dpr : this.transformCanvas.ty = 0
            } else this.renderConfig.preserveAspectRatio === "none" ? (this.transformCanvas.sx = e / (this.transformCanvas.w / this.renderConfig.dpr), this.transformCanvas.sy = t / (this.transformCanvas.h / this.renderConfig.dpr), this.transformCanvas.tx = 0, this.transformCanvas.ty = 0) : (this.transformCanvas.sx = this.renderConfig.dpr, this.transformCanvas.sy = this.renderConfig.dpr, this.transformCanvas.tx = 0, this.transformCanvas.ty = 0);
            this.transformCanvas.props = [this.transformCanvas.sx, 0, 0, 0, 0, this.transformCanvas.sy, 0, 0, 0, 0, 1, 0, this.transformCanvas.tx, this.transformCanvas.ty, 0, 1], this.ctxTransform(this.transformCanvas.props), this.canvasContext.beginPath(), this.canvasContext.rect(0, 0, this.transformCanvas.w, this.transformCanvas.h), this.canvasContext.closePath(), this.canvasContext.clip(), this.renderFrame(this.renderedFrame, !0)
        }, CanvasRenderer.prototype.destroy = function () {
            this.renderConfig.clearCanvas && this.animationItem.wrapper && (this.animationItem.wrapper.innerText = "");
            var e, t = this.layers ? this.layers.length : 0;
            for (e = t - 1; e >= 0; e -= 1) this.elements[e] && this.elements[e].destroy();
            this.elements.length = 0, this.globalData.canvasContext = null, this.animationItem.container = null, this.destroyed = !0
        }, CanvasRenderer.prototype.renderFrame = function (e, t) {
            if (!(this.renderedFrame === e && this.renderConfig.clearCanvas === !0 && !t || this.destroyed || e === -1)) {
                this.renderedFrame = e, this.globalData.frameNum = e - this.animationItem._isFirstFrame, this.globalData.frameId += 1, this.globalData._mdf = !this.renderConfig.clearCanvas || t, this.globalData.projectInterface.currentFrame = e;
                var r, i = this.layers.length;
                for (this.completeLayers || this.checkLayers(e), r = 0; r < i; r += 1)(this.completeLayers || this.elements[r]) && this.elements[r].prepareFrame(e - this.layers[r].st);
                if (this.globalData._mdf) {
                    for (this.renderConfig.clearCanvas === !0 ? this.canvasContext.clearRect(0, 0, this.transformCanvas.w, this.transformCanvas.h) : this.save(), r = i - 1; r >= 0; r -= 1)(this.completeLayers || this.elements[r]) && this.elements[r].renderFrame();
                    this.renderConfig.clearCanvas !== !0 && this.restore()
                }
            }
        }, CanvasRenderer.prototype.buildItem = function (e) {
            var t = this.elements;
            if (!(t[e] || this.layers[e].ty === 99)) {
                var r = this.createItem(this.layers[e], this, this.globalData);
                t[e] = r, r.initExpressions()
            }
        }, CanvasRenderer.prototype.checkPendingElements = function () {
            for (; this.pendingElements.length;) {
                var e = this.pendingElements.pop();
                e.checkParenting()
            }
        }, CanvasRenderer.prototype.hide = function () {
            this.animationItem.container.style.display = "none"
        }, CanvasRenderer.prototype.show = function () {
            this.animationItem.container.style.display = "block"
        };

        function HybridRenderer(e, t) {
            this.animationItem = e, this.layers = null, this.renderedFrame = -1, this.renderConfig = {
                className: t && t.className || "",
                imagePreserveAspectRatio: t && t.imagePreserveAspectRatio || "xMidYMid slice",
                hideOnTransparent: !(t && t.hideOnTransparent === !1),
                filterSize: {
                    width: t && t.filterSize && t.filterSize.width || "400%",
                    height: t && t.filterSize && t.filterSize.height || "400%",
                    x: t && t.filterSize && t.filterSize.x || "-100%",
                    y: t && t.filterSize && t.filterSize.y || "-100%"
                }
            }, this.globalData = {
                _mdf: !1,
                frameNum: -1,
                renderConfig: this.renderConfig
            }, this.pendingElements = [], this.elements = [], this.threeDElements = [], this.destroyed = !1, this.camera = null, this.supports3d = !0, this.rendererType = "html"
        }
        extendPrototype([BaseRenderer], HybridRenderer), HybridRenderer.prototype.buildItem = SVGRenderer.prototype.buildItem, HybridRenderer.prototype.checkPendingElements = function () {
            for (; this.pendingElements.length;) {
                var e = this.pendingElements.pop();
                e.checkParenting()
            }
        }, HybridRenderer.prototype.appendElementInPos = function (e, t) {
            var r = e.getBaseElement();
            if (r) {
                var i = this.layers[t];
                if (!i.ddd || !this.supports3d)
                    if (this.threeDElements) this.addTo3dContainer(r, t);
                    else {
                        for (var s = 0, n, a, l; s < t;) this.elements[s] && this.elements[s] !== !0 && this.elements[s].getBaseElement && (a = this.elements[s], l = this.layers[s].ddd ? this.getThreeDContainerByPos(s) : a.getBaseElement(), n = l || n), s += 1;
                        n ? (!i.ddd || !this.supports3d) && this.layerElement.insertBefore(r, n) : (!i.ddd || !this.supports3d) && this.layerElement.appendChild(r)
                    }
                else this.addTo3dContainer(r, t)
            }
        }, HybridRenderer.prototype.createShape = function (e) {
            return this.supports3d ? new HShapeElement(e, this.globalData, this) : new SVGShapeElement(e, this.globalData, this)
        }, HybridRenderer.prototype.createText = function (e) {
            return this.supports3d ? new HTextElement(e, this.globalData, this) : new SVGTextLottieElement(e, this.globalData, this)
        }, HybridRenderer.prototype.createCamera = function (e) {
            return this.camera = new HCameraElement(e, this.globalData, this), this.camera
        }, HybridRenderer.prototype.createImage = function (e) {
            return this.supports3d ? new HImageElement(e, this.globalData, this) : new IImageElement(e, this.globalData, this)
        }, HybridRenderer.prototype.createComp = function (e) {
            return this.supports3d ? new HCompElement(e, this.globalData, this) : new SVGCompElement(e, this.globalData, this)
        }, HybridRenderer.prototype.createSolid = function (e) {
            return this.supports3d ? new HSolidElement(e, this.globalData, this) : new ISolidElement(e, this.globalData, this)
        }, HybridRenderer.prototype.createNull = SVGRenderer.prototype.createNull, HybridRenderer.prototype.getThreeDContainerByPos = function (e) {
            for (var t = 0, r = this.threeDElements.length; t < r;) {
                if (this.threeDElements[t].startPos <= e && this.threeDElements[t].endPos >= e) return this.threeDElements[t].perspectiveElem;
                t += 1
            }
            return null
        }, HybridRenderer.prototype.createThreeDContainer = function (e, t) {
            var r = createTag("div"),
                i, s;
            styleDiv(r);
            var n = createTag("div");
            if (styleDiv(n), t === "3d") {
                i = r.style, i.width = this.globalData.compSize.w + "px", i.height = this.globalData.compSize.h + "px";
                var a = "50% 50%";
                i.webkitTransformOrigin = a, i.mozTransformOrigin = a, i.transformOrigin = a, s = n.style;
                var l = "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)";
                s.transform = l, s.webkitTransform = l
            }
            r.appendChild(n);
            var c = {
                container: n,
                perspectiveElem: r,
                startPos: e,
                endPos: e,
                type: t
            };
            return this.threeDElements.push(c), c
        }, HybridRenderer.prototype.build3dContainers = function () {
            var e, t = this.layers.length,
                r, i = "";
            for (e = 0; e < t; e += 1) this.layers[e].ddd && this.layers[e].ty !== 3 ? (i !== "3d" && (i = "3d", r = this.createThreeDContainer(e, "3d")), r.endPos = Math.max(r.endPos, e)) : (i !== "2d" && (i = "2d", r = this.createThreeDContainer(e, "2d")), r.endPos = Math.max(r.endPos, e));
            for (t = this.threeDElements.length, e = t - 1; e >= 0; e -= 1) this.resizerElem.appendChild(this.threeDElements[e].perspectiveElem)
        }, HybridRenderer.prototype.addTo3dContainer = function (e, t) {
            for (var r = 0, i = this.threeDElements.length; r < i;) {
                if (t <= this.threeDElements[r].endPos) {
                    for (var s = this.threeDElements[r].startPos, n; s < t;) this.elements[s] && this.elements[s].getBaseElement && (n = this.elements[s].getBaseElement()), s += 1;
                    n ? this.threeDElements[r].container.insertBefore(e, n) : this.threeDElements[r].container.appendChild(e);
                    break
                }
                r += 1
            }
        }, HybridRenderer.prototype.configAnimation = function (e) {
            var t = createTag("div"),
                r = this.animationItem.wrapper,
                i = t.style;
            i.width = e.w + "px", i.height = e.h + "px", this.resizerElem = t, styleDiv(t), i.transformStyle = "flat", i.mozTransformStyle = "flat", i.webkitTransformStyle = "flat", this.renderConfig.className && t.setAttribute("class", this.renderConfig.className), r.appendChild(t), i.overflow = "hidden";
            var s = createNS("svg");
            s.setAttribute("width", "1"), s.setAttribute("height", "1"), styleDiv(s), this.resizerElem.appendChild(s);
            var n = createNS("defs");
            s.appendChild(n), this.data = e, this.setupGlobalData(e, s), this.globalData.defs = n, this.layers = e.layers, this.layerElement = this.resizerElem, this.build3dContainers(), this.updateContainerSize()
        }, HybridRenderer.prototype.destroy = function () {
            this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), this.animationItem.container = null, this.globalData.defs = null;
            var e, t = this.layers ? this.layers.length : 0;
            for (e = 0; e < t; e += 1) this.elements[e].destroy();
            this.elements.length = 0, this.destroyed = !0, this.animationItem = null
        }, HybridRenderer.prototype.updateContainerSize = function () {
            var e = this.animationItem.wrapper.offsetWidth,
                t = this.animationItem.wrapper.offsetHeight,
                r = e / t,
                i = this.globalData.compSize.w / this.globalData.compSize.h,
                s, n, a, l;
            i > r ? (s = e / this.globalData.compSize.w, n = e / this.globalData.compSize.w, a = 0, l = (t - this.globalData.compSize.h * (e / this.globalData.compSize.w)) / 2) : (s = t / this.globalData.compSize.h, n = t / this.globalData.compSize.h, a = (e - this.globalData.compSize.w * (t / this.globalData.compSize.h)) / 2, l = 0);
            var c = this.resizerElem.style;
            c.webkitTransform = "matrix3d(" + s + ",0,0,0,0," + n + ",0,0,0,0,1,0," + a + "," + l + ",0,1)", c.transform = c.webkitTransform
        }, HybridRenderer.prototype.renderFrame = SVGRenderer.prototype.renderFrame, HybridRenderer.prototype.hide = function () {
            this.resizerElem.style.display = "none"
        }, HybridRenderer.prototype.show = function () {
            this.resizerElem.style.display = "block"
        }, HybridRenderer.prototype.initItems = function () {
            if (this.buildAllItems(), this.camera) this.camera.setup();
            else {
                var e = this.globalData.compSize.w,
                    t = this.globalData.compSize.h,
                    r, i = this.threeDElements.length;
                for (r = 0; r < i; r += 1) {
                    var s = this.threeDElements[r].perspectiveElem.style;
                    s.webkitPerspective = Math.sqrt(Math.pow(e, 2) + Math.pow(t, 2)) + "px", s.perspective = s.webkitPerspective
                }
            }
        }, HybridRenderer.prototype.searchExtraCompositions = function (e) {
            var t, r = e.length,
                i = createTag("div");
            for (t = 0; t < r; t += 1)
                if (e[t].xt) {
                    var s = this.createComp(e[t], i, this.globalData.comp, null);
                    s.initExpressions(), this.globalData.projectInterface.registerComposition(s)
                }
        };

        function MaskElement(e, t, r) {
            this.data = e, this.element = t, this.globalData = r, this.storedData = [], this.masksProperties = this.data.masksProperties || [], this.maskElement = null;
            var i = this.globalData.defs,
                s, n = this.masksProperties ? this.masksProperties.length : 0;
            this.viewData = createSizedArray(n), this.solidPath = "";
            var a, l = this.masksProperties,
                c = 0,
                g = [],
                _, E, P = createElementID(),
                x, y, d, b, m = "clipPath",
                o = "clip-path";
            for (s = 0; s < n; s += 1)
                if ((l[s].mode !== "a" && l[s].mode !== "n" || l[s].inv || l[s].o.k !== 100 || l[s].o.x) && (m = "mask", o = "mask"), (l[s].mode === "s" || l[s].mode === "i") && c === 0 ? (x = createNS("rect"), x.setAttribute("fill", "#ffffff"), x.setAttribute("width", this.element.comp.data.w || 0), x.setAttribute("height", this.element.comp.data.h || 0), g.push(x)) : x = null, a = createNS("path"), l[s].mode === "n") this.viewData[s] = {
                    op: PropertyFactory.getProp(this.element, l[s].o, 0, .01, this.element),
                    prop: ShapePropertyFactory.getShapeProp(this.element, l[s], 3),
                    elem: a,
                    lastPath: ""
                }, i.appendChild(a);
                else {
                    c += 1, a.setAttribute("fill", l[s].mode === "s" ? "#000000" : "#ffffff"), a.setAttribute("clip-rule", "nonzero");
                    var f;
                    if (l[s].x.k !== 0 ? (m = "mask", o = "mask", b = PropertyFactory.getProp(this.element, l[s].x, 0, null, this.element), f = createElementID(), y = createNS("filter"), y.setAttribute("id", f), d = createNS("feMorphology"), d.setAttribute("operator", "erode"), d.setAttribute("in", "SourceGraphic"), d.setAttribute("radius", "0"), y.appendChild(d), i.appendChild(y), a.setAttribute("stroke", l[s].mode === "s" ? "#000000" : "#ffffff")) : (d = null, b = null), this.storedData[s] = {
                            elem: a,
                            x: b,
                            expan: d,
                            lastPath: "",
                            lastOperator: "",
                            filterId: f,
                            lastRadius: 0
                        }, l[s].mode === "i") {
                        E = g.length;
                        var u = createNS("g");
                        for (_ = 0; _ < E; _ += 1) u.appendChild(g[_]);
                        var S = createNS("mask");
                        S.setAttribute("mask-type", "alpha"), S.setAttribute("id", P + "_" + c), S.appendChild(a), i.appendChild(S), u.setAttribute("mask", "url(" + locationHref + "#" + P + "_" + c + ")"), g.length = 0, g.push(u)
                    } else g.push(a);
                    l[s].inv && !this.solidPath && (this.solidPath = this.createLayerSolidPath()), this.viewData[s] = {
                        elem: a,
                        lastPath: "",
                        op: PropertyFactory.getProp(this.element, l[s].o, 0, .01, this.element),
                        prop: ShapePropertyFactory.getShapeProp(this.element, l[s], 3),
                        invRect: x
                    }, this.viewData[s].prop.k || this.drawPath(l[s], this.viewData[s].prop.v, this.viewData[s])
                } for (this.maskElement = createNS(m), n = g.length, s = 0; s < n; s += 1) this.maskElement.appendChild(g[s]);
            c > 0 && (this.maskElement.setAttribute("id", P), this.element.maskedElement.setAttribute(o, "url(" + locationHref + "#" + P + ")"), i.appendChild(this.maskElement)), this.viewData.length && this.element.addRenderableComponent(this)
        }
        MaskElement.prototype.getMaskProperty = function (e) {
            return this.viewData[e].prop
        }, MaskElement.prototype.renderFrame = function (e) {
            var t = this.element.finalTransform.mat,
                r, i = this.masksProperties.length;
            for (r = 0; r < i; r += 1)
                if ((this.viewData[r].prop._mdf || e) && this.drawPath(this.masksProperties[r], this.viewData[r].prop.v, this.viewData[r]), (this.viewData[r].op._mdf || e) && this.viewData[r].elem.setAttribute("fill-opacity", this.viewData[r].op.v), this.masksProperties[r].mode !== "n" && (this.viewData[r].invRect && (this.element.finalTransform.mProp._mdf || e) && this.viewData[r].invRect.setAttribute("transform", t.getInverseMatrix().to2dCSS()), this.storedData[r].x && (this.storedData[r].x._mdf || e))) {
                    var s = this.storedData[r].expan;
                    this.storedData[r].x.v < 0 ? (this.storedData[r].lastOperator !== "erode" && (this.storedData[r].lastOperator = "erode", this.storedData[r].elem.setAttribute("filter", "url(" + locationHref + "#" + this.storedData[r].filterId + ")")), s.setAttribute("radius", -this.storedData[r].x.v)) : (this.storedData[r].lastOperator !== "dilate" && (this.storedData[r].lastOperator = "dilate", this.storedData[r].elem.setAttribute("filter", null)), this.storedData[r].elem.setAttribute("stroke-width", this.storedData[r].x.v * 2))
                }
        }, MaskElement.prototype.getMaskelement = function () {
            return this.maskElement
        }, MaskElement.prototype.createLayerSolidPath = function () {
            var e = "M0,0 ";
            return e += " h" + this.globalData.compSize.w, e += " v" + this.globalData.compSize.h, e += " h-" + this.globalData.compSize.w, e += " v-" + this.globalData.compSize.h + " ", e
        }, MaskElement.prototype.drawPath = function (e, t, r) {
            var i = " M" + t.v[0][0] + "," + t.v[0][1],
                s, n;
            for (n = t._length, s = 1; s < n; s += 1) i += " C" + t.o[s - 1][0] + "," + t.o[s - 1][1] + " " + t.i[s][0] + "," + t.i[s][1] + " " + t.v[s][0] + "," + t.v[s][1];
            if (t.c && n > 1 && (i += " C" + t.o[s - 1][0] + "," + t.o[s - 1][1] + " " + t.i[0][0] + "," + t.i[0][1] + " " + t.v[0][0] + "," + t.v[0][1]), r.lastPath !== i) {
                var a = "";
                r.elem && (t.c && (a = e.inv ? this.solidPath + i : i), r.elem.setAttribute("d", a)), r.lastPath = i
            }
        }, MaskElement.prototype.destroy = function () {
            this.element = null, this.globalData = null, this.maskElement = null, this.data = null, this.masksProperties = null
        };

        function HierarchyElement() {}
        HierarchyElement.prototype = {
            initHierarchy: function () {
                this.hierarchy = [], this._isParent = !1, this.checkParenting()
            },
            setHierarchy: function (e) {
                this.hierarchy = e
            },
            setAsParent: function () {
                this._isParent = !0
            },
            checkParenting: function () {
                this.data.parent !== void 0 && this.comp.buildElementParenting(this, this.data.parent, [])
            }
        };

        function FrameElement() {}
        FrameElement.prototype = {
            initFrame: function () {
                this._isFirstFrame = !1, this.dynamicProperties = [], this._mdf = !1
            },
            prepareProperties: function (e, t) {
                var r, i = this.dynamicProperties.length;
                for (r = 0; r < i; r += 1)(t || this._isParent && this.dynamicProperties[r].propType === "transform") && (this.dynamicProperties[r].getValue(), this.dynamicProperties[r]._mdf && (this.globalData._mdf = !0, this._mdf = !0))
            },
            addDynamicProperty: function (e) {
                this.dynamicProperties.indexOf(e) === -1 && this.dynamicProperties.push(e)
            }
        };

        function TransformElement() {}
        TransformElement.prototype = {
            initTransform: function () {
                this.finalTransform = {
                    mProp: this.data.ks ? TransformPropertyFactory.getTransformProperty(this, this.data.ks, this) : {
                        o: 0
                    },
                    _matMdf: !1,
                    _opMdf: !1,
                    mat: new Matrix
                }, this.data.ao && (this.finalTransform.mProp.autoOriented = !0), this.data.ty
            },
            renderTransform: function () {
                if (this.finalTransform._opMdf = this.finalTransform.mProp.o._mdf || this._isFirstFrame, this.finalTransform._matMdf = this.finalTransform.mProp._mdf || this._isFirstFrame, this.hierarchy) {
                    var e, t = this.finalTransform.mat,
                        r = 0,
                        i = this.hierarchy.length;
                    if (!this.finalTransform._matMdf)
                        for (; r < i;) {
                            if (this.hierarchy[r].finalTransform.mProp._mdf) {
                                this.finalTransform._matMdf = !0;
                                break
                            }
                            r += 1
                        }
                    if (this.finalTransform._matMdf)
                        for (e = this.finalTransform.mProp.v.props, t.cloneFromProps(e), r = 0; r < i; r += 1) e = this.hierarchy[r].finalTransform.mProp.v.props, t.transform(e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8], e[9], e[10], e[11], e[12], e[13], e[14], e[15])
                }
            },
            globalToLocal: function (e) {
                var t = [];
                t.push(this.finalTransform);
                for (var r = !0, i = this.comp; r;) i.finalTransform ? (i.data.hasMask && t.splice(0, 0, i.finalTransform), i = i.comp) : r = !1;
                var s, n = t.length,
                    a;
                for (s = 0; s < n; s += 1) a = t[s].mat.applyToPointArray(0, 0, 0), e = [e[0] - a[0], e[1] - a[1], 0];
                return e
            },
            mHelper: new Matrix
        };

        function RenderableElement() {}
        RenderableElement.prototype = {
            initRenderable: function () {
                this.isInRange = !1, this.hidden = !1, this.isTransparent = !1, this.renderableComponents = []
            },
            addRenderableComponent: function (e) {
                this.renderableComponents.indexOf(e) === -1 && this.renderableComponents.push(e)
            },
            removeRenderableComponent: function (e) {
                this.renderableComponents.indexOf(e) !== -1 && this.renderableComponents.splice(this.renderableComponents.indexOf(e), 1)
            },
            prepareRenderableFrame: function (e) {
                this.checkLayerLimits(e)
            },
            checkTransparency: function () {
                this.finalTransform.mProp.o.v <= 0 ? !this.isTransparent && this.globalData.renderConfig.hideOnTransparent && (this.isTransparent = !0, this.hide()) : this.isTransparent && (this.isTransparent = !1, this.show())
            },
            checkLayerLimits: function (e) {
                this.data.ip - this.data.st <= e && this.data.op - this.data.st > e ? this.isInRange !== !0 && (this.globalData._mdf = !0, this._mdf = !0, this.isInRange = !0, this.show()) : this.isInRange !== !1 && (this.globalData._mdf = !0, this.isInRange = !1, this.hide())
            },
            renderRenderable: function () {
                var e, t = this.renderableComponents.length;
                for (e = 0; e < t; e += 1) this.renderableComponents[e].renderFrame(this._isFirstFrame)
            },
            sourceRectAtTime: function () {
                return {
                    top: 0,
                    left: 0,
                    width: 100,
                    height: 100
                }
            },
            getLayerSize: function () {
                return this.data.ty === 5 ? {
                    w: this.data.textData.width,
                    h: this.data.textData.height
                } : {
                    w: this.data.width,
                    h: this.data.height
                }
            }
        };

        function RenderableDOMElement() {}(function () {
            var e = {
                initElement: function (t, r, i) {
                    this.initFrame(), this.initBaseData(t, r, i), this.initTransform(t, r, i), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide()
                },
                hide: function () {
                    if (!this.hidden && (!this.isInRange || this.isTransparent)) {
                        var t = this.baseElement || this.layerElement;
                        t.style.display = "none", this.hidden = !0
                    }
                },
                show: function () {
                    if (this.isInRange && !this.isTransparent) {
                        if (!this.data.hd) {
                            var t = this.baseElement || this.layerElement;
                            t.style.display = "block"
                        }
                        this.hidden = !1, this._isFirstFrame = !0
                    }
                },
                renderFrame: function () {
                    this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = !1))
                },
                renderInnerContent: function () {},
                prepareFrame: function (t) {
                    this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), this.checkTransparency()
                },
                destroy: function () {
                    this.innerElem = null, this.destroyBaseElement()
                }
            };
            extendPrototype([RenderableElement, createProxyFunction(e)], RenderableDOMElement)
        })();

        function ProcessedElement(e, t) {
            this.elem = e, this.pos = t
        }

        function SVGStyleData(e, t) {
            this.data = e, this.type = e.ty, this.d = "", this.lvl = t, this._mdf = !1, this.closed = e.hd === !0, this.pElem = createNS("path"), this.msElem = null
        }
        SVGStyleData.prototype.reset = function () {
            this.d = "", this._mdf = !1
        };

        function SVGShapeData(e, t, r) {
            this.caches = [], this.styles = [], this.transformers = e, this.lStr = "", this.sh = r, this.lvl = t, this._isAnimated = !!r.k;
            for (var i = 0, s = e.length; i < s;) {
                if (e[i].mProps.dynamicProperties.length) {
                    this._isAnimated = !0;
                    break
                }
                i += 1
            }
        }
        SVGShapeData.prototype.setAsAnimated = function () {
            this._isAnimated = !0
        };

        function SVGTransformData(e, t, r) {
            this.transform = {
                mProps: e,
                op: t,
                container: r
            }, this.elements = [], this._isAnimated = this.transform.mProps.dynamicProperties.length || this.transform.op.effectsSequence.length
        }

        function SVGStrokeStyleData(e, t, r) {
            this.initDynamicPropertyContainer(e), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(e, t.o, 0, .01, this), this.w = PropertyFactory.getProp(e, t.w, 0, null, this), this.d = new DashProperty(e, t.d || {}, "svg", this), this.c = PropertyFactory.getProp(e, t.c, 1, 255, this), this.style = r, this._isAnimated = !!this._isAnimated
        }
        extendPrototype([DynamicPropertyContainer], SVGStrokeStyleData);

        function SVGFillStyleData(e, t, r) {
            this.initDynamicPropertyContainer(e), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(e, t.o, 0, .01, this), this.c = PropertyFactory.getProp(e, t.c, 1, 255, this), this.style = r
        }
        extendPrototype([DynamicPropertyContainer], SVGFillStyleData);

        function SVGGradientFillStyleData(e, t, r) {
            this.initDynamicPropertyContainer(e), this.getValue = this.iterateDynamicProperties, this.initGradientData(e, t, r)
        }
        SVGGradientFillStyleData.prototype.initGradientData = function (e, t, r) {
            this.o = PropertyFactory.getProp(e, t.o, 0, .01, this), this.s = PropertyFactory.getProp(e, t.s, 1, null, this), this.e = PropertyFactory.getProp(e, t.e, 1, null, this), this.h = PropertyFactory.getProp(e, t.h || {
                k: 0
            }, 0, .01, this), this.a = PropertyFactory.getProp(e, t.a || {
                k: 0
            }, 0, degToRads, this), this.g = new GradientProperty(e, t.g, this), this.style = r, this.stops = [], this.setGradientData(r.pElem, t), this.setGradientOpacity(t, r), this._isAnimated = !!this._isAnimated
        }, SVGGradientFillStyleData.prototype.setGradientData = function (e, t) {
            var r = createElementID(),
                i = createNS(t.t === 1 ? "linearGradient" : "radialGradient");
            i.setAttribute("id", r), i.setAttribute("spreadMethod", "pad"), i.setAttribute("gradientUnits", "userSpaceOnUse");
            var s = [],
                n, a, l;
            for (l = t.g.p * 4, a = 0; a < l; a += 4) n = createNS("stop"), i.appendChild(n), s.push(n);
            e.setAttribute(t.ty === "gf" ? "fill" : "stroke", "url(" + locationHref + "#" + r + ")"), this.gf = i, this.cst = s
        }, SVGGradientFillStyleData.prototype.setGradientOpacity = function (e, t) {
            if (this.g._hasOpacity && !this.g._collapsable) {
                var r, i, s, n = createNS("mask"),
                    a = createNS("path");
                n.appendChild(a);
                var l = createElementID(),
                    c = createElementID();
                n.setAttribute("id", c);
                var g = createNS(e.t === 1 ? "linearGradient" : "radialGradient");
                g.setAttribute("id", l), g.setAttribute("spreadMethod", "pad"), g.setAttribute("gradientUnits", "userSpaceOnUse"), s = e.g.k.k[0].s ? e.g.k.k[0].s.length : e.g.k.k.length;
                var _ = this.stops;
                for (i = e.g.p * 4; i < s; i += 2) r = createNS("stop"), r.setAttribute("stop-color", "rgb(255,255,255)"), g.appendChild(r), _.push(r);
                a.setAttribute(e.ty === "gf" ? "fill" : "stroke", "url(" + locationHref + "#" + l + ")"), e.ty === "gs" && (a.setAttribute("stroke-linecap", lineCapEnum[e.lc || 2]), a.setAttribute("stroke-linejoin", lineJoinEnum[e.lj || 2]), e.lj === 1 && a.setAttribute("stroke-miterlimit", e.ml)), this.of = g, this.ms = n, this.ost = _, this.maskId = c, t.msElem = a
            }
        }, extendPrototype([DynamicPropertyContainer], SVGGradientFillStyleData);

        function SVGGradientStrokeStyleData(e, t, r) {
            this.initDynamicPropertyContainer(e), this.getValue = this.iterateDynamicProperties, this.w = PropertyFactory.getProp(e, t.w, 0, null, this), this.d = new DashProperty(e, t.d || {}, "svg", this), this.initGradientData(e, t, r), this._isAnimated = !!this._isAnimated
        }
        extendPrototype([SVGGradientFillStyleData, DynamicPropertyContainer], SVGGradientStrokeStyleData);

        function ShapeGroupData() {
            this.it = [], this.prevViewData = [], this.gr = createNS("g")
        }
        var SVGElementsRenderer = function () {
            var e = new Matrix,
                t = new Matrix,
                r = {
                    createRenderFunction: i
                };

            function i(_) {
                switch (_.ty) {
                    case "fl":
                        return a;
                    case "gf":
                        return c;
                    case "gs":
                        return l;
                    case "st":
                        return g;
                    case "sh":
                    case "el":
                    case "rc":
                    case "sr":
                        return n;
                    case "tr":
                        return s;
                    default:
                        return null
                }
            }

            function s(_, E, P) {
                (P || E.transform.op._mdf) && E.transform.container.setAttribute("opacity", E.transform.op.v), (P || E.transform.mProps._mdf) && E.transform.container.setAttribute("transform", E.transform.mProps.v.to2dCSS())
            }

            function n(_, E, P) {
                var x, y, d, b, m, o, f = E.styles.length,
                    u = E.lvl,
                    S, k, C, T, B;
                for (o = 0; o < f; o += 1) {
                    if (b = E.sh._mdf || P, E.styles[o].lvl < u) {
                        for (k = t.reset(), T = u - E.styles[o].lvl, B = E.transformers.length - 1; !b && T > 0;) b = E.transformers[B].mProps._mdf || b, T -= 1, B -= 1;
                        if (b)
                            for (T = u - E.styles[o].lvl, B = E.transformers.length - 1; T > 0;) C = E.transformers[B].mProps.v.props, k.transform(C[0], C[1], C[2], C[3], C[4], C[5], C[6], C[7], C[8], C[9], C[10], C[11], C[12], C[13], C[14], C[15]), T -= 1, B -= 1
                    } else k = e;
                    if (S = E.sh.paths, y = S._length, b) {
                        for (d = "", x = 0; x < y; x += 1) m = S.shapes[x], m && m._length && (d += buildShapeString(m, m._length, m.c, k));
                        E.caches[o] = d
                    } else d = E.caches[o];
                    E.styles[o].d += _.hd === !0 ? "" : d, E.styles[o]._mdf = b || E.styles[o]._mdf
                }
            }

            function a(_, E, P) {
                var x = E.style;
                (E.c._mdf || P) && x.pElem.setAttribute("fill", "rgb(" + bmFloor(E.c.v[0]) + "," + bmFloor(E.c.v[1]) + "," + bmFloor(E.c.v[2]) + ")"), (E.o._mdf || P) && x.pElem.setAttribute("fill-opacity", E.o.v)
            }

            function l(_, E, P) {
                c(_, E, P), g(_, E, P)
            }

            function c(_, E, P) {
                var x = E.gf,
                    y = E.g._hasOpacity,
                    d = E.s.v,
                    b = E.e.v;
                if (E.o._mdf || P) {
                    var m = _.ty === "gf" ? "fill-opacity" : "stroke-opacity";
                    E.style.pElem.setAttribute(m, E.o.v)
                }
                if (E.s._mdf || P) {
                    var o = _.t === 1 ? "x1" : "cx",
                        f = o === "x1" ? "y1" : "cy";
                    x.setAttribute(o, d[0]), x.setAttribute(f, d[1]), y && !E.g._collapsable && (E.of.setAttribute(o, d[0]), E.of.setAttribute(f, d[1]))
                }
                var u, S, k, C;
                if (E.g._cmdf || P) {
                    u = E.cst;
                    var T = E.g.c;
                    for (k = u.length, S = 0; S < k; S += 1) C = u[S], C.setAttribute("offset", T[S * 4] + "%"), C.setAttribute("stop-color", "rgb(" + T[S * 4 + 1] + "," + T[S * 4 + 2] + "," + T[S * 4 + 3] + ")")
                }
                if (y && (E.g._omdf || P)) {
                    var B = E.g.o;
                    for (E.g._collapsable ? u = E.cst : u = E.ost, k = u.length, S = 0; S < k; S += 1) C = u[S], E.g._collapsable || C.setAttribute("offset", B[S * 2] + "%"), C.setAttribute("stop-opacity", B[S * 2 + 1])
                }
                if (_.t === 1)(E.e._mdf || P) && (x.setAttribute("x2", b[0]), x.setAttribute("y2", b[1]), y && !E.g._collapsable && (E.of.setAttribute("x2", b[0]), E.of.setAttribute("y2", b[1])));
                else {
                    var D;
                    if ((E.s._mdf || E.e._mdf || P) && (D = Math.sqrt(Math.pow(d[0] - b[0], 2) + Math.pow(d[1] - b[1], 2)), x.setAttribute("r", D), y && !E.g._collapsable && E.of.setAttribute("r", D)), E.e._mdf || E.h._mdf || E.a._mdf || P) {
                        D || (D = Math.sqrt(Math.pow(d[0] - b[0], 2) + Math.pow(d[1] - b[1], 2)));
                        var H = Math.atan2(b[1] - d[1], b[0] - d[0]),
                            L = E.h.v;
                        L >= 1 ? L = .99 : L <= -1 && (L = -.99);
                        var U = D * L,
                            Y = Math.cos(H + E.a.v) * U + d[0],
                            Z = Math.sin(H + E.a.v) * U + d[1];
                        x.setAttribute("fx", Y), x.setAttribute("fy", Z), y && !E.g._collapsable && (E.of.setAttribute("fx", Y), E.of.setAttribute("fy", Z))
                    }
                }
            }

            function g(_, E, P) {
                var x = E.style,
                    y = E.d;
                y && (y._mdf || P) && y.dashStr && (x.pElem.setAttribute("stroke-dasharray", y.dashStr), x.pElem.setAttribute("stroke-dashoffset", y.dashoffset[0])), E.c && (E.c._mdf || P) && x.pElem.setAttribute("stroke", "rgb(" + bmFloor(E.c.v[0]) + "," + bmFloor(E.c.v[1]) + "," + bmFloor(E.c.v[2]) + ")"), (E.o._mdf || P) && x.pElem.setAttribute("stroke-opacity", E.o.v), (E.w._mdf || P) && (x.pElem.setAttribute("stroke-width", E.w.v), x.msElem && x.msElem.setAttribute("stroke-width", E.w.v))
            }
            return r
        }();

        function ShapeTransformManager() {
            this.sequences = {}, this.sequenceList = [], this.transform_key_count = 0
        }
        ShapeTransformManager.prototype = {
            addTransformSequence: function (e) {
                var t, r = e.length,
                    i = "_";
                for (t = 0; t < r; t += 1) i += e[t].transform.key + "_";
                var s = this.sequences[i];
                return s || (s = {
                    transforms: [].concat(e),
                    finalTransform: new Matrix,
                    _mdf: !1
                }, this.sequences[i] = s, this.sequenceList.push(s)), s
            },
            processSequence: function (e, t) {
                for (var r = 0, i = e.transforms.length, s = t; r < i && !t;) {
                    if (e.transforms[r].transform.mProps._mdf) {
                        s = !0;
                        break
                    }
                    r += 1
                }
                if (s) {
                    var n;
                    for (e.finalTransform.reset(), r = i - 1; r >= 0; r -= 1) n = e.transforms[r].transform.mProps.v.props, e.finalTransform.transform(n[0], n[1], n[2], n[3], n[4], n[5], n[6], n[7], n[8], n[9], n[10], n[11], n[12], n[13], n[14], n[15])
                }
                e._mdf = s
            },
            processSequences: function (e) {
                var t, r = this.sequenceList.length;
                for (t = 0; t < r; t += 1) this.processSequence(this.sequenceList[t], e)
            },
            getNewKey: function () {
                return this.transform_key_count += 1, "_" + this.transform_key_count
            }
        };

        function CVShapeData(e, t, r, i) {
            this.styledShapes = [], this.tr = [0, 0, 0, 0, 0, 0];
            var s = 4;
            t.ty === "rc" ? s = 5 : t.ty === "el" ? s = 6 : t.ty === "sr" && (s = 7), this.sh = ShapePropertyFactory.getShapeProp(e, t, s, e);
            var n, a = r.length,
                l;
            for (n = 0; n < a; n += 1) r[n].closed || (l = {
                transforms: i.addTransformSequence(r[n].transforms),
                trNodes: []
            }, this.styledShapes.push(l), r[n].elements.push(l))
        }
        CVShapeData.prototype.setAsAnimated = SVGShapeData.prototype.setAsAnimated;

        function BaseElement() {}
        BaseElement.prototype = {
            checkMasks: function () {
                if (!this.data.hasMask) return !1;
                for (var e = 0, t = this.data.masksProperties.length; e < t;) {
                    if (this.data.masksProperties[e].mode !== "n" && this.data.masksProperties[e].cl !== !1) return !0;
                    e += 1
                }
                return !1
            },
            initExpressions: function () {
                this.layerInterface = LayerExpressionInterface(this), this.data.hasMask && this.maskManager && this.layerInterface.registerMaskInterface(this.maskManager);
                var e = EffectsExpressionInterface.createEffectsInterface(this, this.layerInterface);
                this.layerInterface.registerEffectsInterface(e), this.data.ty === 0 || this.data.xt ? this.compInterface = CompExpressionInterface(this) : this.data.ty === 4 ? (this.layerInterface.shapeInterface = ShapeExpressionInterface(this.shapesData, this.itemsData, this.layerInterface), this.layerInterface.content = this.layerInterface.shapeInterface) : this.data.ty === 5 && (this.layerInterface.textInterface = TextExpressionInterface(this), this.layerInterface.text = this.layerInterface.textInterface)
            },
            setBlendMode: function () {
                var e = getBlendMode(this.data.bm),
                    t = this.baseElement || this.layerElement;
                t.style["mix-blend-mode"] = e
            },
            initBaseData: function (e, t, r) {
                this.globalData = t, this.comp = r, this.data = e, this.layerId = createElementID(), this.data.sr || (this.data.sr = 1), this.effectsManager = new EffectsManager(this.data, this, this.dynamicProperties)
            },
            getType: function () {
                return this.type
            },
            sourceRectAtTime: function () {}
        };

        function NullElement(e, t, r) {
            this.initFrame(), this.initBaseData(e, t, r), this.initFrame(), this.initTransform(e, t, r), this.initHierarchy()
        }
        NullElement.prototype.prepareFrame = function (e) {
            this.prepareProperties(e, !0)
        }, NullElement.prototype.renderFrame = function () {}, NullElement.prototype.getBaseElement = function () {
            return null
        }, NullElement.prototype.destroy = function () {}, NullElement.prototype.sourceRectAtTime = function () {}, NullElement.prototype.hide = function () {}, extendPrototype([BaseElement, TransformElement, HierarchyElement, FrameElement], NullElement);

        function SVGBaseElement() {}
        SVGBaseElement.prototype = {
            initRendererElement: function () {
                this.layerElement = createNS("g")
            },
            createContainerElements: function () {
                this.matteElement = createNS("g"), this.transformedElement = this.layerElement, this.maskedElement = this.layerElement, this._sizeChanged = !1;
                var e = null,
                    t, r, i;
                if (this.data.td) {
                    if (this.data.td == 3 || this.data.td == 1) {
                        var s = createNS("mask");
                        s.setAttribute("id", this.layerId), s.setAttribute("mask-type", this.data.td == 3 ? "luminance" : "alpha"), s.appendChild(this.layerElement), e = s, this.globalData.defs.appendChild(s), !featureSupport.maskType && this.data.td == 1 && (s.setAttribute("mask-type", "luminance"), t = createElementID(), r = filtersFactory.createFilter(t), this.globalData.defs.appendChild(r), r.appendChild(filtersFactory.createAlphaToLuminanceFilter()), i = createNS("g"), i.appendChild(this.layerElement), e = i, s.appendChild(i), i.setAttribute("filter", "url(" + locationHref + "#" + t + ")"))
                    } else if (this.data.td == 2) {
                        var n = createNS("mask");
                        n.setAttribute("id", this.layerId), n.setAttribute("mask-type", "alpha");
                        var a = createNS("g");
                        n.appendChild(a), t = createElementID(), r = filtersFactory.createFilter(t);
                        var l = createNS("feComponentTransfer");
                        l.setAttribute("in", "SourceGraphic"), r.appendChild(l);
                        var c = createNS("feFuncA");
                        c.setAttribute("type", "table"), c.setAttribute("tableValues", "1.0 0.0"), l.appendChild(c), this.globalData.defs.appendChild(r);
                        var g = createNS("rect");
                        g.setAttribute("width", this.comp.data.w), g.setAttribute("height", this.comp.data.h), g.setAttribute("x", "0"), g.setAttribute("y", "0"), g.setAttribute("fill", "#ffffff"), g.setAttribute("opacity", "0"), a.setAttribute("filter", "url(" + locationHref + "#" + t + ")"), a.appendChild(g), a.appendChild(this.layerElement), e = a, featureSupport.maskType || (n.setAttribute("mask-type", "luminance"), r.appendChild(filtersFactory.createAlphaToLuminanceFilter()), i = createNS("g"), a.appendChild(g), i.appendChild(this.layerElement), e = i, a.appendChild(i)), this.globalData.defs.appendChild(n)
                    }
                } else this.data.tt ? (this.matteElement.appendChild(this.layerElement), e = this.matteElement, this.baseElement = this.matteElement) : this.baseElement = this.layerElement;
                if (this.data.ln && this.layerElement.setAttribute("id", this.data.ln), this.data.cl && this.layerElement.setAttribute("class", this.data.cl), this.data.ty === 0 && !this.data.hd) {
                    var _ = createNS("clipPath"),
                        E = createNS("path");
                    E.setAttribute("d", "M0,0 L" + this.data.w + ",0 L" + this.data.w + "," + this.data.h + " L0," + this.data.h + "z");
                    var P = createElementID();
                    if (_.setAttribute("id", P), _.appendChild(E), this.globalData.defs.appendChild(_), this.checkMasks()) {
                        var x = createNS("g");
                        x.setAttribute("clip-path", "url(" + locationHref + "#" + P + ")"), x.appendChild(this.layerElement), this.transformedElement = x, e ? e.appendChild(this.transformedElement) : this.baseElement = this.transformedElement
                    } else this.layerElement.setAttribute("clip-path", "url(" + locationHref + "#" + P + ")")
                }
                this.data.bm !== 0 && this.setBlendMode()
            },
            renderElement: function () {
                this.finalTransform._matMdf && this.transformedElement.setAttribute("transform", this.finalTransform.mat.to2dCSS()), this.finalTransform._opMdf && this.transformedElement.setAttribute("opacity", this.finalTransform.mProp.o.v)
            },
            destroyBaseElement: function () {
                this.layerElement = null, this.matteElement = null, this.maskManager.destroy()
            },
            getBaseElement: function () {
                return this.data.hd ? null : this.baseElement
            },
            createRenderableComponents: function () {
                this.maskManager = new MaskElement(this.data, this, this.globalData), this.renderableEffectsManager = new SVGEffects(this)
            },
            setMatte: function (e) {
                this.matteElement && this.matteElement.setAttribute("mask", "url(" + locationHref + "#" + e + ")")
            }
        };

        function IShapeElement() {}
        IShapeElement.prototype = {
            addShapeToModifiers: function (e) {
                var t, r = this.shapeModifiers.length;
                for (t = 0; t < r; t += 1) this.shapeModifiers[t].addShape(e)
            },
            isShapeInAnimatedModifiers: function (e) {
                for (var t = 0, r = this.shapeModifiers.length; t < r;)
                    if (this.shapeModifiers[t].isAnimatedWithShape(e)) return !0;
                return !1
            },
            renderModifiers: function () {
                if (this.shapeModifiers.length) {
                    var e, t = this.shapes.length;
                    for (e = 0; e < t; e += 1) this.shapes[e].sh.reset();
                    t = this.shapeModifiers.length;
                    var r;
                    for (e = t - 1; e >= 0 && (r = this.shapeModifiers[e].processShapes(this._isFirstFrame), !r); e -= 1);
                }
            },
            searchProcessedElement: function (e) {
                for (var t = this.processedElements, r = 0, i = t.length; r < i;) {
                    if (t[r].elem === e) return t[r].pos;
                    r += 1
                }
                return 0
            },
            addProcessedElement: function (e, t) {
                for (var r = this.processedElements, i = r.length; i;)
                    if (i -= 1, r[i].elem === e) {
                        r[i].pos = t;
                        return
                    } r.push(new ProcessedElement(e, t))
            },
            prepareFrame: function (e) {
                this.prepareRenderableFrame(e), this.prepareProperties(e, this.isInRange)
            }
        };

        function ITextElement() {}
        ITextElement.prototype.initElement = function (e, t, r) {
            this.lettersChangedFlag = !0, this.initFrame(), this.initBaseData(e, t, r), this.textProperty = new TextProperty(this, e.t, this.dynamicProperties), this.textAnimator = new TextAnimatorProperty(e.t, this.renderType, this), this.initTransform(e, t, r), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide(), this.textAnimator.searchProperties(this.dynamicProperties)
        }, ITextElement.prototype.prepareFrame = function (e) {
            this._mdf = !1, this.prepareRenderableFrame(e), this.prepareProperties(e, this.isInRange), (this.textProperty._mdf || this.textProperty._isFirstFrame) && (this.buildNewText(), this.textProperty._isFirstFrame = !1, this.textProperty._mdf = !1)
        }, ITextElement.prototype.createPathShape = function (e, t) {
            var r, i = t.length,
                s, n = "";
            for (r = 0; r < i; r += 1) s = t[r].ks.k, n += buildShapeString(s, s.i.length, !0, e);
            return n
        }, ITextElement.prototype.updateDocumentData = function (e, t) {
            this.textProperty.updateDocumentData(e, t)
        }, ITextElement.prototype.canResizeFont = function (e) {
            this.textProperty.canResizeFont(e)
        }, ITextElement.prototype.setMinimumFontSize = function (e) {
            this.textProperty.setMinimumFontSize(e)
        }, ITextElement.prototype.applyTextPropertiesToMatrix = function (e, t, r, i, s) {
            switch (e.ps && t.translate(e.ps[0], e.ps[1] + e.ascent, 0), t.translate(0, -e.ls, 0), e.j) {
                case 1:
                    t.translate(e.justifyOffset + (e.boxWidth - e.lineWidths[r]), 0, 0);
                    break;
                case 2:
                    t.translate(e.justifyOffset + (e.boxWidth - e.lineWidths[r]) / 2, 0, 0);
                    break
            }
            t.translate(i, s, 0)
        }, ITextElement.prototype.buildColor = function (e) {
            return "rgb(" + Math.round(e[0] * 255) + "," + Math.round(e[1] * 255) + "," + Math.round(e[2] * 255) + ")"
        }, ITextElement.prototype.emptyProp = new LetterProps, ITextElement.prototype.destroy = function () {};

        function ICompElement() {}
        extendPrototype([BaseElement, TransformElement, HierarchyElement, FrameElement, RenderableDOMElement], ICompElement), ICompElement.prototype.initElement = function (e, t, r) {
            this.initFrame(), this.initBaseData(e, t, r), this.initTransform(e, t, r), this.initRenderable(), this.initHierarchy(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), (this.data.xt || !t.progressiveLoad) && this.buildAllItems(), this.hide()
        }, ICompElement.prototype.prepareFrame = function (e) {
            if (this._mdf = !1, this.prepareRenderableFrame(e), this.prepareProperties(e, this.isInRange), !(!this.isInRange && !this.data.xt)) {
                if (this.tm._placeholder) this.renderedFrame = e / this.data.sr;
                else {
                    var t = this.tm.v;
                    t === this.data.op && (t = this.data.op - 1), this.renderedFrame = t
                }
                var r, i = this.elements.length;
                for (this.completeLayers || this.checkLayers(this.renderedFrame), r = i - 1; r >= 0; r -= 1)(this.completeLayers || this.elements[r]) && (this.elements[r].prepareFrame(this.renderedFrame - this.layers[r].st), this.elements[r]._mdf && (this._mdf = !0))
            }
        }, ICompElement.prototype.renderInnerContent = function () {
            var e, t = this.layers.length;
            for (e = 0; e < t; e += 1)(this.completeLayers || this.elements[e]) && this.elements[e].renderFrame()
        }, ICompElement.prototype.setElements = function (e) {
            this.elements = e
        }, ICompElement.prototype.getElements = function () {
            return this.elements
        }, ICompElement.prototype.destroyElements = function () {
            var e, t = this.layers.length;
            for (e = 0; e < t; e += 1) this.elements[e] && this.elements[e].destroy()
        }, ICompElement.prototype.destroy = function () {
            this.destroyElements(), this.destroyBaseElement()
        };

        function IImageElement(e, t, r) {
            this.assetData = t.getAssetData(e.refId), this.initElement(e, t, r), this.sourceRect = {
                top: 0,
                left: 0,
                width: this.assetData.w,
                height: this.assetData.h
            }
        }
        extendPrototype([BaseElement, TransformElement, SVGBaseElement, HierarchyElement, FrameElement, RenderableDOMElement], IImageElement), IImageElement.prototype.createContent = function () {
            var e = this.globalData.getAssetsPath(this.assetData);
            this.innerElem = createNS("image"), this.innerElem.setAttribute("width", this.assetData.w + "px"), this.innerElem.setAttribute("height", this.assetData.h + "px"), this.innerElem.setAttribute("preserveAspectRatio", this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio), this.innerElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", e), this.layerElement.appendChild(this.innerElem)
        }, IImageElement.prototype.sourceRectAtTime = function () {
            return this.sourceRect
        };

        function ISolidElement(e, t, r) {
            this.initElement(e, t, r)
        }
        extendPrototype([IImageElement], ISolidElement), ISolidElement.prototype.createContent = function () {
            var e = createNS("rect");
            e.setAttribute("width", this.data.sw), e.setAttribute("height", this.data.sh), e.setAttribute("fill", this.data.sc), this.layerElement.appendChild(e)
        };

        function AudioElement(e, t, r) {
            this.initFrame(), this.initRenderable(), this.assetData = t.getAssetData(e.refId), this.initBaseData(e, t, r), this._isPlaying = !1, this._canPlay = !1;
            var i = this.globalData.getAssetsPath(this.assetData);
            this.audio = this.globalData.audioController.createAudio(i), this._currentTime = 0, this.globalData.audioController.addAudio(this), this.tm = e.tm ? PropertyFactory.getProp(this, e.tm, 0, t.frameRate, this) : {
                _placeholder: !0
            }
        }
        AudioElement.prototype.prepareFrame = function (e) {
            if (this.prepareRenderableFrame(e, !0), this.prepareProperties(e, !0), this.tm._placeholder) this._currentTime = e / this.data.sr;
            else {
                var t = this.tm.v;
                this._currentTime = t
            }
        }, extendPrototype([RenderableElement, BaseElement, FrameElement], AudioElement), AudioElement.prototype.renderFrame = function () {
            this.isInRange && this._canPlay && (this._isPlaying ? (!this.audio.playing() || Math.abs(this._currentTime / this.globalData.frameRate - this.audio.seek()) > .1) && this.audio.seek(this._currentTime / this.globalData.frameRate) : (this.audio.play(), this.audio.seek(this._currentTime / this.globalData.frameRate), this._isPlaying = !0))
        }, AudioElement.prototype.show = function () {}, AudioElement.prototype.hide = function () {
            this.audio.pause(), this._isPlaying = !1
        }, AudioElement.prototype.pause = function () {
            this.audio.pause(), this._isPlaying = !1, this._canPlay = !1
        }, AudioElement.prototype.resume = function () {
            this._canPlay = !0
        }, AudioElement.prototype.setRate = function (e) {
            this.audio.rate(e)
        }, AudioElement.prototype.volume = function (e) {
            this.audio.volume(e)
        }, AudioElement.prototype.getBaseElement = function () {
            return null
        }, AudioElement.prototype.destroy = function () {}, AudioElement.prototype.sourceRectAtTime = function () {}, AudioElement.prototype.initExpressions = function () {};

        function FootageElement(e, t, r) {
            this.initFrame(), this.initRenderable(), this.assetData = t.getAssetData(e.refId), this.footageData = t.imageLoader.getAsset(this.assetData), this.initBaseData(e, t, r)
        }
        FootageElement.prototype.prepareFrame = function () {}, extendPrototype([RenderableElement, BaseElement, FrameElement], FootageElement), FootageElement.prototype.getBaseElement = function () {
            return null
        }, FootageElement.prototype.renderFrame = function () {}, FootageElement.prototype.destroy = function () {}, FootageElement.prototype.initExpressions = function () {
            this.layerInterface = FootageInterface(this)
        }, FootageElement.prototype.getFootageData = function () {
            return this.footageData
        };

        function SVGCompElement(e, t, r) {
            this.layers = e.layers, this.supports3d = !0, this.completeLayers = !1, this.pendingElements = [], this.elements = this.layers ? createSizedArray(this.layers.length) : [], this.initElement(e, t, r), this.tm = e.tm ? PropertyFactory.getProp(this, e.tm, 0, t.frameRate, this) : {
                _placeholder: !0
            }
        }
        extendPrototype([SVGRenderer, ICompElement, SVGBaseElement], SVGCompElement);

        function SVGTextLottieElement(e, t, r) {
            this.textSpans = [], this.renderType = "svg", this.initElement(e, t, r)
        }
        extendPrototype([BaseElement, TransformElement, SVGBaseElement, HierarchyElement, FrameElement, RenderableDOMElement, ITextElement], SVGTextLottieElement), SVGTextLottieElement.prototype.createContent = function () {
            this.data.singleShape && !this.globalData.fontManager.chars && (this.textContainer = createNS("text"))
        }, SVGTextLottieElement.prototype.buildTextContents = function (e) {
            for (var t = 0, r = e.length, i = [], s = ""; t < r;) e[t] === String.fromCharCode(13) || e[t] === String.fromCharCode(3) ? (i.push(s), s = "") : s += e[t], t += 1;
            return i.push(s), i
        }, SVGTextLottieElement.prototype.buildNewText = function () {
            var e, t, r = this.textProperty.currentData;
            this.renderedLetters = createSizedArray(r ? r.l.length : 0), r.fc ? this.layerElement.setAttribute("fill", this.buildColor(r.fc)) : this.layerElement.setAttribute("fill", "rgba(0,0,0,0)"), r.sc && (this.layerElement.setAttribute("stroke", this.buildColor(r.sc)), this.layerElement.setAttribute("stroke-width", r.sw)), this.layerElement.setAttribute("font-size", r.finalSize);
            var i = this.globalData.fontManager.getFontByName(r.f);
            if (i.fClass) this.layerElement.setAttribute("class", i.fClass);
            else {
                this.layerElement.setAttribute("font-family", i.fFamily);
                var s = r.fWeight,
                    n = r.fStyle;
                this.layerElement.setAttribute("font-style", n), this.layerElement.setAttribute("font-weight", s)
            }
            this.layerElement.setAttribute("aria-label", r.t);
            var a = r.l || [],
                l = !!this.globalData.fontManager.chars;
            t = a.length;
            var c, g = this.mHelper,
                _, E = "",
                P = this.data.singleShape,
                x = 0,
                y = 0,
                d = !0,
                b = r.tr * .001 * r.finalSize;
            if (P && !l && !r.sz) {
                var m = this.textContainer,
                    o = "start";
                switch (r.j) {
                    case 1:
                        o = "end";
                        break;
                    case 2:
                        o = "middle";
                        break;
                    default:
                        o = "start";
                        break
                }
                m.setAttribute("text-anchor", o), m.setAttribute("letter-spacing", b);
                var f = this.buildTextContents(r.finalText);
                for (t = f.length, y = r.ps ? r.ps[1] + r.ascent : 0, e = 0; e < t; e += 1) c = this.textSpans[e] || createNS("tspan"), c.textContent = f[e], c.setAttribute("x", 0), c.setAttribute("y", y), c.style.display = "inherit", m.appendChild(c), this.textSpans[e] = c, y += r.finalLineHeight;
                this.layerElement.appendChild(m)
            } else {
                var u = this.textSpans.length,
                    S, k;
                for (e = 0; e < t; e += 1)(!l || !P || e === 0) && (c = u > e ? this.textSpans[e] : createNS(l ? "path" : "text"), u <= e && (c.setAttribute("stroke-linecap", "butt"), c.setAttribute("stroke-linejoin", "round"), c.setAttribute("stroke-miterlimit", "4"), this.textSpans[e] = c, this.layerElement.appendChild(c)), c.style.display = "inherit"), g.reset(), g.scale(r.finalSize / 100, r.finalSize / 100), P && (a[e].n && (x = -b, y += r.yOffset, y += d ? 1 : 0, d = !1), this.applyTextPropertiesToMatrix(r, g, a[e].line, x, y), x += a[e].l || 0, x += b), l ? (k = this.globalData.fontManager.getCharData(r.finalText[e], i.fStyle, this.globalData.fontManager.getFontByName(r.f).fFamily), S = k && k.data || {}, _ = S.shapes ? S.shapes[0].it : [], P ? E += this.createPathShape(g, _) : c.setAttribute("d", this.createPathShape(g, _))) : (P && c.setAttribute("transform", "translate(" + g.props[12] + "," + g.props[13] + ")"), c.textContent = a[e].val, c.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"));
                P && c && c.setAttribute("d", E)
            }
            for (; e < this.textSpans.length;) this.textSpans[e].style.display = "none", e += 1;
            this._sizeChanged = !0
        }, SVGTextLottieElement.prototype.sourceRectAtTime = function () {
            if (this.prepareFrame(this.comp.renderedFrame - this.data.st), this.renderInnerContent(), this._sizeChanged) {
                this._sizeChanged = !1;
                var e = this.layerElement.getBBox();
                this.bbox = {
                    top: e.y,
                    left: e.x,
                    width: e.width,
                    height: e.height
                }
            }
            return this.bbox
        }, SVGTextLottieElement.prototype.renderInnerContent = function () {
            if (!this.data.singleShape && (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), this.lettersChangedFlag || this.textAnimator.lettersChangedFlag)) {
                this._sizeChanged = !0;
                var e, t, r = this.textAnimator.renderedLetters,
                    i = this.textProperty.currentData.l;
                t = i.length;
                var s, n;
                for (e = 0; e < t; e += 1) i[e].n || (s = r[e], n = this.textSpans[e], s._mdf.m && n.setAttribute("transform", s.m), s._mdf.o && n.setAttribute("opacity", s.o), s._mdf.sw && n.setAttribute("stroke-width", s.sw), s._mdf.sc && n.setAttribute("stroke", s.sc), s._mdf.fc && n.setAttribute("fill", s.fc))
            }
        };

        function SVGShapeElement(e, t, r) {
            this.shapes = [], this.shapesData = e.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.initElement(e, t, r), this.prevViewData = []
        }
        extendPrototype([BaseElement, TransformElement, SVGBaseElement, IShapeElement, HierarchyElement, FrameElement, RenderableDOMElement], SVGShapeElement), SVGShapeElement.prototype.initSecondaryElement = function () {}, SVGShapeElement.prototype.identityMatrix = new Matrix, SVGShapeElement.prototype.buildExpressionInterface = function () {}, SVGShapeElement.prototype.createContent = function () {
            this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes()
        }, SVGShapeElement.prototype.filterUniqueShapes = function () {
            var e, t = this.shapes.length,
                r, i, s = this.stylesList.length,
                n, a = [],
                l = !1;
            for (i = 0; i < s; i += 1) {
                for (n = this.stylesList[i], l = !1, a.length = 0, e = 0; e < t; e += 1) r = this.shapes[e], r.styles.indexOf(n) !== -1 && (a.push(r), l = r._isAnimated || l);
                a.length > 1 && l && this.setShapesAsAnimated(a)
            }
        }, SVGShapeElement.prototype.setShapesAsAnimated = function (e) {
            var t, r = e.length;
            for (t = 0; t < r; t += 1) e[t].setAsAnimated()
        }, SVGShapeElement.prototype.createStyleElement = function (e, t) {
            var r, i = new SVGStyleData(e, t),
                s = i.pElem;
            if (e.ty === "st") r = new SVGStrokeStyleData(this, e, i);
            else if (e.ty === "fl") r = new SVGFillStyleData(this, e, i);
            else if (e.ty === "gf" || e.ty === "gs") {
                var n = e.ty === "gf" ? SVGGradientFillStyleData : SVGGradientStrokeStyleData;
                r = new n(this, e, i), this.globalData.defs.appendChild(r.gf), r.maskId && (this.globalData.defs.appendChild(r.ms), this.globalData.defs.appendChild(r.of), s.setAttribute("mask", "url(" + locationHref + "#" + r.maskId + ")"))
            }
            return (e.ty === "st" || e.ty === "gs") && (s.setAttribute("stroke-linecap", lineCapEnum[e.lc || 2]), s.setAttribute("stroke-linejoin", lineJoinEnum[e.lj || 2]), s.setAttribute("fill-opacity", "0"), e.lj === 1 && s.setAttribute("stroke-miterlimit", e.ml)), e.r === 2 && s.setAttribute("fill-rule", "evenodd"), e.ln && s.setAttribute("id", e.ln), e.cl && s.setAttribute("class", e.cl), e.bm && (s.style["mix-blend-mode"] = getBlendMode(e.bm)), this.stylesList.push(i), this.addToAnimatedContents(e, r), r
        }, SVGShapeElement.prototype.createGroupElement = function (e) {
            var t = new ShapeGroupData;
            return e.ln && t.gr.setAttribute("id", e.ln), e.cl && t.gr.setAttribute("class", e.cl), e.bm && (t.gr.style["mix-blend-mode"] = getBlendMode(e.bm)), t
        }, SVGShapeElement.prototype.createTransformElement = function (e, t) {
            var r = TransformPropertyFactory.getTransformProperty(this, e, this),
                i = new SVGTransformData(r, r.o, t);
            return this.addToAnimatedContents(e, i), i
        }, SVGShapeElement.prototype.createShapeElement = function (e, t, r) {
            var i = 4;
            e.ty === "rc" ? i = 5 : e.ty === "el" ? i = 6 : e.ty === "sr" && (i = 7);
            var s = ShapePropertyFactory.getShapeProp(this, e, i, this),
                n = new SVGShapeData(t, r, s);
            return this.shapes.push(n), this.addShapeToModifiers(n), this.addToAnimatedContents(e, n), n
        }, SVGShapeElement.prototype.addToAnimatedContents = function (e, t) {
            for (var r = 0, i = this.animatedContents.length; r < i;) {
                if (this.animatedContents[r].element === t) return;
                r += 1
            }
            this.animatedContents.push({
                fn: SVGElementsRenderer.createRenderFunction(e),
                element: t,
                data: e
            })
        }, SVGShapeElement.prototype.setElementStyles = function (e) {
            var t = e.styles,
                r, i = this.stylesList.length;
            for (r = 0; r < i; r += 1) this.stylesList[r].closed || t.push(this.stylesList[r])
        }, SVGShapeElement.prototype.reloadShapes = function () {
            this._isFirstFrame = !0;
            var e, t = this.itemsData.length;
            for (e = 0; e < t; e += 1) this.prevViewData[e] = this.itemsData[e];
            for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes(), t = this.dynamicProperties.length, e = 0; e < t; e += 1) this.dynamicProperties[e].getValue();
            this.renderModifiers()
        }, SVGShapeElement.prototype.searchShapes = function (e, t, r, i, s, n, a) {
            var l = [].concat(n),
                c, g = e.length - 1,
                _, E, P = [],
                x = [],
                y, d, b;
            for (c = g; c >= 0; c -= 1) {
                if (b = this.searchProcessedElement(e[c]), b ? t[c] = r[b - 1] : e[c]._render = a, e[c].ty === "fl" || e[c].ty === "st" || e[c].ty === "gf" || e[c].ty === "gs") b ? t[c].style.closed = !1 : t[c] = this.createStyleElement(e[c], s), e[c]._render && i.appendChild(t[c].style.pElem), P.push(t[c].style);
                else if (e[c].ty === "gr") {
                    if (!b) t[c] = this.createGroupElement(e[c]);
                    else
                        for (E = t[c].it.length, _ = 0; _ < E; _ += 1) t[c].prevViewData[_] = t[c].it[_];
                    this.searchShapes(e[c].it, t[c].it, t[c].prevViewData, t[c].gr, s + 1, l, a), e[c]._render && i.appendChild(t[c].gr)
                } else e[c].ty === "tr" ? (b || (t[c] = this.createTransformElement(e[c], i)), y = t[c].transform, l.push(y)) : e[c].ty === "sh" || e[c].ty === "rc" || e[c].ty === "el" || e[c].ty === "sr" ? (b || (t[c] = this.createShapeElement(e[c], l, s)), this.setElementStyles(t[c])) : e[c].ty === "tm" || e[c].ty === "rd" || e[c].ty === "ms" || e[c].ty === "pb" ? (b ? (d = t[c], d.closed = !1) : (d = ShapeModifiers.getModifier(e[c].ty), d.init(this, e[c]), t[c] = d, this.shapeModifiers.push(d)), x.push(d)) : e[c].ty === "rp" && (b ? (d = t[c], d.closed = !0) : (d = ShapeModifiers.getModifier(e[c].ty), t[c] = d, d.init(this, e, c, t), this.shapeModifiers.push(d), a = !1), x.push(d));
                this.addProcessedElement(e[c], c + 1)
            }
            for (g = P.length, c = 0; c < g; c += 1) P[c].closed = !0;
            for (g = x.length, c = 0; c < g; c += 1) x[c].closed = !0
        }, SVGShapeElement.prototype.renderInnerContent = function () {
            this.renderModifiers();
            var e, t = this.stylesList.length;
            for (e = 0; e < t; e += 1) this.stylesList[e].reset();
            for (this.renderShape(), e = 0; e < t; e += 1)(this.stylesList[e]._mdf || this._isFirstFrame) && (this.stylesList[e].msElem && (this.stylesList[e].msElem.setAttribute("d", this.stylesList[e].d), this.stylesList[e].d = "M0 0" + this.stylesList[e].d), this.stylesList[e].pElem.setAttribute("d", this.stylesList[e].d || "M0 0"))
        }, SVGShapeElement.prototype.renderShape = function () {
            var e, t = this.animatedContents.length,
                r;
            for (e = 0; e < t; e += 1) r = this.animatedContents[e], (this._isFirstFrame || r.element._isAnimated) && r.data !== !0 && r.fn(r.data, r.element, this._isFirstFrame)
        }, SVGShapeElement.prototype.destroy = function () {
            this.destroyBaseElement(), this.shapesData = null, this.itemsData = null
        };

        function SVGTintFilter(e, t) {
            this.filterManager = t;
            var r = createNS("feColorMatrix");
            if (r.setAttribute("type", "matrix"), r.setAttribute("color-interpolation-filters", "linearRGB"), r.setAttribute("values", "0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0"), r.setAttribute("result", "f1"), e.appendChild(r), r = createNS("feColorMatrix"), r.setAttribute("type", "matrix"), r.setAttribute("color-interpolation-filters", "sRGB"), r.setAttribute("values", "1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"), r.setAttribute("result", "f2"), e.appendChild(r), this.matrixFilter = r, t.effectElements[2].p.v !== 100 || t.effectElements[2].p.k) {
                var i = createNS("feMerge");
                e.appendChild(i);
                var s;
                s = createNS("feMergeNode"), s.setAttribute("in", "SourceGraphic"), i.appendChild(s), s = createNS("feMergeNode"), s.setAttribute("in", "f2"), i.appendChild(s)
            }
        }
        SVGTintFilter.prototype.renderFrame = function (e) {
            if (e || this.filterManager._mdf) {
                var t = this.filterManager.effectElements[0].p.v,
                    r = this.filterManager.effectElements[1].p.v,
                    i = this.filterManager.effectElements[2].p.v / 100;
                this.matrixFilter.setAttribute("values", r[0] - t[0] + " 0 0 0 " + t[0] + " " + (r[1] - t[1]) + " 0 0 0 " + t[1] + " " + (r[2] - t[2]) + " 0 0 0 " + t[2] + " 0 0 0 " + i + " 0")
            }
        };

        function SVGFillFilter(e, t) {
            this.filterManager = t;
            var r = createNS("feColorMatrix");
            r.setAttribute("type", "matrix"), r.setAttribute("color-interpolation-filters", "sRGB"), r.setAttribute("values", "1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"), e.appendChild(r), this.matrixFilter = r
        }
        SVGFillFilter.prototype.renderFrame = function (e) {
            if (e || this.filterManager._mdf) {
                var t = this.filterManager.effectElements[2].p.v,
                    r = this.filterManager.effectElements[6].p.v;
                this.matrixFilter.setAttribute("values", "0 0 0 0 " + t[0] + " 0 0 0 0 " + t[1] + " 0 0 0 0 " + t[2] + " 0 0 0 " + r + " 0")
            }
        };

        function SVGGaussianBlurEffect(e, t) {
            e.setAttribute("x", "-100%"), e.setAttribute("y", "-100%"), e.setAttribute("width", "300%"), e.setAttribute("height", "300%"), this.filterManager = t;
            var r = createNS("feGaussianBlur");
            e.appendChild(r), this.feGaussianBlur = r
        }
        SVGGaussianBlurEffect.prototype.renderFrame = function (e) {
            if (e || this.filterManager._mdf) {
                var t = .3,
                    r = this.filterManager.effectElements[0].p.v * t,
                    i = this.filterManager.effectElements[1].p.v,
                    s = i == 3 ? 0 : r,
                    n = i == 2 ? 0 : r;
                this.feGaussianBlur.setAttribute("stdDeviation", s + " " + n);
                var a = this.filterManager.effectElements[2].p.v == 1 ? "wrap" : "duplicate";
                this.feGaussianBlur.setAttribute("edgeMode", a)
            }
        };

        function SVGStrokeEffect(e, t) {
            this.initialized = !1, this.filterManager = t, this.elem = e, this.paths = []
        }
        SVGStrokeEffect.prototype.initialize = function () {
            var e = this.elem.layerElement.children || this.elem.layerElement.childNodes,
                t, r, i, s;
            for (this.filterManager.effectElements[1].p.v === 1 ? (s = this.elem.maskManager.masksProperties.length, i = 0) : (i = this.filterManager.effectElements[0].p.v - 1, s = i + 1), r = createNS("g"), r.setAttribute("fill", "none"), r.setAttribute("stroke-linecap", "round"), r.setAttribute("stroke-dashoffset", 1), i; i < s; i += 1) t = createNS("path"), r.appendChild(t), this.paths.push({
                p: t,
                m: i
            });
            if (this.filterManager.effectElements[10].p.v === 3) {
                var n = createNS("mask"),
                    a = createElementID();
                n.setAttribute("id", a), n.setAttribute("mask-type", "alpha"), n.appendChild(r), this.elem.globalData.defs.appendChild(n);
                var l = createNS("g");
                for (l.setAttribute("mask", "url(" + locationHref + "#" + a + ")"); e[0];) l.appendChild(e[0]);
                this.elem.layerElement.appendChild(l), this.masker = n, r.setAttribute("stroke", "#fff")
            } else if (this.filterManager.effectElements[10].p.v === 1 || this.filterManager.effectElements[10].p.v === 2) {
                if (this.filterManager.effectElements[10].p.v === 2)
                    for (e = this.elem.layerElement.children || this.elem.layerElement.childNodes; e.length;) this.elem.layerElement.removeChild(e[0]);
                this.elem.layerElement.appendChild(r), this.elem.layerElement.removeAttribute("mask"), r.setAttribute("stroke", "#fff")
            }
            this.initialized = !0, this.pathMasker = r
        }, SVGStrokeEffect.prototype.renderFrame = function (e) {
            this.initialized || this.initialize();
            var t, r = this.paths.length,
                i, s;
            for (t = 0; t < r; t += 1)
                if (this.paths[t].m !== -1 && (i = this.elem.maskManager.viewData[this.paths[t].m], s = this.paths[t].p, (e || this.filterManager._mdf || i.prop._mdf) && s.setAttribute("d", i.lastPath), e || this.filterManager.effectElements[9].p._mdf || this.filterManager.effectElements[4].p._mdf || this.filterManager.effectElements[7].p._mdf || this.filterManager.effectElements[8].p._mdf || i.prop._mdf)) {
                    var n;
                    if (this.filterManager.effectElements[7].p.v !== 0 || this.filterManager.effectElements[8].p.v !== 100) {
                        var a = Math.min(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v) * .01,
                            l = Math.max(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v) * .01,
                            c = s.getTotalLength();
                        n = "0 0 0 " + c * a + " ";
                        var g = c * (l - a),
                            _ = 1 + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * .01,
                            E = Math.floor(g / _),
                            P;
                        for (P = 0; P < E; P += 1) n += "1 " + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * .01 + " ";
                        n += "0 " + c * 10 + " 0 0"
                    } else n = "1 " + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * .01;
                    s.setAttribute("stroke-dasharray", n)
                } if ((e || this.filterManager.effectElements[4].p._mdf) && this.pathMasker.setAttribute("stroke-width", this.filterManager.effectElements[4].p.v * 2), (e || this.filterManager.effectElements[6].p._mdf) && this.pathMasker.setAttribute("opacity", this.filterManager.effectElements[6].p.v), (this.filterManager.effectElements[10].p.v === 1 || this.filterManager.effectElements[10].p.v === 2) && (e || this.filterManager.effectElements[3].p._mdf)) {
                var x = this.filterManager.effectElements[3].p.v;
                this.pathMasker.setAttribute("stroke", "rgb(" + bmFloor(x[0] * 255) + "," + bmFloor(x[1] * 255) + "," + bmFloor(x[2] * 255) + ")")
            }
        };

        function SVGTritoneFilter(e, t) {
            this.filterManager = t;
            var r = createNS("feColorMatrix");
            r.setAttribute("type", "matrix"), r.setAttribute("color-interpolation-filters", "linearRGB"), r.setAttribute("values", "0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0"), r.setAttribute("result", "f1"), e.appendChild(r);
            var i = createNS("feComponentTransfer");
            i.setAttribute("color-interpolation-filters", "sRGB"), e.appendChild(i), this.matrixFilter = i;
            var s = createNS("feFuncR");
            s.setAttribute("type", "table"), i.appendChild(s), this.feFuncR = s;
            var n = createNS("feFuncG");
            n.setAttribute("type", "table"), i.appendChild(n), this.feFuncG = n;
            var a = createNS("feFuncB");
            a.setAttribute("type", "table"), i.appendChild(a), this.feFuncB = a
        }
        SVGTritoneFilter.prototype.renderFrame = function (e) {
            if (e || this.filterManager._mdf) {
                var t = this.filterManager.effectElements[0].p.v,
                    r = this.filterManager.effectElements[1].p.v,
                    i = this.filterManager.effectElements[2].p.v,
                    s = i[0] + " " + r[0] + " " + t[0],
                    n = i[1] + " " + r[1] + " " + t[1],
                    a = i[2] + " " + r[2] + " " + t[2];
                this.feFuncR.setAttribute("tableValues", s), this.feFuncG.setAttribute("tableValues", n), this.feFuncB.setAttribute("tableValues", a)
            }
        };

        function SVGProLevelsFilter(e, t) {
            this.filterManager = t;
            var r = this.filterManager.effectElements,
                i = createNS("feComponentTransfer");
            (r[10].p.k || r[10].p.v !== 0 || r[11].p.k || r[11].p.v !== 1 || r[12].p.k || r[12].p.v !== 1 || r[13].p.k || r[13].p.v !== 0 || r[14].p.k || r[14].p.v !== 1) && (this.feFuncR = this.createFeFunc("feFuncR", i)), (r[17].p.k || r[17].p.v !== 0 || r[18].p.k || r[18].p.v !== 1 || r[19].p.k || r[19].p.v !== 1 || r[20].p.k || r[20].p.v !== 0 || r[21].p.k || r[21].p.v !== 1) && (this.feFuncG = this.createFeFunc("feFuncG", i)), (r[24].p.k || r[24].p.v !== 0 || r[25].p.k || r[25].p.v !== 1 || r[26].p.k || r[26].p.v !== 1 || r[27].p.k || r[27].p.v !== 0 || r[28].p.k || r[28].p.v !== 1) && (this.feFuncB = this.createFeFunc("feFuncB", i)), (r[31].p.k || r[31].p.v !== 0 || r[32].p.k || r[32].p.v !== 1 || r[33].p.k || r[33].p.v !== 1 || r[34].p.k || r[34].p.v !== 0 || r[35].p.k || r[35].p.v !== 1) && (this.feFuncA = this.createFeFunc("feFuncA", i)), (this.feFuncR || this.feFuncG || this.feFuncB || this.feFuncA) && (i.setAttribute("color-interpolation-filters", "sRGB"), e.appendChild(i), i = createNS("feComponentTransfer")), (r[3].p.k || r[3].p.v !== 0 || r[4].p.k || r[4].p.v !== 1 || r[5].p.k || r[5].p.v !== 1 || r[6].p.k || r[6].p.v !== 0 || r[7].p.k || r[7].p.v !== 1) && (i.setAttribute("color-interpolation-filters", "sRGB"), e.appendChild(i), this.feFuncRComposed = this.createFeFunc("feFuncR", i), this.feFuncGComposed = this.createFeFunc("feFuncG", i), this.feFuncBComposed = this.createFeFunc("feFuncB", i))
        }
        SVGProLevelsFilter.prototype.createFeFunc = function (e, t) {
            var r = createNS(e);
            return r.setAttribute("type", "table"), t.appendChild(r), r
        }, SVGProLevelsFilter.prototype.getTableValue = function (e, t, r, i, s) {
            for (var n = 0, a = 256, l, c = Math.min(e, t), g = Math.max(e, t), _ = Array.call(null, {
                    length: a
                }), E, P = 0, x = s - i, y = t - e; n <= 256;) l = n / 256, l <= c ? E = y < 0 ? s : i : l >= g ? E = y < 0 ? i : s : E = i + x * Math.pow((l - e) / y, 1 / r), _[P] = E, P += 1, n += 256 / (a - 1);
            return _.join(" ")
        }, SVGProLevelsFilter.prototype.renderFrame = function (e) {
            if (e || this.filterManager._mdf) {
                var t, r = this.filterManager.effectElements;
                this.feFuncRComposed && (e || r[3].p._mdf || r[4].p._mdf || r[5].p._mdf || r[6].p._mdf || r[7].p._mdf) && (t = this.getTableValue(r[3].p.v, r[4].p.v, r[5].p.v, r[6].p.v, r[7].p.v), this.feFuncRComposed.setAttribute("tableValues", t), this.feFuncGComposed.setAttribute("tableValues", t), this.feFuncBComposed.setAttribute("tableValues", t)), this.feFuncR && (e || r[10].p._mdf || r[11].p._mdf || r[12].p._mdf || r[13].p._mdf || r[14].p._mdf) && (t = this.getTableValue(r[10].p.v, r[11].p.v, r[12].p.v, r[13].p.v, r[14].p.v), this.feFuncR.setAttribute("tableValues", t)), this.feFuncG && (e || r[17].p._mdf || r[18].p._mdf || r[19].p._mdf || r[20].p._mdf || r[21].p._mdf) && (t = this.getTableValue(r[17].p.v, r[18].p.v, r[19].p.v, r[20].p.v, r[21].p.v), this.feFuncG.setAttribute("tableValues", t)), this.feFuncB && (e || r[24].p._mdf || r[25].p._mdf || r[26].p._mdf || r[27].p._mdf || r[28].p._mdf) && (t = this.getTableValue(r[24].p.v, r[25].p.v, r[26].p.v, r[27].p.v, r[28].p.v), this.feFuncB.setAttribute("tableValues", t)), this.feFuncA && (e || r[31].p._mdf || r[32].p._mdf || r[33].p._mdf || r[34].p._mdf || r[35].p._mdf) && (t = this.getTableValue(r[31].p.v, r[32].p.v, r[33].p.v, r[34].p.v, r[35].p.v), this.feFuncA.setAttribute("tableValues", t))
            }
        };

        function SVGDropShadowEffect(e, t) {
            var r = t.container.globalData.renderConfig.filterSize;
            e.setAttribute("x", r.x), e.setAttribute("y", r.y), e.setAttribute("width", r.width), e.setAttribute("height", r.height), this.filterManager = t;
            var i = createNS("feGaussianBlur");
            i.setAttribute("in", "SourceAlpha"), i.setAttribute("result", "drop_shadow_1"), i.setAttribute("stdDeviation", "0"), this.feGaussianBlur = i, e.appendChild(i);
            var s = createNS("feOffset");
            s.setAttribute("dx", "25"), s.setAttribute("dy", "0"), s.setAttribute("in", "drop_shadow_1"), s.setAttribute("result", "drop_shadow_2"), this.feOffset = s, e.appendChild(s);
            var n = createNS("feFlood");
            n.setAttribute("flood-color", "#00ff00"), n.setAttribute("flood-opacity", "1"), n.setAttribute("result", "drop_shadow_3"), this.feFlood = n, e.appendChild(n);
            var a = createNS("feComposite");
            a.setAttribute("in", "drop_shadow_3"), a.setAttribute("in2", "drop_shadow_2"), a.setAttribute("operator", "in"), a.setAttribute("result", "drop_shadow_4"), e.appendChild(a);
            var l = createNS("feMerge");
            e.appendChild(l);
            var c;
            c = createNS("feMergeNode"), l.appendChild(c), c = createNS("feMergeNode"), c.setAttribute("in", "SourceGraphic"), this.feMergeNode = c, this.feMerge = l, this.originalNodeAdded = !1, l.appendChild(c)
        }
        SVGDropShadowEffect.prototype.renderFrame = function (e) {
            if (e || this.filterManager._mdf) {
                if ((e || this.filterManager.effectElements[4].p._mdf) && this.feGaussianBlur.setAttribute("stdDeviation", this.filterManager.effectElements[4].p.v / 4), e || this.filterManager.effectElements[0].p._mdf) {
                    var t = this.filterManager.effectElements[0].p.v;
                    this.feFlood.setAttribute("flood-color", rgbToHex(Math.round(t[0] * 255), Math.round(t[1] * 255), Math.round(t[2] * 255)))
                }
                if ((e || this.filterManager.effectElements[1].p._mdf) && this.feFlood.setAttribute("flood-opacity", this.filterManager.effectElements[1].p.v / 255), e || this.filterManager.effectElements[2].p._mdf || this.filterManager.effectElements[3].p._mdf) {
                    var r = this.filterManager.effectElements[3].p.v,
                        i = (this.filterManager.effectElements[2].p.v - 90) * degToRads,
                        s = r * Math.cos(i),
                        n = r * Math.sin(i);
                    this.feOffset.setAttribute("dx", s), this.feOffset.setAttribute("dy", n)
                }
            }
        };
        var _svgMatteSymbols = [];

        function SVGMatte3Effect(e, t, r) {
            this.initialized = !1, this.filterManager = t, this.filterElem = e, this.elem = r, r.matteElement = createNS("g"), r.matteElement.appendChild(r.layerElement), r.matteElement.appendChild(r.transformedElement), r.baseElement = r.matteElement
        }
        SVGMatte3Effect.prototype.findSymbol = function (e) {
            for (var t = 0, r = _svgMatteSymbols.length; t < r;) {
                if (_svgMatteSymbols[t] === e) return _svgMatteSymbols[t];
                t += 1
            }
            return null
        }, SVGMatte3Effect.prototype.replaceInParent = function (e, t) {
            var r = e.layerElement.parentNode;
            if (r) {
                for (var i = r.children, s = 0, n = i.length; s < n && i[s] !== e.layerElement;) s += 1;
                var a;
                s <= n - 2 && (a = i[s + 1]);
                var l = createNS("use");
                l.setAttribute("href", "#" + t), a ? r.insertBefore(l, a) : r.appendChild(l)
            }
        }, SVGMatte3Effect.prototype.setElementAsMask = function (e, t) {
            if (!this.findSymbol(t)) {
                var r = createElementID(),
                    i = createNS("mask");
                i.setAttribute("id", t.layerId), i.setAttribute("mask-type", "alpha"), _svgMatteSymbols.push(t);
                var s = e.globalData.defs;
                s.appendChild(i);
                var n = createNS("symbol");
                n.setAttribute("id", r), this.replaceInParent(t, r), n.appendChild(t.layerElement), s.appendChild(n);
                var a = createNS("use");
                a.setAttribute("href", "#" + r), i.appendChild(a), t.data.hd = !1, t.show()
            }
            e.setMatte(t.layerId)
        }, SVGMatte3Effect.prototype.initialize = function () {
            for (var e = this.filterManager.effectElements[0].p.v, t = this.elem.comp.elements, r = 0, i = t.length; r < i;) t[r] && t[r].data.ind === e && this.setElementAsMask(this.elem, t[r]), r += 1;
            this.initialized = !0
        }, SVGMatte3Effect.prototype.renderFrame = function () {
            this.initialized || this.initialize()
        };

        function SVGEffects(e) {
            var t, r = e.data.ef ? e.data.ef.length : 0,
                i = createElementID(),
                s = filtersFactory.createFilter(i, !0),
                n = 0;
            this.filters = [];
            var a;
            for (t = 0; t < r; t += 1) a = null, e.data.ef[t].ty === 20 ? (n += 1, a = new SVGTintFilter(s, e.effectsManager.effectElements[t])) : e.data.ef[t].ty === 21 ? (n += 1, a = new SVGFillFilter(s, e.effectsManager.effectElements[t])) : e.data.ef[t].ty === 22 ? a = new SVGStrokeEffect(e, e.effectsManager.effectElements[t]) : e.data.ef[t].ty === 23 ? (n += 1, a = new SVGTritoneFilter(s, e.effectsManager.effectElements[t])) : e.data.ef[t].ty === 24 ? (n += 1, a = new SVGProLevelsFilter(s, e.effectsManager.effectElements[t])) : e.data.ef[t].ty === 25 ? (n += 1, a = new SVGDropShadowEffect(s, e.effectsManager.effectElements[t])) : e.data.ef[t].ty === 28 ? a = new SVGMatte3Effect(s, e.effectsManager.effectElements[t], e) : e.data.ef[t].ty === 29 && (n += 1, a = new SVGGaussianBlurEffect(s, e.effectsManager.effectElements[t])), a && this.filters.push(a);
            n && (e.globalData.defs.appendChild(s), e.layerElement.setAttribute("filter", "url(" + locationHref + "#" + i + ")")), this.filters.length && e.addRenderableComponent(this)
        }
        SVGEffects.prototype.renderFrame = function (e) {
            var t, r = this.filters.length;
            for (t = 0; t < r; t += 1) this.filters[t].renderFrame(e)
        };

        function CVContextData() {
            this.saved = [], this.cArrPos = 0, this.cTr = new Matrix, this.cO = 1;
            var e, t = 15;
            for (this.savedOp = createTypedArray("float32", t), e = 0; e < t; e += 1) this.saved[e] = createTypedArray("float32", 16);
            this._length = t
        }
        CVContextData.prototype.duplicate = function () {
            var e = this._length * 2,
                t = this.savedOp;
            this.savedOp = createTypedArray("float32", e), this.savedOp.set(t);
            var r = 0;
            for (r = this._length; r < e; r += 1) this.saved[r] = createTypedArray("float32", 16);
            this._length = e
        }, CVContextData.prototype.reset = function () {
            this.cArrPos = 0, this.cTr.reset(), this.cO = 1
        };

        function CVBaseElement() {}
        CVBaseElement.prototype = {
            createElements: function () {},
            initRendererElement: function () {},
            createContainerElements: function () {
                this.canvasContext = this.globalData.canvasContext, this.renderableEffectsManager = new CVEffects
            },
            createContent: function () {},
            setBlendMode: function () {
                var e = this.globalData;
                if (e.blendMode !== this.data.bm) {
                    e.blendMode = this.data.bm;
                    var t = getBlendMode(this.data.bm);
                    e.canvasContext.globalCompositeOperation = t
                }
            },
            createRenderableComponents: function () {
                this.maskManager = new CVMaskElement(this.data, this)
            },
            hideElement: function () {
                !this.hidden && (!this.isInRange || this.isTransparent) && (this.hidden = !0)
            },
            showElement: function () {
                this.isInRange && !this.isTransparent && (this.hidden = !1, this._isFirstFrame = !0, this.maskManager._isFirstFrame = !0)
            },
            renderFrame: function () {
                if (!(this.hidden || this.data.hd)) {
                    this.renderTransform(), this.renderRenderable(), this.setBlendMode();
                    var e = this.data.ty === 0;
                    this.globalData.renderer.save(e), this.globalData.renderer.ctxTransform(this.finalTransform.mat.props), this.globalData.renderer.ctxOpacity(this.finalTransform.mProp.o.v), this.renderInnerContent(), this.globalData.renderer.restore(e), this.maskManager.hasMasks && this.globalData.renderer.restore(!0), this._isFirstFrame && (this._isFirstFrame = !1)
                }
            },
            destroy: function () {
                this.canvasContext = null, this.data = null, this.globalData = null, this.maskManager.destroy()
            },
            mHelper: new Matrix
        }, CVBaseElement.prototype.hide = CVBaseElement.prototype.hideElement, CVBaseElement.prototype.show = CVBaseElement.prototype.showElement;

        function CVImageElement(e, t, r) {
            this.assetData = t.getAssetData(e.refId), this.img = t.imageLoader.getAsset(this.assetData), this.initElement(e, t, r)
        }
        extendPrototype([BaseElement, TransformElement, CVBaseElement, HierarchyElement, FrameElement, RenderableElement], CVImageElement), CVImageElement.prototype.initElement = SVGShapeElement.prototype.initElement, CVImageElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame, CVImageElement.prototype.createContent = function () {
            if (this.img.width && (this.assetData.w !== this.img.width || this.assetData.h !== this.img.height)) {
                var e = createTag("canvas");
                e.width = this.assetData.w, e.height = this.assetData.h;
                var t = e.getContext("2d"),
                    r = this.img.width,
                    i = this.img.height,
                    s = r / i,
                    n = this.assetData.w / this.assetData.h,
                    a, l, c = this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio;
                s > n && c === "xMidYMid slice" || s < n && c !== "xMidYMid slice" ? (l = i, a = l * n) : (a = r, l = a / n), t.drawImage(this.img, (r - a) / 2, (i - l) / 2, a, l, 0, 0, this.assetData.w, this.assetData.h), this.img = e
            }
        }, CVImageElement.prototype.renderInnerContent = function () {
            this.canvasContext.drawImage(this.img, 0, 0)
        }, CVImageElement.prototype.destroy = function () {
            this.img = null
        };

        function CVCompElement(e, t, r) {
            this.completeLayers = !1, this.layers = e.layers, this.pendingElements = [], this.elements = createSizedArray(this.layers.length), this.initElement(e, t, r), this.tm = e.tm ? PropertyFactory.getProp(this, e.tm, 0, t.frameRate, this) : {
                _placeholder: !0
            }
        }
        extendPrototype([CanvasRenderer, ICompElement, CVBaseElement], CVCompElement), CVCompElement.prototype.renderInnerContent = function () {
            var e = this.canvasContext;
            e.beginPath(), e.moveTo(0, 0), e.lineTo(this.data.w, 0), e.lineTo(this.data.w, this.data.h), e.lineTo(0, this.data.h), e.lineTo(0, 0), e.clip();
            var t, r = this.layers.length;
            for (t = r - 1; t >= 0; t -= 1)(this.completeLayers || this.elements[t]) && this.elements[t].renderFrame()
        }, CVCompElement.prototype.destroy = function () {
            var e, t = this.layers.length;
            for (e = t - 1; e >= 0; e -= 1) this.elements[e] && this.elements[e].destroy();
            this.layers = null, this.elements = null
        };

        function CVMaskElement(e, t) {
            this.data = e, this.element = t, this.masksProperties = this.data.masksProperties || [], this.viewData = createSizedArray(this.masksProperties.length);
            var r, i = this.masksProperties.length,
                s = !1;
            for (r = 0; r < i; r += 1) this.masksProperties[r].mode !== "n" && (s = !0), this.viewData[r] = ShapePropertyFactory.getShapeProp(this.element, this.masksProperties[r], 3);
            this.hasMasks = s, s && this.element.addRenderableComponent(this)
        }
        CVMaskElement.prototype.renderFrame = function () {
            if (this.hasMasks) {
                var e = this.element.finalTransform.mat,
                    t = this.element.canvasContext,
                    r, i = this.masksProperties.length,
                    s, n, a;
                for (t.beginPath(), r = 0; r < i; r += 1)
                    if (this.masksProperties[r].mode !== "n") {
                        this.masksProperties[r].inv && (t.moveTo(0, 0), t.lineTo(this.element.globalData.compSize.w, 0), t.lineTo(this.element.globalData.compSize.w, this.element.globalData.compSize.h), t.lineTo(0, this.element.globalData.compSize.h), t.lineTo(0, 0)), a = this.viewData[r].v, s = e.applyToPointArray(a.v[0][0], a.v[0][1], 0), t.moveTo(s[0], s[1]);
                        var l, c = a._length;
                        for (l = 1; l < c; l += 1) n = e.applyToTriplePoints(a.o[l - 1], a.i[l], a.v[l]), t.bezierCurveTo(n[0], n[1], n[2], n[3], n[4], n[5]);
                        n = e.applyToTriplePoints(a.o[l - 1], a.i[0], a.v[0]), t.bezierCurveTo(n[0], n[1], n[2], n[3], n[4], n[5])
                    } this.element.globalData.renderer.save(!0), t.clip()
            }
        }, CVMaskElement.prototype.getMaskProperty = MaskElement.prototype.getMaskProperty, CVMaskElement.prototype.destroy = function () {
            this.element = null
        };

        function CVShapeElement(e, t, r) {
            this.shapes = [], this.shapesData = e.shapes, this.stylesList = [], this.itemsData = [], this.prevViewData = [], this.shapeModifiers = [], this.processedElements = [], this.transformsManager = new ShapeTransformManager, this.initElement(e, t, r)
        }
        extendPrototype([BaseElement, TransformElement, CVBaseElement, IShapeElement, HierarchyElement, FrameElement, RenderableElement], CVShapeElement), CVShapeElement.prototype.initElement = RenderableDOMElement.prototype.initElement, CVShapeElement.prototype.transformHelper = {
            opacity: 1,
            _opMdf: !1
        }, CVShapeElement.prototype.dashResetter = [], CVShapeElement.prototype.createContent = function () {
            this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, !0, [])
        }, CVShapeElement.prototype.createStyleElement = function (e, t) {
            var r = {
                    data: e,
                    type: e.ty,
                    preTransforms: this.transformsManager.addTransformSequence(t),
                    transforms: [],
                    elements: [],
                    closed: e.hd === !0
                },
                i = {};
            if (e.ty === "fl" || e.ty === "st" ? (i.c = PropertyFactory.getProp(this, e.c, 1, 255, this), i.c.k || (r.co = "rgb(" + bmFloor(i.c.v[0]) + "," + bmFloor(i.c.v[1]) + "," + bmFloor(i.c.v[2]) + ")")) : (e.ty === "gf" || e.ty === "gs") && (i.s = PropertyFactory.getProp(this, e.s, 1, null, this), i.e = PropertyFactory.getProp(this, e.e, 1, null, this), i.h = PropertyFactory.getProp(this, e.h || {
                    k: 0
                }, 0, .01, this), i.a = PropertyFactory.getProp(this, e.a || {
                    k: 0
                }, 0, degToRads, this), i.g = new GradientProperty(this, e.g, this)), i.o = PropertyFactory.getProp(this, e.o, 0, .01, this), e.ty === "st" || e.ty === "gs") {
                if (r.lc = lineCapEnum[e.lc || 2], r.lj = lineJoinEnum[e.lj || 2], e.lj == 1 && (r.ml = e.ml), i.w = PropertyFactory.getProp(this, e.w, 0, null, this), i.w.k || (r.wi = i.w.v), e.d) {
                    var s = new DashProperty(this, e.d, "canvas", this);
                    i.d = s, i.d.k || (r.da = i.d.dashArray, r.do = i.d.dashoffset[0])
                }
            } else r.r = e.r === 2 ? "evenodd" : "nonzero";
            return this.stylesList.push(r), i.style = r, i
        }, CVShapeElement.prototype.createGroupElement = function () {
            var e = {
                it: [],
                prevViewData: []
            };
            return e
        }, CVShapeElement.prototype.createTransformElement = function (e) {
            var t = {
                transform: {
                    opacity: 1,
                    _opMdf: !1,
                    key: this.transformsManager.getNewKey(),
                    op: PropertyFactory.getProp(this, e.o, 0, .01, this),
                    mProps: TransformPropertyFactory.getTransformProperty(this, e, this)
                }
            };
            return t
        }, CVShapeElement.prototype.createShapeElement = function (e) {
            var t = new CVShapeData(this, e, this.stylesList, this.transformsManager);
            return this.shapes.push(t), this.addShapeToModifiers(t), t
        }, CVShapeElement.prototype.reloadShapes = function () {
            this._isFirstFrame = !0;
            var e, t = this.itemsData.length;
            for (e = 0; e < t; e += 1) this.prevViewData[e] = this.itemsData[e];
            for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, !0, []), t = this.dynamicProperties.length, e = 0; e < t; e += 1) this.dynamicProperties[e].getValue();
            this.renderModifiers(), this.transformsManager.processSequences(this._isFirstFrame)
        }, CVShapeElement.prototype.addTransformToStyleList = function (e) {
            var t, r = this.stylesList.length;
            for (t = 0; t < r; t += 1) this.stylesList[t].closed || this.stylesList[t].transforms.push(e)
        }, CVShapeElement.prototype.removeTransformFromStyleList = function () {
            var e, t = this.stylesList.length;
            for (e = 0; e < t; e += 1) this.stylesList[e].closed || this.stylesList[e].transforms.pop()
        }, CVShapeElement.prototype.closeStyles = function (e) {
            var t, r = e.length;
            for (t = 0; t < r; t += 1) e[t].closed = !0
        }, CVShapeElement.prototype.searchShapes = function (e, t, r, i, s) {
            var n, a = e.length - 1,
                l, c, g = [],
                _ = [],
                E, P, x, y = [].concat(s);
            for (n = a; n >= 0; n -= 1) {
                if (E = this.searchProcessedElement(e[n]), E ? t[n] = r[E - 1] : e[n]._shouldRender = i, e[n].ty === "fl" || e[n].ty === "st" || e[n].ty === "gf" || e[n].ty === "gs") E ? t[n].style.closed = !1 : t[n] = this.createStyleElement(e[n], y), g.push(t[n].style);
                else if (e[n].ty === "gr") {
                    if (!E) t[n] = this.createGroupElement(e[n]);
                    else
                        for (c = t[n].it.length, l = 0; l < c; l += 1) t[n].prevViewData[l] = t[n].it[l];
                    this.searchShapes(e[n].it, t[n].it, t[n].prevViewData, i, y)
                } else e[n].ty === "tr" ? (E || (x = this.createTransformElement(e[n]), t[n] = x), y.push(t[n]), this.addTransformToStyleList(t[n])) : e[n].ty === "sh" || e[n].ty === "rc" || e[n].ty === "el" || e[n].ty === "sr" ? E || (t[n] = this.createShapeElement(e[n])) : e[n].ty === "tm" || e[n].ty === "rd" || e[n].ty === "pb" ? (E ? (P = t[n], P.closed = !1) : (P = ShapeModifiers.getModifier(e[n].ty), P.init(this, e[n]), t[n] = P, this.shapeModifiers.push(P)), _.push(P)) : e[n].ty === "rp" && (E ? (P = t[n], P.closed = !0) : (P = ShapeModifiers.getModifier(e[n].ty), t[n] = P, P.init(this, e, n, t), this.shapeModifiers.push(P), i = !1), _.push(P));
                this.addProcessedElement(e[n], n + 1)
            }
            for (this.removeTransformFromStyleList(), this.closeStyles(g), a = _.length, n = 0; n < a; n += 1) _[n].closed = !0
        }, CVShapeElement.prototype.renderInnerContent = function () {
            this.transformHelper.opacity = 1, this.transformHelper._opMdf = !1, this.renderModifiers(), this.transformsManager.processSequences(this._isFirstFrame), this.renderShape(this.transformHelper, this.shapesData, this.itemsData, !0)
        }, CVShapeElement.prototype.renderShapeTransform = function (e, t) {
            (e._opMdf || t.op._mdf || this._isFirstFrame) && (t.opacity = e.opacity, t.opacity *= t.op.v, t._opMdf = !0)
        }, CVShapeElement.prototype.drawLayer = function () {
            var e, t = this.stylesList.length,
                r, i, s, n, a, l, c = this.globalData.renderer,
                g = this.globalData.canvasContext,
                _, E;
            for (e = 0; e < t; e += 1)
                if (E = this.stylesList[e], _ = E.type, !((_ === "st" || _ === "gs") && E.wi === 0 || !E.data._shouldRender || E.coOp === 0 || this.globalData.currentGlobalAlpha === 0)) {
                    for (c.save(), a = E.elements, _ === "st" || _ === "gs" ? (g.strokeStyle = _ === "st" ? E.co : E.grd, g.lineWidth = E.wi, g.lineCap = E.lc, g.lineJoin = E.lj, g.miterLimit = E.ml || 0) : g.fillStyle = _ === "fl" ? E.co : E.grd, c.ctxOpacity(E.coOp), _ !== "st" && _ !== "gs" && g.beginPath(), c.ctxTransform(E.preTransforms.finalTransform.props), i = a.length, r = 0; r < i; r += 1) {
                        for ((_ === "st" || _ === "gs") && (g.beginPath(), E.da && (g.setLineDash(E.da), g.lineDashOffset = E.do)), l = a[r].trNodes, n = l.length, s = 0; s < n; s += 1) l[s].t === "m" ? g.moveTo(l[s].p[0], l[s].p[1]) : l[s].t === "c" ? g.bezierCurveTo(l[s].pts[0], l[s].pts[1], l[s].pts[2], l[s].pts[3], l[s].pts[4], l[s].pts[5]) : g.closePath();
                        (_ === "st" || _ === "gs") && (g.stroke(), E.da && g.setLineDash(this.dashResetter))
                    }
                    _ !== "st" && _ !== "gs" && g.fill(E.r), c.restore()
                }
        }, CVShapeElement.prototype.renderShape = function (e, t, r, i) {
            var s, n = t.length - 1,
                a;
            for (a = e, s = n; s >= 0; s -= 1) t[s].ty === "tr" ? (a = r[s].transform, this.renderShapeTransform(e, a)) : t[s].ty === "sh" || t[s].ty === "el" || t[s].ty === "rc" || t[s].ty === "sr" ? this.renderPath(t[s], r[s]) : t[s].ty === "fl" ? this.renderFill(t[s], r[s], a) : t[s].ty === "st" ? this.renderStroke(t[s], r[s], a) : t[s].ty === "gf" || t[s].ty === "gs" ? this.renderGradientFill(t[s], r[s], a) : t[s].ty === "gr" ? this.renderShape(a, t[s].it, r[s].it) : t[s].ty;
            i && this.drawLayer()
        }, CVShapeElement.prototype.renderStyledShape = function (e, t) {
            if (this._isFirstFrame || t._mdf || e.transforms._mdf) {
                var r = e.trNodes,
                    i = t.paths,
                    s, n, a, l = i._length;
                r.length = 0;
                var c = e.transforms.finalTransform;
                for (a = 0; a < l; a += 1) {
                    var g = i.shapes[a];
                    if (g && g.v) {
                        for (n = g._length, s = 1; s < n; s += 1) s === 1 && r.push({
                            t: "m",
                            p: c.applyToPointArray(g.v[0][0], g.v[0][1], 0)
                        }), r.push({
                            t: "c",
                            pts: c.applyToTriplePoints(g.o[s - 1], g.i[s], g.v[s])
                        });
                        n === 1 && r.push({
                            t: "m",
                            p: c.applyToPointArray(g.v[0][0], g.v[0][1], 0)
                        }), g.c && n && (r.push({
                            t: "c",
                            pts: c.applyToTriplePoints(g.o[s - 1], g.i[0], g.v[0])
                        }), r.push({
                            t: "z"
                        }))
                    }
                }
                e.trNodes = r
            }
        }, CVShapeElement.prototype.renderPath = function (e, t) {
            if (e.hd !== !0 && e._shouldRender) {
                var r, i = t.styledShapes.length;
                for (r = 0; r < i; r += 1) this.renderStyledShape(t.styledShapes[r], t.sh)
            }
        }, CVShapeElement.prototype.renderFill = function (e, t, r) {
            var i = t.style;
            (t.c._mdf || this._isFirstFrame) && (i.co = "rgb(" + bmFloor(t.c.v[0]) + "," + bmFloor(t.c.v[1]) + "," + bmFloor(t.c.v[2]) + ")"), (t.o._mdf || r._opMdf || this._isFirstFrame) && (i.coOp = t.o.v * r.opacity)
        }, CVShapeElement.prototype.renderGradientFill = function (e, t, r) {
            var i = t.style,
                s;
            if (!i.grd || t.g._mdf || t.s._mdf || t.e._mdf || e.t !== 1 && (t.h._mdf || t.a._mdf)) {
                var n = this.globalData.canvasContext,
                    a = t.s.v,
                    l = t.e.v;
                if (e.t === 1) s = n.createLinearGradient(a[0], a[1], l[0], l[1]);
                else {
                    var c = Math.sqrt(Math.pow(a[0] - l[0], 2) + Math.pow(a[1] - l[1], 2)),
                        g = Math.atan2(l[1] - a[1], l[0] - a[0]),
                        _ = t.h.v;
                    _ >= 1 ? _ = .99 : _ <= -1 && (_ = -.99);
                    var E = c * _,
                        P = Math.cos(g + t.a.v) * E + a[0],
                        x = Math.sin(g + t.a.v) * E + a[1];
                    s = n.createRadialGradient(P, x, 0, a[0], a[1], c)
                }
                var y, d = e.g.p,
                    b = t.g.c,
                    m = 1;
                for (y = 0; y < d; y += 1) t.g._hasOpacity && t.g._collapsable && (m = t.g.o[y * 2 + 1]), s.addColorStop(b[y * 4] / 100, "rgba(" + b[y * 4 + 1] + "," + b[y * 4 + 2] + "," + b[y * 4 + 3] + "," + m + ")");
                i.grd = s
            }
            i.coOp = t.o.v * r.opacity
        }, CVShapeElement.prototype.renderStroke = function (e, t, r) {
            var i = t.style,
                s = t.d;
            s && (s._mdf || this._isFirstFrame) && (i.da = s.dashArray, i.do = s.dashoffset[0]), (t.c._mdf || this._isFirstFrame) && (i.co = "rgb(" + bmFloor(t.c.v[0]) + "," + bmFloor(t.c.v[1]) + "," + bmFloor(t.c.v[2]) + ")"), (t.o._mdf || r._opMdf || this._isFirstFrame) && (i.coOp = t.o.v * r.opacity), (t.w._mdf || this._isFirstFrame) && (i.wi = t.w.v)
        }, CVShapeElement.prototype.destroy = function () {
            this.shapesData = null, this.globalData = null, this.canvasContext = null, this.stylesList.length = 0, this.itemsData.length = 0
        };

        function CVSolidElement(e, t, r) {
            this.initElement(e, t, r)
        }
        extendPrototype([BaseElement, TransformElement, CVBaseElement, HierarchyElement, FrameElement, RenderableElement], CVSolidElement), CVSolidElement.prototype.initElement = SVGShapeElement.prototype.initElement, CVSolidElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame, CVSolidElement.prototype.renderInnerContent = function () {
            var e = this.canvasContext;
            e.fillStyle = this.data.sc, e.fillRect(0, 0, this.data.sw, this.data.sh)
        };

        function CVTextElement(e, t, r) {
            this.textSpans = [], this.yOffset = 0, this.fillColorAnim = !1, this.strokeColorAnim = !1, this.strokeWidthAnim = !1, this.stroke = !1, this.fill = !1, this.justifyOffset = 0, this.currentRender = null, this.renderType = "canvas", this.values = {
                fill: "rgba(0,0,0,0)",
                stroke: "rgba(0,0,0,0)",
                sWidth: 0,
                fValue: ""
            }, this.initElement(e, t, r)
        }
        extendPrototype([BaseElement, TransformElement, CVBaseElement, HierarchyElement, FrameElement, RenderableElement, ITextElement], CVTextElement), CVTextElement.prototype.tHelper = createTag("canvas").getContext("2d"), CVTextElement.prototype.buildNewText = function () {
            var e = this.textProperty.currentData;
            this.renderedLetters = createSizedArray(e.l ? e.l.length : 0);
            var t = !1;
            e.fc ? (t = !0, this.values.fill = this.buildColor(e.fc)) : this.values.fill = "rgba(0,0,0,0)", this.fill = t;
            var r = !1;
            e.sc && (r = !0, this.values.stroke = this.buildColor(e.sc), this.values.sWidth = e.sw);
            var i = this.globalData.fontManager.getFontByName(e.f),
                s, n, a = e.l,
                l = this.mHelper;
            this.stroke = r, this.values.fValue = e.finalSize + "px " + this.globalData.fontManager.getFontByName(e.f).fFamily, n = e.finalText.length;
            var c, g, _, E, P, x, y, d, b, m, o = this.data.singleShape,
                f = e.tr * .001 * e.finalSize,
                u = 0,
                S = 0,
                k = !0,
                C = 0;
            for (s = 0; s < n; s += 1) {
                for (c = this.globalData.fontManager.getCharData(e.finalText[s], i.fStyle, this.globalData.fontManager.getFontByName(e.f).fFamily), g = c && c.data || {}, l.reset(), o && a[s].n && (u = -f, S += e.yOffset, S += k ? 1 : 0, k = !1), P = g.shapes ? g.shapes[0].it : [], y = P.length, l.scale(e.finalSize / 100, e.finalSize / 100), o && this.applyTextPropertiesToMatrix(e, l, a[s].line, u, S), b = createSizedArray(y), x = 0; x < y; x += 1) {
                    for (E = P[x].ks.k.i.length, d = P[x].ks.k, m = [], _ = 1; _ < E; _ += 1) _ === 1 && m.push(l.applyToX(d.v[0][0], d.v[0][1], 0), l.applyToY(d.v[0][0], d.v[0][1], 0)), m.push(l.applyToX(d.o[_ - 1][0], d.o[_ - 1][1], 0), l.applyToY(d.o[_ - 1][0], d.o[_ - 1][1], 0), l.applyToX(d.i[_][0], d.i[_][1], 0), l.applyToY(d.i[_][0], d.i[_][1], 0), l.applyToX(d.v[_][0], d.v[_][1], 0), l.applyToY(d.v[_][0], d.v[_][1], 0));
                    m.push(l.applyToX(d.o[_ - 1][0], d.o[_ - 1][1], 0), l.applyToY(d.o[_ - 1][0], d.o[_ - 1][1], 0), l.applyToX(d.i[0][0], d.i[0][1], 0), l.applyToY(d.i[0][0], d.i[0][1], 0), l.applyToX(d.v[0][0], d.v[0][1], 0), l.applyToY(d.v[0][0], d.v[0][1], 0)), b[x] = m
                }
                o && (u += a[s].l, u += f), this.textSpans[C] ? this.textSpans[C].elem = b : this.textSpans[C] = {
                    elem: b
                }, C += 1
            }
        }, CVTextElement.prototype.renderInnerContent = function () {
            var e = this.canvasContext;
            e.font = this.values.fValue, e.lineCap = "butt", e.lineJoin = "miter", e.miterLimit = 4, this.data.singleShape || this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag);
            var t, r, i, s, n, a, l = this.textAnimator.renderedLetters,
                c = this.textProperty.currentData.l;
            r = c.length;
            var g, _ = null,
                E = null,
                P = null,
                x, y;
            for (t = 0; t < r; t += 1)
                if (!c[t].n) {
                    if (g = l[t], g && (this.globalData.renderer.save(), this.globalData.renderer.ctxTransform(g.p), this.globalData.renderer.ctxOpacity(g.o)), this.fill) {
                        for (g && g.fc ? _ !== g.fc && (_ = g.fc, e.fillStyle = g.fc) : _ !== this.values.fill && (_ = this.values.fill, e.fillStyle = this.values.fill), x = this.textSpans[t].elem, s = x.length, this.globalData.canvasContext.beginPath(), i = 0; i < s; i += 1)
                            for (y = x[i], a = y.length, this.globalData.canvasContext.moveTo(y[0], y[1]), n = 2; n < a; n += 6) this.globalData.canvasContext.bezierCurveTo(y[n], y[n + 1], y[n + 2], y[n + 3], y[n + 4], y[n + 5]);
                        this.globalData.canvasContext.closePath(), this.globalData.canvasContext.fill()
                    }
                    if (this.stroke) {
                        for (g && g.sw ? P !== g.sw && (P = g.sw, e.lineWidth = g.sw) : P !== this.values.sWidth && (P = this.values.sWidth, e.lineWidth = this.values.sWidth), g && g.sc ? E !== g.sc && (E = g.sc, e.strokeStyle = g.sc) : E !== this.values.stroke && (E = this.values.stroke, e.strokeStyle = this.values.stroke), x = this.textSpans[t].elem, s = x.length, this.globalData.canvasContext.beginPath(), i = 0; i < s; i += 1)
                            for (y = x[i], a = y.length, this.globalData.canvasContext.moveTo(y[0], y[1]), n = 2; n < a; n += 6) this.globalData.canvasContext.bezierCurveTo(y[n], y[n + 1], y[n + 2], y[n + 3], y[n + 4], y[n + 5]);
                        this.globalData.canvasContext.closePath(), this.globalData.canvasContext.stroke()
                    }
                    g && this.globalData.renderer.restore()
                }
        };

        function CVEffects() {}
        CVEffects.prototype.renderFrame = function () {};

        function HBaseElement() {}
        HBaseElement.prototype = {
            checkBlendMode: function () {},
            initRendererElement: function () {
                this.baseElement = createTag(this.data.tg || "div"), this.data.hasMask ? (this.svgElement = createNS("svg"), this.layerElement = createNS("g"), this.maskedElement = this.layerElement, this.svgElement.appendChild(this.layerElement), this.baseElement.appendChild(this.svgElement)) : this.layerElement = this.baseElement, styleDiv(this.baseElement)
            },
            createContainerElements: function () {
                this.renderableEffectsManager = new CVEffects, this.transformedElement = this.baseElement, this.maskedElement = this.layerElement, this.data.ln && this.layerElement.setAttribute("id", this.data.ln), this.data.cl && this.layerElement.setAttribute("class", this.data.cl), this.data.bm !== 0 && this.setBlendMode()
            },
            renderElement: function () {
                var e = this.transformedElement ? this.transformedElement.style : {};
                if (this.finalTransform._matMdf) {
                    var t = this.finalTransform.mat.toCSS();
                    e.transform = t, e.webkitTransform = t
                }
                this.finalTransform._opMdf && (e.opacity = this.finalTransform.mProp.o.v)
            },
            renderFrame: function () {
                this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = !1))
            },
            destroy: function () {
                this.layerElement = null, this.transformedElement = null, this.matteElement && (this.matteElement = null), this.maskManager && (this.maskManager.destroy(), this.maskManager = null)
            },
            createRenderableComponents: function () {
                this.maskManager = new MaskElement(this.data, this, this.globalData)
            },
            addEffects: function () {},
            setMatte: function () {}
        }, HBaseElement.prototype.getBaseElement = SVGBaseElement.prototype.getBaseElement, HBaseElement.prototype.destroyBaseElement = HBaseElement.prototype.destroy, HBaseElement.prototype.buildElementParenting = HybridRenderer.prototype.buildElementParenting;

        function HSolidElement(e, t, r) {
            this.initElement(e, t, r)
        }
        extendPrototype([BaseElement, TransformElement, HBaseElement, HierarchyElement, FrameElement, RenderableDOMElement], HSolidElement), HSolidElement.prototype.createContent = function () {
            var e;
            this.data.hasMask ? (e = createNS("rect"), e.setAttribute("width", this.data.sw), e.setAttribute("height", this.data.sh), e.setAttribute("fill", this.data.sc), this.svgElement.setAttribute("width", this.data.sw), this.svgElement.setAttribute("height", this.data.sh)) : (e = createTag("div"), e.style.width = this.data.sw + "px", e.style.height = this.data.sh + "px", e.style.backgroundColor = this.data.sc), this.layerElement.appendChild(e)
        };

        function HCompElement(e, t, r) {
            this.layers = e.layers, this.supports3d = !e.hasMask, this.completeLayers = !1, this.pendingElements = [], this.elements = this.layers ? createSizedArray(this.layers.length) : [], this.initElement(e, t, r), this.tm = e.tm ? PropertyFactory.getProp(this, e.tm, 0, t.frameRate, this) : {
                _placeholder: !0
            }
        }
        extendPrototype([HybridRenderer, ICompElement, HBaseElement], HCompElement), HCompElement.prototype._createBaseContainerElements = HCompElement.prototype.createContainerElements, HCompElement.prototype.createContainerElements = function () {
            this._createBaseContainerElements(), this.data.hasMask ? (this.svgElement.setAttribute("width", this.data.w), this.svgElement.setAttribute("height", this.data.h), this.transformedElement = this.baseElement) : this.transformedElement = this.layerElement
        }, HCompElement.prototype.addTo3dContainer = function (e, t) {
            for (var r = 0, i; r < t;) this.elements[r] && this.elements[r].getBaseElement && (i = this.elements[r].getBaseElement()), r += 1;
            i ? this.layerElement.insertBefore(e, i) : this.layerElement.appendChild(e)
        };

        function HShapeElement(e, t, r) {
            this.shapes = [], this.shapesData = e.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.shapesContainer = createNS("g"), this.initElement(e, t, r), this.prevViewData = [], this.currentBBox = {
                x: 999999,
                y: -999999,
                h: 0,
                w: 0
            }
        }
        extendPrototype([BaseElement, TransformElement, HSolidElement, SVGShapeElement, HBaseElement, HierarchyElement, FrameElement, RenderableElement], HShapeElement), HShapeElement.prototype._renderShapeFrame = HShapeElement.prototype.renderInnerContent, HShapeElement.prototype.createContent = function () {
            var e;
            if (this.baseElement.style.fontSize = 0, this.data.hasMask) this.layerElement.appendChild(this.shapesContainer), e = this.svgElement;
            else {
                e = createNS("svg");
                var t = this.comp.data ? this.comp.data : this.globalData.compSize;
                e.setAttribute("width", t.w), e.setAttribute("height", t.h), e.appendChild(this.shapesContainer), this.layerElement.appendChild(e)
            }
            this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.shapesContainer, 0, [], !0), this.filterUniqueShapes(), this.shapeCont = e
        }, HShapeElement.prototype.getTransformedPoint = function (e, t) {
            var r, i = e.length;
            for (r = 0; r < i; r += 1) t = e[r].mProps.v.applyToPointArray(t[0], t[1], 0);
            return t
        }, HShapeElement.prototype.calculateShapeBoundingBox = function (e, t) {
            var r = e.sh.v,
                i = e.transformers,
                s, n = r._length,
                a, l, c, g;
            if (!(n <= 1)) {
                for (s = 0; s < n - 1; s += 1) a = this.getTransformedPoint(i, r.v[s]), l = this.getTransformedPoint(i, r.o[s]), c = this.getTransformedPoint(i, r.i[s + 1]), g = this.getTransformedPoint(i, r.v[s + 1]), this.checkBounds(a, l, c, g, t);
                r.c && (a = this.getTransformedPoint(i, r.v[s]), l = this.getTransformedPoint(i, r.o[s]), c = this.getTransformedPoint(i, r.i[0]), g = this.getTransformedPoint(i, r.v[0]), this.checkBounds(a, l, c, g, t))
            }
        }, HShapeElement.prototype.checkBounds = function (e, t, r, i, s) {
            this.getBoundsOfCurve(e, t, r, i);
            var n = this.shapeBoundingBox;
            s.x = bmMin(n.left, s.x), s.xMax = bmMax(n.right, s.xMax), s.y = bmMin(n.top, s.y), s.yMax = bmMax(n.bottom, s.yMax)
        }, HShapeElement.prototype.shapeBoundingBox = {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0
        }, HShapeElement.prototype.tempBoundingBox = {
            x: 0,
            xMax: 0,
            y: 0,
            yMax: 0,
            width: 0,
            height: 0
        }, HShapeElement.prototype.getBoundsOfCurve = function (e, t, r, i) {
            for (var s = [[e[0], i[0]], [e[1], i[1]]], n, a, l, c, g, _, E, P = 0; P < 2; ++P) a = 6 * e[P] - 12 * t[P] + 6 * r[P], n = -3 * e[P] + 9 * t[P] - 9 * r[P] + 3 * i[P], l = 3 * t[P] - 3 * e[P], a |= 0, n |= 0, l |= 0, n === 0 && a === 0 || (n === 0 ? (c = -l / a, c > 0 && c < 1 && s[P].push(this.calculateF(c, e, t, r, i, P))) : (g = a * a - 4 * l * n, g >= 0 && (_ = (-a + bmSqrt(g)) / (2 * n), _ > 0 && _ < 1 && s[P].push(this.calculateF(_, e, t, r, i, P)), E = (-a - bmSqrt(g)) / (2 * n), E > 0 && E < 1 && s[P].push(this.calculateF(E, e, t, r, i, P)))));
            this.shapeBoundingBox.left = bmMin.apply(null, s[0]), this.shapeBoundingBox.top = bmMin.apply(null, s[1]), this.shapeBoundingBox.right = bmMax.apply(null, s[0]), this.shapeBoundingBox.bottom = bmMax.apply(null, s[1])
        }, HShapeElement.prototype.calculateF = function (e, t, r, i, s, n) {
            return bmPow(1 - e, 3) * t[n] + 3 * bmPow(1 - e, 2) * e * r[n] + 3 * (1 - e) * bmPow(e, 2) * i[n] + bmPow(e, 3) * s[n]
        }, HShapeElement.prototype.calculateBoundingBox = function (e, t) {
            var r, i = e.length;
            for (r = 0; r < i; r += 1) e[r] && e[r].sh ? this.calculateShapeBoundingBox(e[r], t) : e[r] && e[r].it && this.calculateBoundingBox(e[r].it, t)
        }, HShapeElement.prototype.currentBoxContains = function (e) {
            return this.currentBBox.x <= e.x && this.currentBBox.y <= e.y && this.currentBBox.width + this.currentBBox.x >= e.x + e.width && this.currentBBox.height + this.currentBBox.y >= e.y + e.height
        }, HShapeElement.prototype.renderInnerContent = function () {
            if (this._renderShapeFrame(), !this.hidden && (this._isFirstFrame || this._mdf)) {
                var e = this.tempBoundingBox,
                    t = 999999;
                if (e.x = t, e.xMax = -t, e.y = t, e.yMax = -t, this.calculateBoundingBox(this.itemsData, e), e.width = e.xMax < e.x ? 0 : e.xMax - e.x, e.height = e.yMax < e.y ? 0 : e.yMax - e.y, this.currentBoxContains(e)) return;
                var r = !1;
                if (this.currentBBox.w !== e.width && (this.currentBBox.w = e.width, this.shapeCont.setAttribute("width", e.width), r = !0), this.currentBBox.h !== e.height && (this.currentBBox.h = e.height, this.shapeCont.setAttribute("height", e.height), r = !0), r || this.currentBBox.x !== e.x || this.currentBBox.y !== e.y) {
                    this.currentBBox.w = e.width, this.currentBBox.h = e.height, this.currentBBox.x = e.x, this.currentBBox.y = e.y, this.shapeCont.setAttribute("viewBox", this.currentBBox.x + " " + this.currentBBox.y + " " + this.currentBBox.w + " " + this.currentBBox.h);
                    var i = this.shapeCont.style,
                        s = "translate(" + this.currentBBox.x + "px," + this.currentBBox.y + "px)";
                    i.transform = s, i.webkitTransform = s
                }
            }
        };

        function HTextElement(e, t, r) {
            this.textSpans = [], this.textPaths = [], this.currentBBox = {
                x: 999999,
                y: -999999,
                h: 0,
                w: 0
            }, this.renderType = "svg", this.isMasked = !1, this.initElement(e, t, r)
        }
        extendPrototype([BaseElement, TransformElement, HBaseElement, HierarchyElement, FrameElement, RenderableDOMElement, ITextElement], HTextElement), HTextElement.prototype.createContent = function () {
            if (this.isMasked = this.checkMasks(), this.isMasked) {
                this.renderType = "svg", this.compW = this.comp.data.w, this.compH = this.comp.data.h, this.svgElement.setAttribute("width", this.compW), this.svgElement.setAttribute("height", this.compH);
                var e = createNS("g");
                this.maskedElement.appendChild(e), this.innerElem = e
            } else this.renderType = "html", this.innerElem = this.layerElement;
            this.checkParenting()
        }, HTextElement.prototype.buildNewText = function () {
            var e = this.textProperty.currentData;
            this.renderedLetters = createSizedArray(e.l ? e.l.length : 0);
            var t = this.innerElem.style,
                r = e.fc ? this.buildColor(e.fc) : "rgba(0,0,0,0)";
            t.fill = r, t.color = r, e.sc && (t.stroke = this.buildColor(e.sc), t.strokeWidth = e.sw + "px");
            var i = this.globalData.fontManager.getFontByName(e.f);
            if (!this.globalData.fontManager.chars)
                if (t.fontSize = e.finalSize + "px", t.lineHeight = e.finalSize + "px", i.fClass) this.innerElem.className = i.fClass;
                else {
                    t.fontFamily = i.fFamily;
                    var s = e.fWeight,
                        n = e.fStyle;
                    t.fontStyle = n, t.fontWeight = s
                } var a, l, c = e.l;
            l = c.length;
            var g, _, E, P = this.mHelper,
                x, y = "",
                d = 0;
            for (a = 0; a < l; a += 1) {
                if (this.globalData.fontManager.chars ? (this.textPaths[d] ? g = this.textPaths[d] : (g = createNS("path"), g.setAttribute("stroke-linecap", lineCapEnum[1]), g.setAttribute("stroke-linejoin", lineJoinEnum[2]), g.setAttribute("stroke-miterlimit", "4")), this.isMasked || (this.textSpans[d] ? (_ = this.textSpans[d], E = _.children[0]) : (_ = createTag("div"), _.style.lineHeight = 0, E = createNS("svg"), E.appendChild(g), styleDiv(_)))) : this.isMasked ? g = this.textPaths[d] ? this.textPaths[d] : createNS("text") : this.textSpans[d] ? (_ = this.textSpans[d], g = this.textPaths[d]) : (_ = createTag("span"), styleDiv(_), g = createTag("span"), styleDiv(g), _.appendChild(g)), this.globalData.fontManager.chars) {
                    var b = this.globalData.fontManager.getCharData(e.finalText[a], i.fStyle, this.globalData.fontManager.getFontByName(e.f).fFamily),
                        m;
                    if (b ? m = b.data : m = null, P.reset(), m && m.shapes && (x = m.shapes[0].it, P.scale(e.finalSize / 100, e.finalSize / 100), y = this.createPathShape(P, x), g.setAttribute("d", y)), this.isMasked) this.innerElem.appendChild(g);
                    else {
                        if (this.innerElem.appendChild(_), m && m.shapes) {
                            document.body.appendChild(E);
                            var o = E.getBBox();
                            E.setAttribute("width", o.width + 2), E.setAttribute("height", o.height + 2), E.setAttribute("viewBox", o.x - 1 + " " + (o.y - 1) + " " + (o.width + 2) + " " + (o.height + 2));
                            var f = E.style,
                                u = "translate(" + (o.x - 1) + "px," + (o.y - 1) + "px)";
                            f.transform = u, f.webkitTransform = u, c[a].yOffset = o.y - 1
                        } else E.setAttribute("width", 1), E.setAttribute("height", 1);
                        _.appendChild(E)
                    }
                } else if (g.textContent = c[a].val, g.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), this.isMasked) this.innerElem.appendChild(g);
                else {
                    this.innerElem.appendChild(_);
                    var S = g.style,
                        k = "translate3d(0," + -e.finalSize / 1.2 + "px,0)";
                    S.transform = k, S.webkitTransform = k
                }
                this.isMasked ? this.textSpans[d] = g : this.textSpans[d] = _, this.textSpans[d].style.display = "block", this.textPaths[d] = g, d += 1
            }
            for (; d < this.textSpans.length;) this.textSpans[d].style.display = "none", d += 1
        }, HTextElement.prototype.renderInnerContent = function () {
            var e;
            if (this.data.singleShape) {
                if (!this._isFirstFrame && !this.lettersChangedFlag) return;
                if (this.isMasked && this.finalTransform._matMdf) {
                    this.svgElement.setAttribute("viewBox", -this.finalTransform.mProp.p.v[0] + " " + -this.finalTransform.mProp.p.v[1] + " " + this.compW + " " + this.compH), e = this.svgElement.style;
                    var t = "translate(" + -this.finalTransform.mProp.p.v[0] + "px," + -this.finalTransform.mProp.p.v[1] + "px)";
                    e.transform = t, e.webkitTransform = t
                }
            }
            if (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), !(!this.lettersChangedFlag && !this.textAnimator.lettersChangedFlag)) {
                var r, i, s = 0,
                    n = this.textAnimator.renderedLetters,
                    a = this.textProperty.currentData.l;
                i = a.length;
                var l, c, g;
                for (r = 0; r < i; r += 1) a[r].n ? s += 1 : (c = this.textSpans[r], g = this.textPaths[r], l = n[s], s += 1, l._mdf.m && (this.isMasked ? c.setAttribute("transform", l.m) : (c.style.webkitTransform = l.m, c.style.transform = l.m)), c.style.opacity = l.o, l.sw && l._mdf.sw && g.setAttribute("stroke-width", l.sw), l.sc && l._mdf.sc && g.setAttribute("stroke", l.sc), l.fc && l._mdf.fc && (g.setAttribute("fill", l.fc), g.style.color = l.fc));
                if (this.innerElem.getBBox && !this.hidden && (this._isFirstFrame || this._mdf)) {
                    var _ = this.innerElem.getBBox();
                    this.currentBBox.w !== _.width && (this.currentBBox.w = _.width, this.svgElement.setAttribute("width", _.width)), this.currentBBox.h !== _.height && (this.currentBBox.h = _.height, this.svgElement.setAttribute("height", _.height));
                    var E = 1;
                    if (this.currentBBox.w !== _.width + E * 2 || this.currentBBox.h !== _.height + E * 2 || this.currentBBox.x !== _.x - E || this.currentBBox.y !== _.y - E) {
                        this.currentBBox.w = _.width + E * 2, this.currentBBox.h = _.height + E * 2, this.currentBBox.x = _.x - E, this.currentBBox.y = _.y - E, this.svgElement.setAttribute("viewBox", this.currentBBox.x + " " + this.currentBBox.y + " " + this.currentBBox.w + " " + this.currentBBox.h), e = this.svgElement.style;
                        var P = "translate(" + this.currentBBox.x + "px," + this.currentBBox.y + "px)";
                        e.transform = P, e.webkitTransform = P
                    }
                }
            }
        };

        function HImageElement(e, t, r) {
            this.assetData = t.getAssetData(e.refId), this.initElement(e, t, r)
        }
        extendPrototype([BaseElement, TransformElement, HBaseElement, HSolidElement, HierarchyElement, FrameElement, RenderableElement], HImageElement), HImageElement.prototype.createContent = function () {
            var e = this.globalData.getAssetsPath(this.assetData),
                t = new Image;
            this.data.hasMask ? (this.imageElem = createNS("image"), this.imageElem.setAttribute("width", this.assetData.w + "px"), this.imageElem.setAttribute("height", this.assetData.h + "px"), this.imageElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", e), this.layerElement.appendChild(this.imageElem), this.baseElement.setAttribute("width", this.assetData.w), this.baseElement.setAttribute("height", this.assetData.h)) : this.layerElement.appendChild(t), t.crossOrigin = "anonymous", t.src = e, this.data.ln && this.baseElement.setAttribute("id", this.data.ln)
        };

        function HCameraElement(e, t, r) {
            this.initFrame(), this.initBaseData(e, t, r), this.initHierarchy();
            var i = PropertyFactory.getProp;
            if (this.pe = i(this, e.pe, 0, 0, this), e.ks.p.s ? (this.px = i(this, e.ks.p.x, 1, 0, this), this.py = i(this, e.ks.p.y, 1, 0, this), this.pz = i(this, e.ks.p.z, 1, 0, this)) : this.p = i(this, e.ks.p, 1, 0, this), e.ks.a && (this.a = i(this, e.ks.a, 1, 0, this)), e.ks.or.k.length && e.ks.or.k[0].to) {
                var s, n = e.ks.or.k.length;
                for (s = 0; s < n; s += 1) e.ks.or.k[s].to = null, e.ks.or.k[s].ti = null
            }
            this.or = i(this, e.ks.or, 1, degToRads, this), this.or.sh = !0, this.rx = i(this, e.ks.rx, 0, degToRads, this), this.ry = i(this, e.ks.ry, 0, degToRads, this), this.rz = i(this, e.ks.rz, 0, degToRads, this), this.mat = new Matrix, this._prevMat = new Matrix, this._isFirstFrame = !0, this.finalTransform = {
                mProp: this
            }
        }
        extendPrototype([BaseElement, FrameElement, HierarchyElement], HCameraElement), HCameraElement.prototype.setup = function () {
            var e, t = this.comp.threeDElements.length,
                r, i, s;
            for (e = 0; e < t; e += 1)
                if (r = this.comp.threeDElements[e], r.type === "3d") {
                    i = r.perspectiveElem.style, s = r.container.style;
                    var n = this.pe.v + "px",
                        a = "0px 0px 0px",
                        l = "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)";
                    i.perspective = n, i.webkitPerspective = n, s.transformOrigin = a, s.mozTransformOrigin = a, s.webkitTransformOrigin = a, i.transform = l, i.webkitTransform = l
                }
        }, HCameraElement.prototype.createElements = function () {}, HCameraElement.prototype.hide = function () {}, HCameraElement.prototype.renderFrame = function () {
            var e = this._isFirstFrame,
                t, r;
            if (this.hierarchy)
                for (r = this.hierarchy.length, t = 0; t < r; t += 1) e = this.hierarchy[t].finalTransform.mProp._mdf || e;
            if (e || this.pe._mdf || this.p && this.p._mdf || this.px && (this.px._mdf || this.py._mdf || this.pz._mdf) || this.rx._mdf || this.ry._mdf || this.rz._mdf || this.or._mdf || this.a && this.a._mdf) {
                if (this.mat.reset(), this.hierarchy)
                    for (r = this.hierarchy.length - 1, t = r; t >= 0; t -= 1) {
                        var i = this.hierarchy[t].finalTransform.mProp;
                        this.mat.translate(-i.p.v[0], -i.p.v[1], i.p.v[2]), this.mat.rotateX(-i.or.v[0]).rotateY(-i.or.v[1]).rotateZ(i.or.v[2]), this.mat.rotateX(-i.rx.v).rotateY(-i.ry.v).rotateZ(i.rz.v), this.mat.scale(1 / i.s.v[0], 1 / i.s.v[1], 1 / i.s.v[2]), this.mat.translate(i.a.v[0], i.a.v[1], i.a.v[2])
                    }
                if (this.p ? this.mat.translate(-this.p.v[0], -this.p.v[1], this.p.v[2]) : this.mat.translate(-this.px.v, -this.py.v, this.pz.v), this.a) {
                    var s;
                    this.p ? s = [this.p.v[0] - this.a.v[0], this.p.v[1] - this.a.v[1], this.p.v[2] - this.a.v[2]] : s = [this.px.v - this.a.v[0], this.py.v - this.a.v[1], this.pz.v - this.a.v[2]];
                    var n = Math.sqrt(Math.pow(s[0], 2) + Math.pow(s[1], 2) + Math.pow(s[2], 2)),
                        a = [s[0] / n, s[1] / n, s[2] / n],
                        l = Math.sqrt(a[2] * a[2] + a[0] * a[0]),
                        c = Math.atan2(a[1], l),
                        g = Math.atan2(a[0], -a[2]);
                    this.mat.rotateY(g).rotateX(-c)
                }
                this.mat.rotateX(-this.rx.v).rotateY(-this.ry.v).rotateZ(this.rz.v), this.mat.rotateX(-this.or.v[0]).rotateY(-this.or.v[1]).rotateZ(this.or.v[2]), this.mat.translate(this.globalData.compSize.w / 2, this.globalData.compSize.h / 2, 0), this.mat.translate(0, 0, this.pe.v);
                var _ = !this._prevMat.equals(this.mat);
                if ((_ || this.pe._mdf) && this.comp.threeDElements) {
                    r = this.comp.threeDElements.length;
                    var E, P, x;
                    for (t = 0; t < r; t += 1)
                        if (E = this.comp.threeDElements[t], E.type === "3d") {
                            if (_) {
                                var y = this.mat.toCSS();
                                x = E.container.style, x.transform = y, x.webkitTransform = y
                            }
                            this.pe._mdf && (P = E.perspectiveElem.style, P.perspective = this.pe.v + "px", P.webkitPerspective = this.pe.v + "px")
                        } this.mat.clone(this._prevMat)
                }
            }
            this._isFirstFrame = !1
        }, HCameraElement.prototype.prepareFrame = function (e) {
            this.prepareProperties(e, !0)
        }, HCameraElement.prototype.destroy = function () {}, HCameraElement.prototype.getBaseElement = function () {
            return null
        };
        var animationManager = function () {
                var e = {},
                    t = [],
                    r = 0,
                    i = 0,
                    s = 0,
                    n = !0,
                    a = !1;

                function l(V) {
                    for (var I = 0, A = V.target; I < i;) t[I].animation === A && (t.splice(I, 1), I -= 1, i -= 1, A.isPaused || E()), I += 1
                }

                function c(V, I) {
                    if (!V) return null;
                    for (var A = 0; A < i;) {
                        if (t[A].elem === V && t[A].elem !== null) return t[A].animation;
                        A += 1
                    }
                    var R = new AnimationItem;
                    return P(R, V), R.setData(V, I), R
                }

                function g() {
                    var V, I = t.length,
                        A = [];
                    for (V = 0; V < I; V += 1) A.push(t[V].animation);
                    return A
                }

                function _() {
                    s += 1, D()
                }

                function E() {
                    s -= 1
                }

                function P(V, I) {
                    V.addEventListener("destroy", l), V.addEventListener("_active", _), V.addEventListener("_idle", E), t.push({
                        elem: I,
                        animation: V
                    }), i += 1
                }

                function x(V) {
                    var I = new AnimationItem;
                    return P(I, null), I.setParams(V), I
                }

                function y(V, I) {
                    var A;
                    for (A = 0; A < i; A += 1) t[A].animation.setSpeed(V, I)
                }

                function d(V, I) {
                    var A;
                    for (A = 0; A < i; A += 1) t[A].animation.setDirection(V, I)
                }

                function b(V) {
                    var I;
                    for (I = 0; I < i; I += 1) t[I].animation.play(V)
                }

                function m(V) {
                    var I = V - r,
                        A;
                    for (A = 0; A < i; A += 1) t[A].animation.advanceTime(I);
                    r = V, s && !a ? window.requestAnimationFrame(m) : n = !0
                }

                function o(V) {
                    r = V, window.requestAnimationFrame(m)
                }

                function f(V) {
                    var I;
                    for (I = 0; I < i; I += 1) t[I].animation.pause(V)
                }

                function u(V, I, A) {
                    var R;
                    for (R = 0; R < i; R += 1) t[R].animation.goToAndStop(V, I, A)
                }

                function S(V) {
                    var I;
                    for (I = 0; I < i; I += 1) t[I].animation.stop(V)
                }

                function k(V) {
                    var I;
                    for (I = 0; I < i; I += 1) t[I].animation.togglePause(V)
                }

                function C(V) {
                    var I;
                    for (I = i - 1; I >= 0; I -= 1) t[I].animation.destroy(V)
                }

                function T(V, I, A) {
                    var R = [].concat([].slice.call(document.getElementsByClassName("lottie")), [].slice.call(document.getElementsByClassName("bodymovin"))),
                        X, O = R.length;
                    for (X = 0; X < O; X += 1) A && R[X].setAttribute("data-bm-type", A), c(R[X], V);
                    if (I && O === 0) {
                        A || (A = "svg");
                        var ie = document.getElementsByTagName("body")[0];
                        ie.innerText = "";
                        var se = createTag("div");
                        se.style.width = "100%", se.style.height = "100%", se.setAttribute("data-bm-type", A), ie.appendChild(se), c(se, V)
                    }
                }

                function B() {
                    var V;
                    for (V = 0; V < i; V += 1) t[V].animation.resize()
                }

                function D() {
                    !a && s && n && (window.requestAnimationFrame(o), n = !1)
                }

                function H() {
                    a = !0
                }

                function L() {
                    a = !1, D()
                }

                function U(V, I) {
                    var A;
                    for (A = 0; A < i; A += 1) t[A].animation.setVolume(V, I)
                }

                function Y(V) {
                    var I;
                    for (I = 0; I < i; I += 1) t[I].animation.mute(V)
                }

                function Z(V) {
                    var I;
                    for (I = 0; I < i; I += 1) t[I].animation.unmute(V)
                }
                return e.registerAnimation = c, e.loadAnimation = x, e.setSpeed = y, e.setDirection = d, e.play = b, e.pause = f, e.stop = S, e.togglePause = k, e.searchAnimations = T, e.resize = B, e.goToAndStop = u, e.destroy = C, e.freeze = H, e.unfreeze = L, e.setVolume = U, e.mute = Y, e.unmute = Z, e.getRegisteredAnimations = g, e
            }(),
            AnimationItem = function () {
                this._cbs = [], this.name = "", this.path = "", this.isLoaded = !1, this.currentFrame = 0, this.currentRawFrame = 0, this.firstFrame = 0, this.totalFrames = 0, this.frameRate = 0, this.frameMult = 0, this.playSpeed = 1, this.playDirection = 1, this.playCount = 0, this.animationData = {}, this.assets = [], this.isPaused = !0, this.autoplay = !1, this.loop = !0, this.renderer = null, this.animationID = createElementID(), this.assetsPath = "", this.timeCompleted = 0, this.segmentPos = 0, this.isSubframeEnabled = subframeEnabled, this.segments = [], this._idle = !0, this._completedLoop = !1, this.projectInterface = ProjectInterface(), this.imagePreloader = new ImagePreloader, this.audioController = audioControllerFactory(), this.markers = []
            };
        extendPrototype([BaseEvent], AnimationItem), AnimationItem.prototype.setParams = function (e) {
            (e.wrapper || e.container) && (this.wrapper = e.wrapper || e.container);
            var t = "svg";
            switch (e.animType ? t = e.animType : e.renderer && (t = e.renderer), t) {
                case "canvas":
                    this.renderer = new CanvasRenderer(this, e.rendererSettings);
                    break;
                case "svg":
                    this.renderer = new SVGRenderer(this, e.rendererSettings);
                    break;
                default:
                    this.renderer = new HybridRenderer(this, e.rendererSettings);
                    break
            }
            this.imagePreloader.setCacheType(t, this.renderer.globalData.defs), this.renderer.setProjectInterface(this.projectInterface), this.animType = t, e.loop === "" || e.loop === null || e.loop === void 0 || e.loop === !0 ? this.loop = !0 : e.loop === !1 ? this.loop = !1 : this.loop = parseInt(e.loop, 10), this.autoplay = "autoplay" in e ? e.autoplay : !0, this.name = e.name ? e.name : "", this.autoloadSegments = Object.prototype.hasOwnProperty.call(e, "autoloadSegments") ? e.autoloadSegments : !0, this.assetsPath = e.assetsPath, this.initialSegment = e.initialSegment, e.audioFactory && this.audioController.setAudioFactory(e.audioFactory), e.animationData ? this.configAnimation(e.animationData) : e.path && (e.path.lastIndexOf("\\") !== -1 ? this.path = e.path.substr(0, e.path.lastIndexOf("\\") + 1) : this.path = e.path.substr(0, e.path.lastIndexOf("/") + 1), this.fileName = e.path.substr(e.path.lastIndexOf("/") + 1), this.fileName = this.fileName.substr(0, this.fileName.lastIndexOf(".json")), assetLoader.load(e.path, this.configAnimation.bind(this), (function () {
                this.trigger("data_failed")
            }).bind(this)))
        }, AnimationItem.prototype.setData = function (e, t) {
            t && typeof t != "object" && (t = JSON.parse(t));
            var r = {
                    wrapper: e,
                    animationData: t
                },
                i = e.attributes;
            r.path = i.getNamedItem("data-animation-path") ? i.getNamedItem("data-animation-path").value : i.getNamedItem("data-bm-path") ? i.getNamedItem("data-bm-path").value : i.getNamedItem("bm-path") ? i.getNamedItem("bm-path").value : "", r.animType = i.getNamedItem("data-anim-type") ? i.getNamedItem("data-anim-type").value : i.getNamedItem("data-bm-type") ? i.getNamedItem("data-bm-type").value : i.getNamedItem("bm-type") ? i.getNamedItem("bm-type").value : i.getNamedItem("data-bm-renderer") ? i.getNamedItem("data-bm-renderer").value : i.getNamedItem("bm-renderer") ? i.getNamedItem("bm-renderer").value : "canvas";
            var s = i.getNamedItem("data-anim-loop") ? i.getNamedItem("data-anim-loop").value : i.getNamedItem("data-bm-loop") ? i.getNamedItem("data-bm-loop").value : i.getNamedItem("bm-loop") ? i.getNamedItem("bm-loop").value : "";
            s === "false" ? r.loop = !1 : s === "true" ? r.loop = !0 : s !== "" && (r.loop = parseInt(s, 10));
            var n = i.getNamedItem("data-anim-autoplay") ? i.getNamedItem("data-anim-autoplay").value : i.getNamedItem("data-bm-autoplay") ? i.getNamedItem("data-bm-autoplay").value : i.getNamedItem("bm-autoplay") ? i.getNamedItem("bm-autoplay").value : !0;
            r.autoplay = n !== "false", r.name = i.getNamedItem("data-name") ? i.getNamedItem("data-name").value : i.getNamedItem("data-bm-name") ? i.getNamedItem("data-bm-name").value : i.getNamedItem("bm-name") ? i.getNamedItem("bm-name").value : "";
            var a = i.getNamedItem("data-anim-prerender") ? i.getNamedItem("data-anim-prerender").value : i.getNamedItem("data-bm-prerender") ? i.getNamedItem("data-bm-prerender").value : i.getNamedItem("bm-prerender") ? i.getNamedItem("bm-prerender").value : "";
            a === "false" && (r.prerender = !1), this.setParams(r)
        }, AnimationItem.prototype.includeLayers = function (e) {
            e.op > this.animationData.op && (this.animationData.op = e.op, this.totalFrames = Math.floor(e.op - this.animationData.ip));
            var t = this.animationData.layers,
                r, i = t.length,
                s = e.layers,
                n, a = s.length;
            for (n = 0; n < a; n += 1)
                for (r = 0; r < i;) {
                    if (t[r].id === s[n].id) {
                        t[r] = s[n];
                        break
                    }
                    r += 1
                }
            if ((e.chars || e.fonts) && (this.renderer.globalData.fontManager.addChars(e.chars), this.renderer.globalData.fontManager.addFonts(e.fonts, this.renderer.globalData.defs)), e.assets)
                for (i = e.assets.length, r = 0; r < i; r += 1) this.animationData.assets.push(e.assets[r]);
            this.animationData.__complete = !1, dataManager.completeData(this.animationData, this.renderer.globalData.fontManager), this.renderer.includeLayers(e.layers), expressionsPlugin && expressionsPlugin.initExpressions(this), this.loadNextSegment()
        }, AnimationItem.prototype.loadNextSegment = function () {
            var e = this.animationData.segments;
            if (!e || e.length === 0 || !this.autoloadSegments) {
                this.trigger("data_ready"), this.timeCompleted = this.totalFrames;
                return
            }
            var t = e.shift();
            this.timeCompleted = t.time * this.frameRate;
            var r = this.path + this.fileName + "_" + this.segmentPos + ".json";
            this.segmentPos += 1, assetLoader.load(r, this.includeLayers.bind(this), (function () {
                this.trigger("data_failed")
            }).bind(this))
        }, AnimationItem.prototype.loadSegments = function () {
            var e = this.animationData.segments;
            e || (this.timeCompleted = this.totalFrames), this.loadNextSegment()
        }, AnimationItem.prototype.imagesLoaded = function () {
            this.trigger("loaded_images"), this.checkLoaded()
        }, AnimationItem.prototype.preloadImages = function () {
            this.imagePreloader.setAssetsPath(this.assetsPath), this.imagePreloader.setPath(this.path), this.imagePreloader.loadAssets(this.animationData.assets, this.imagesLoaded.bind(this))
        }, AnimationItem.prototype.configAnimation = function (e) {
            if (this.renderer) try {
                this.animationData = e, this.initialSegment ? (this.totalFrames = Math.floor(this.initialSegment[1] - this.initialSegment[0]), this.firstFrame = Math.round(this.initialSegment[0])) : (this.totalFrames = Math.floor(this.animationData.op - this.animationData.ip), this.firstFrame = Math.round(this.animationData.ip)), this.renderer.configAnimation(e), e.assets || (e.assets = []), this.assets = this.animationData.assets, this.frameRate = this.animationData.fr, this.frameMult = this.animationData.fr / 1e3, this.renderer.searchExtraCompositions(e.assets), this.markers = markerParser(e.markers || []), this.trigger("config_ready"), this.preloadImages(), this.loadSegments(), this.updaFrameModifier(), this.waitForFontsLoaded(), this.isPaused && this.audioController.pause()
            } catch (t) {
                this.triggerConfigError(t)
            }
        }, AnimationItem.prototype.waitForFontsLoaded = function () {
            this.renderer && (this.renderer.globalData.fontManager.isLoaded ? this.checkLoaded() : setTimeout(this.waitForFontsLoaded.bind(this), 20))
        }, AnimationItem.prototype.checkLoaded = function () {
            !this.isLoaded && this.renderer.globalData.fontManager.isLoaded && (this.imagePreloader.loadedImages() || this.renderer.rendererType !== "canvas") && this.imagePreloader.loadedFootages() && (this.isLoaded = !0, dataManager.completeData(this.animationData, this.renderer.globalData.fontManager), expressionsPlugin && expressionsPlugin.initExpressions(this), this.renderer.initItems(), setTimeout((function () {
                this.trigger("DOMLoaded")
            }).bind(this), 0), this.gotoFrame(), this.autoplay && this.play())
        }, AnimationItem.prototype.resize = function () {
            this.renderer.updateContainerSize()
        }, AnimationItem.prototype.setSubframe = function (e) {
            this.isSubframeEnabled = !!e
        }, AnimationItem.prototype.gotoFrame = function () {
            this.currentFrame = this.isSubframeEnabled ? this.currentRawFrame : ~~this.currentRawFrame, this.timeCompleted !== this.totalFrames && this.currentFrame > this.timeCompleted && (this.currentFrame = this.timeCompleted), this.trigger("enterFrame"), this.renderFrame()
        }, AnimationItem.prototype.renderFrame = function () {
            if (!(this.isLoaded === !1 || !this.renderer)) try {
                this.renderer.renderFrame(this.currentFrame + this.firstFrame)
            } catch (e) {
                this.triggerRenderFrameError(e)
            }
        }, AnimationItem.prototype.play = function (e) {
            e && this.name !== e || this.isPaused === !0 && (this.isPaused = !1, this.audioController.resume(), this._idle && (this._idle = !1, this.trigger("_active")))
        }, AnimationItem.prototype.pause = function (e) {
            e && this.name !== e || this.isPaused === !1 && (this.isPaused = !0, this._idle = !0, this.trigger("_idle"), this.audioController.pause())
        }, AnimationItem.prototype.togglePause = function (e) {
            e && this.name !== e || (this.isPaused === !0 ? this.play() : this.pause())
        }, AnimationItem.prototype.stop = function (e) {
            e && this.name !== e || (this.pause(), this.playCount = 0, this._completedLoop = !1, this.setCurrentRawFrameValue(0))
        }, AnimationItem.prototype.getMarkerData = function (e) {
            for (var t, r = 0; r < this.markers.length; r += 1)
                if (t = this.markers[r], t.payload && t.payload.name === e) return t;
            return null
        }, AnimationItem.prototype.goToAndStop = function (e, t, r) {
            if (!(r && this.name !== r)) {
                var i = Number(e);
                if (isNaN(i)) {
                    var s = this.getMarkerData(e);
                    s && this.goToAndStop(s.time, !0)
                } else t ? this.setCurrentRawFrameValue(e) : this.setCurrentRawFrameValue(e * this.frameModifier);
                this.pause()
            }
        }, AnimationItem.prototype.goToAndPlay = function (e, t, r) {
            if (!(r && this.name !== r)) {
                var i = Number(e);
                if (isNaN(i)) {
                    var s = this.getMarkerData(e);
                    s && (s.duration ? this.playSegments([s.time, s.time + s.duration], !0) : this.goToAndStop(s.time, !0))
                } else this.goToAndStop(i, t, r);
                this.play()
            }
        }, AnimationItem.prototype.advanceTime = function (e) {
            if (!(this.isPaused === !0 || this.isLoaded === !1)) {
                var t = this.currentRawFrame + e * this.frameModifier,
                    r = !1;
                t >= this.totalFrames - 1 && this.frameModifier > 0 ? !this.loop || this.playCount === this.loop ? this.checkSegments(t > this.totalFrames ? t % this.totalFrames : 0) || (r = !0, t = this.totalFrames - 1) : t >= this.totalFrames ? (this.playCount += 1, this.checkSegments(t % this.totalFrames) || (this.setCurrentRawFrameValue(t % this.totalFrames), this._completedLoop = !0, this.trigger("loopComplete"))) : this.setCurrentRawFrameValue(t) : t < 0 ? this.checkSegments(t % this.totalFrames) || (this.loop && !(this.playCount-- <= 0 && this.loop !== !0) ? (this.setCurrentRawFrameValue(this.totalFrames + t % this.totalFrames), this._completedLoop ? this.trigger("loopComplete") : this._completedLoop = !0) : (r = !0, t = 0)) : this.setCurrentRawFrameValue(t), r && (this.setCurrentRawFrameValue(t), this.pause(), this.trigger("complete"))
            }
        }, AnimationItem.prototype.adjustSegment = function (e, t) {
            this.playCount = 0, e[1] < e[0] ? (this.frameModifier > 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(-1)), this.totalFrames = e[0] - e[1], this.timeCompleted = this.totalFrames, this.firstFrame = e[1], this.setCurrentRawFrameValue(this.totalFrames - .001 - t)) : e[1] > e[0] && (this.frameModifier < 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(1)), this.totalFrames = e[1] - e[0], this.timeCompleted = this.totalFrames, this.firstFrame = e[0], this.setCurrentRawFrameValue(.001 + t)), this.trigger("segmentStart")
        }, AnimationItem.prototype.setSegment = function (e, t) {
            var r = -1;
            this.isPaused && (this.currentRawFrame + this.firstFrame < e ? r = e : this.currentRawFrame + this.firstFrame > t && (r = t - e)), this.firstFrame = e, this.totalFrames = t - e, this.timeCompleted = this.totalFrames, r !== -1 && this.goToAndStop(r, !0)
        }, AnimationItem.prototype.playSegments = function (e, t) {
            if (t && (this.segments.length = 0), typeof e[0] == "object") {
                var r, i = e.length;
                for (r = 0; r < i; r += 1) this.segments.push(e[r])
            } else this.segments.push(e);
            this.segments.length && t && this.adjustSegment(this.segments.shift(), 0), this.isPaused && this.play()
        }, AnimationItem.prototype.resetSegments = function (e) {
            this.segments.length = 0, this.segments.push([this.animationData.ip, this.animationData.op]), e && this.checkSegments(0)
        }, AnimationItem.prototype.checkSegments = function (e) {
            return this.segments.length ? (this.adjustSegment(this.segments.shift(), e), !0) : !1
        }, AnimationItem.prototype.destroy = function (e) {
            e && this.name !== e || !this.renderer || (this.renderer.destroy(), this.imagePreloader.destroy(), this.trigger("destroy"), this._cbs = null, this.onEnterFrame = null, this.onLoopComplete = null, this.onComplete = null, this.onSegmentStart = null, this.onDestroy = null, this.renderer = null, this.renderer = null, this.imagePreloader = null, this.projectInterface = null)
        }, AnimationItem.prototype.setCurrentRawFrameValue = function (e) {
            this.currentRawFrame = e, this.gotoFrame()
        }, AnimationItem.prototype.setSpeed = function (e) {
            this.playSpeed = e, this.updaFrameModifier()
        }, AnimationItem.prototype.setDirection = function (e) {
            this.playDirection = e < 0 ? -1 : 1, this.updaFrameModifier()
        }, AnimationItem.prototype.setVolume = function (e, t) {
            t && this.name !== t || this.audioController.setVolume(e)
        }, AnimationItem.prototype.getVolume = function () {
            return this.audioController.getVolume()
        }, AnimationItem.prototype.mute = function (e) {
            e && this.name !== e || this.audioController.mute()
        }, AnimationItem.prototype.unmute = function (e) {
            e && this.name !== e || this.audioController.unmute()
        }, AnimationItem.prototype.updaFrameModifier = function () {
            this.frameModifier = this.frameMult * this.playSpeed * this.playDirection, this.audioController.setRate(this.playSpeed * this.playDirection)
        }, AnimationItem.prototype.getPath = function () {
            return this.path
        }, AnimationItem.prototype.getAssetsPath = function (e) {
            var t = "";
            if (e.e) t = e.p;
            else if (this.assetsPath) {
                var r = e.p;
                r.indexOf("images/") !== -1 && (r = r.split("/")[1]), t = this.assetsPath + r
            } else t = this.path, t += e.u ? e.u : "", t += e.p;
            return t
        }, AnimationItem.prototype.getAssetData = function (e) {
            for (var t = 0, r = this.assets.length; t < r;) {
                if (e === this.assets[t].id) return this.assets[t];
                t += 1
            }
            return null
        }, AnimationItem.prototype.hide = function () {
            this.renderer.hide()
        }, AnimationItem.prototype.show = function () {
            this.renderer.show()
        }, AnimationItem.prototype.getDuration = function (e) {
            return e ? this.totalFrames : this.totalFrames / this.frameRate
        }, AnimationItem.prototype.trigger = function (e) {
            if (this._cbs && this._cbs[e]) switch (e) {
                case "enterFrame":
                    this.triggerEvent(e, new BMEnterFrameEvent(e, this.currentFrame, this.totalFrames, this.frameModifier));
                    break;
                case "loopComplete":
                    this.triggerEvent(e, new BMCompleteLoopEvent(e, this.loop, this.playCount, this.frameMult));
                    break;
                case "complete":
                    this.triggerEvent(e, new BMCompleteEvent(e, this.frameMult));
                    break;
                case "segmentStart":
                    this.triggerEvent(e, new BMSegmentStartEvent(e, this.firstFrame, this.totalFrames));
                    break;
                case "destroy":
                    this.triggerEvent(e, new BMDestroyEvent(e, this));
                    break;
                default:
                    this.triggerEvent(e)
            }
            e === "enterFrame" && this.onEnterFrame && this.onEnterFrame.call(this, new BMEnterFrameEvent(e, this.currentFrame, this.totalFrames, this.frameMult)), e === "loopComplete" && this.onLoopComplete && this.onLoopComplete.call(this, new BMCompleteLoopEvent(e, this.loop, this.playCount, this.frameMult)), e === "complete" && this.onComplete && this.onComplete.call(this, new BMCompleteEvent(e, this.frameMult)), e === "segmentStart" && this.onSegmentStart && this.onSegmentStart.call(this, new BMSegmentStartEvent(e, this.firstFrame, this.totalFrames)), e === "destroy" && this.onDestroy && this.onDestroy.call(this, new BMDestroyEvent(e, this))
        }, AnimationItem.prototype.triggerRenderFrameError = function (e) {
            var t = new BMRenderFrameErrorEvent(e, this.currentFrame);
            this.triggerEvent("error", t), this.onError && this.onError.call(this, t)
        }, AnimationItem.prototype.triggerConfigError = function (e) {
            var t = new BMConfigErrorEvent(e, this.currentFrame);
            this.triggerEvent("error", t), this.onError && this.onError.call(this, t)
        };
        var Expressions = function () {
            var e = {};
            e.initExpressions = t;

            function t(r) {
                var i = 0,
                    s = [];

                function n() {
                    i += 1
                }

                function a() {
                    i -= 1, i === 0 && c()
                }

                function l(g) {
                    s.indexOf(g) === -1 && s.push(g)
                }

                function c() {
                    var g, _ = s.length;
                    for (g = 0; g < _; g += 1) s[g].release();
                    s.length = 0
                }
                r.renderer.compInterface = CompExpressionInterface(r.renderer), r.renderer.globalData.projectInterface.registerComposition(r.renderer), r.renderer.globalData.pushExpression = n, r.renderer.globalData.popExpression = a, r.renderer.globalData.registerExpressionProperty = l
            }
            return e
        }();
        expressionsPlugin = Expressions;
        var ExpressionManager = function () {
                var ob = {},
                    Math = BMMath;
                BezierFactory.getBezierEasing(.333, 0, .833, .833, "easeIn").get, BezierFactory.getBezierEasing(.167, .167, .667, 1, "easeOut").get, BezierFactory.getBezierEasing(.33, 0, .667, 1, "easeInOut").get;

                function initiateExpression(elem, data, property) {
                    var val = data.x,
                        needsVelocity = /velocity(?![\w\d])/.test(val),
                        _needsRandom = val.indexOf("random") !== -1,
                        elemType = elem.data.ty,
                        transform, content, effect, thisProperty = property;
                    thisProperty.valueAtTime = thisProperty.getValueAtTime, Object.defineProperty(thisProperty, "value", {
                        get: function () {
                            return thisProperty.v
                        }
                    }), elem.comp.frameDuration = 1 / elem.comp.globalData.frameRate, elem.comp.displayStartTime = 0, elem.data.ip / elem.comp.globalData.frameRate, elem.data.op / elem.comp.globalData.frameRate, elem.data.sw && elem.data.sw, elem.data.sh && elem.data.sh, elem.data.nm;
                    var thisLayer, velocityAtTime, scoped_bm_rt, expression_function = eval("[function _expression_function(){" + val + ";scoped_bm_rt=$bm_rt}]")[0];
                    property.kf && data.k.length, !this.data || this.data.hd, (function e(t, r) {
                        var i, s, n = this.pv.length ? this.pv.length : 1,
                            a = createTypedArray("float32", n);
                        t = 5;
                        var l = Math.floor(time * t);
                        for (i = 0, s = 0; i < l;) {
                            for (s = 0; s < n; s += 1) a[s] += -r + r * 2 * BMMath.random();
                            i += 1
                        }
                        var c = time * t,
                            g = c - Math.floor(c),
                            _ = createTypedArray("float32", n);
                        if (n > 1) {
                            for (s = 0; s < n; s += 1) _[s] = this.pv[s] + a[s] + (-r + r * 2 * BMMath.random()) * g;
                            return _
                        }
                        return this.pv + a[0] + (-r + r * 2 * BMMath.random()) * g
                    }).bind(this), thisProperty.loopIn && thisProperty.loopIn.bind(thisProperty), thisProperty.loopOut && thisProperty.loopOut.bind(thisProperty), thisProperty.smooth && thisProperty.smooth.bind(thisProperty), this.getValueAtTime && this.getValueAtTime.bind(this), this.getVelocityAtTime && (velocityAtTime = this.getVelocityAtTime.bind(this)), elem.comp.globalData.projectInterface.bind(elem.comp.globalData.projectInterface);

                    function seedRandom(e) {
                        BMMath.seedrandom(randSeed + e)
                    }
                    var time, value;
                    elem.data.ind;
                    var hasParent = !!(elem.hierarchy && elem.hierarchy.length),
                        parent, randSeed = Math.floor(Math.random() * 1e6);
                    elem.globalData;

                    function executeExpression(e) {
                        return value = e, _needsRandom && seedRandom(randSeed), this.frameExpressionId === elem.globalData.frameId && this.propType !== "textSelector" ? value : (this.propType === "textSelector" && (this.textIndex, this.textTotal, this.selectorValue), thisLayer || (elem.layerInterface.text, thisLayer = elem.layerInterface, elem.comp.compInterface, thisLayer.toWorld.bind(thisLayer), thisLayer.fromWorld.bind(thisLayer), thisLayer.fromComp.bind(thisLayer), thisLayer.toComp.bind(thisLayer), thisLayer.mask && thisLayer.mask.bind(thisLayer)), transform || (transform = elem.layerInterface("ADBE Transform Group"), transform && transform.anchorPoint), elemType === 4 && !content && (content = thisLayer("ADBE Root Vectors Group")), effect || (effect = thisLayer(4)), hasParent = !!(elem.hierarchy && elem.hierarchy.length), hasParent && !parent && (parent = elem.hierarchy[0].layerInterface), time = this.comp.renderedFrame / this.comp.globalData.frameRate, needsVelocity && velocityAtTime(time), expression_function(), this.frameExpressionId = elem.globalData.frameId, scoped_bm_rt.propType, scoped_bm_rt)
                    }
                    return executeExpression
                }
                return ob.initiateExpression = initiateExpression, ob
            }(),
            expressionHelpers = function () {
                function e(a, l, c) {
                    l.x && (c.k = !0, c.x = !0, c.initiateExpression = ExpressionManager.initiateExpression, c.effectsSequence.push(c.initiateExpression(a, l, c).bind(c)))
                }

                function t(a) {
                    return a *= this.elem.globalData.frameRate, a -= this.offsetTime, a !== this._cachingAtTime.lastFrame && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastFrame < a ? this._cachingAtTime.lastIndex : 0, this._cachingAtTime.value = this.interpolateValue(a, this._cachingAtTime), this._cachingAtTime.lastFrame = a), this._cachingAtTime.value
                }

                function r(a) {
                    var l = -.01,
                        c = this.getValueAtTime(a),
                        g = this.getValueAtTime(a + l),
                        _ = 0;
                    if (c.length) {
                        var E;
                        for (E = 0; E < c.length; E += 1) _ += Math.pow(g[E] - c[E], 2);
                        _ = Math.sqrt(_) * 100
                    } else _ = 0;
                    return _
                }

                function i(a) {
                    if (this.vel !== void 0) return this.vel;
                    var l = -.001,
                        c = this.getValueAtTime(a),
                        g = this.getValueAtTime(a + l),
                        _;
                    if (c.length) {
                        _ = createTypedArray("float32", c.length);
                        var E;
                        for (E = 0; E < c.length; E += 1) _[E] = (g[E] - c[E]) / l
                    } else _ = (g - c) / l;
                    return _
                }

                function s() {
                    return this.pv
                }

                function n(a) {
                    this.propertyGroup = a
                }
                return {
                    searchExpressions: e,
                    getSpeedAtTime: r,
                    getVelocityAtTime: i,
                    getValueAtTime: t,
                    getStaticValueAtTime: s,
                    setGroupProperty: n
                }
            }();
        (function e() {
            function t(x, y, d) {
                if (!this.k || !this.keyframes) return this.pv;
                x = x ? x.toLowerCase() : "";
                var b = this.comp.renderedFrame,
                    m = this.keyframes,
                    o = m[m.length - 1].t;
                if (b <= o) return this.pv;
                var f, u;
                d ? (y ? f = Math.abs(o - this.elem.comp.globalData.frameRate * y) : f = Math.max(0, o - this.elem.data.ip), u = o - f) : ((!y || y > m.length - 1) && (y = m.length - 1), u = m[m.length - 1 - y].t, f = o - u);
                var S, k, C;
                if (x === "pingpong") {
                    var T = Math.floor((b - u) / f);
                    if (T % 2 !== 0) return this.getValueAtTime((f - (b - u) % f + u) / this.comp.globalData.frameRate, 0)
                } else if (x === "offset") {
                    var B = this.getValueAtTime(u / this.comp.globalData.frameRate, 0),
                        D = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                        H = this.getValueAtTime(((b - u) % f + u) / this.comp.globalData.frameRate, 0),
                        L = Math.floor((b - u) / f);
                    if (this.pv.length) {
                        for (C = new Array(B.length), k = C.length, S = 0; S < k; S += 1) C[S] = (D[S] - B[S]) * L + H[S];
                        return C
                    }
                    return (D - B) * L + H
                } else if (x === "continue") {
                    var U = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                        Y = this.getValueAtTime((o - .001) / this.comp.globalData.frameRate, 0);
                    if (this.pv.length) {
                        for (C = new Array(U.length), k = C.length, S = 0; S < k; S += 1) C[S] = U[S] + (U[S] - Y[S]) * ((b - o) / this.comp.globalData.frameRate) / 5e-4;
                        return C
                    }
                    return U + (U - Y) * ((b - o) / .001)
                }
                return this.getValueAtTime(((b - u) % f + u) / this.comp.globalData.frameRate, 0)
            }

            function r(x, y, d) {
                if (!this.k) return this.pv;
                x = x ? x.toLowerCase() : "";
                var b = this.comp.renderedFrame,
                    m = this.keyframes,
                    o = m[0].t;
                if (b >= o) return this.pv;
                var f, u;
                d ? (y ? f = Math.abs(this.elem.comp.globalData.frameRate * y) : f = Math.max(0, this.elem.data.op - o), u = o + f) : ((!y || y > m.length - 1) && (y = m.length - 1), u = m[y].t, f = u - o);
                var S, k, C;
                if (x === "pingpong") {
                    var T = Math.floor((o - b) / f);
                    if (T % 2 === 0) return this.getValueAtTime(((o - b) % f + o) / this.comp.globalData.frameRate, 0)
                } else if (x === "offset") {
                    var B = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                        D = this.getValueAtTime(u / this.comp.globalData.frameRate, 0),
                        H = this.getValueAtTime((f - (o - b) % f + o) / this.comp.globalData.frameRate, 0),
                        L = Math.floor((o - b) / f) + 1;
                    if (this.pv.length) {
                        for (C = new Array(B.length), k = C.length, S = 0; S < k; S += 1) C[S] = H[S] - (D[S] - B[S]) * L;
                        return C
                    }
                    return H - (D - B) * L
                } else if (x === "continue") {
                    var U = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                        Y = this.getValueAtTime((o + .001) / this.comp.globalData.frameRate, 0);
                    if (this.pv.length) {
                        for (C = new Array(U.length), k = C.length, S = 0; S < k; S += 1) C[S] = U[S] + (U[S] - Y[S]) * (o - b) / .001;
                        return C
                    }
                    return U + (U - Y) * (o - b) / .001
                }
                return this.getValueAtTime((f - ((o - b) % f + o)) / this.comp.globalData.frameRate, 0)
            }

            function i(x, y) {
                if (!this.k) return this.pv;
                if (x = (x || .4) * .5, y = Math.floor(y || 5), y <= 1) return this.pv;
                var d = this.comp.renderedFrame / this.comp.globalData.frameRate,
                    b = d - x,
                    m = d + x,
                    o = y > 1 ? (m - b) / (y - 1) : 1,
                    f = 0,
                    u = 0,
                    S;
                this.pv.length ? S = createTypedArray("float32", this.pv.length) : S = 0;
                for (var k; f < y;) {
                    if (k = this.getValueAtTime(b + f * o), this.pv.length)
                        for (u = 0; u < this.pv.length; u += 1) S[u] += k[u];
                    else S += k;
                    f += 1
                }
                if (this.pv.length)
                    for (u = 0; u < this.pv.length; u += 1) S[u] /= y;
                else S /= y;
                return S
            }

            function s(x) {
                this._transformCachingAtTime || (this._transformCachingAtTime = {
                    v: new Matrix
                });
                var y = this._transformCachingAtTime.v;
                if (y.cloneFromProps(this.pre.props), this.appliedTransformations < 1) {
                    var d = this.a.getValueAtTime(x);
                    y.translate(-d[0] * this.a.mult, -d[1] * this.a.mult, d[2] * this.a.mult)
                }
                if (this.appliedTransformations < 2) {
                    var b = this.s.getValueAtTime(x);
                    y.scale(b[0] * this.s.mult, b[1] * this.s.mult, b[2] * this.s.mult)
                }
                if (this.sk && this.appliedTransformations < 3) {
                    var m = this.sk.getValueAtTime(x),
                        o = this.sa.getValueAtTime(x);
                    y.skewFromAxis(-m * this.sk.mult, o * this.sa.mult)
                }
                if (this.r && this.appliedTransformations < 4) {
                    var f = this.r.getValueAtTime(x);
                    y.rotate(-f * this.r.mult)
                } else if (!this.r && this.appliedTransformations < 4) {
                    var u = this.rz.getValueAtTime(x),
                        S = this.ry.getValueAtTime(x),
                        k = this.rx.getValueAtTime(x),
                        C = this.or.getValueAtTime(x);
                    y.rotateZ(-u * this.rz.mult).rotateY(S * this.ry.mult).rotateX(k * this.rx.mult).rotateZ(-C[2] * this.or.mult).rotateY(C[1] * this.or.mult).rotateX(C[0] * this.or.mult)
                }
                if (this.data.p && this.data.p.s) {
                    var T = this.px.getValueAtTime(x),
                        B = this.py.getValueAtTime(x);
                    if (this.data.p.z) {
                        var D = this.pz.getValueAtTime(x);
                        y.translate(T * this.px.mult, B * this.py.mult, -D * this.pz.mult)
                    } else y.translate(T * this.px.mult, B * this.py.mult, 0)
                } else {
                    var H = this.p.getValueAtTime(x);
                    y.translate(H[0] * this.p.mult, H[1] * this.p.mult, -H[2] * this.p.mult)
                }
                return y
            }

            function n() {
                return this.v.clone(new Matrix)
            }
            var a = TransformPropertyFactory.getTransformProperty;
            TransformPropertyFactory.getTransformProperty = function (x, y, d) {
                var b = a(x, y, d);
                return b.dynamicProperties.length ? b.getValueAtTime = s.bind(b) : b.getValueAtTime = n.bind(b), b.setGroupProperty = expressionHelpers.setGroupProperty, b
            };
            var l = PropertyFactory.getProp;
            PropertyFactory.getProp = function (x, y, d, b, m) {
                var o = l(x, y, d, b, m);
                o.kf ? o.getValueAtTime = expressionHelpers.getValueAtTime.bind(o) : o.getValueAtTime = expressionHelpers.getStaticValueAtTime.bind(o), o.setGroupProperty = expressionHelpers.setGroupProperty, o.loopOut = t, o.loopIn = r, o.smooth = i, o.getVelocityAtTime = expressionHelpers.getVelocityAtTime.bind(o), o.getSpeedAtTime = expressionHelpers.getSpeedAtTime.bind(o), o.numKeys = y.a === 1 ? y.k.length : 0, o.propertyIndex = y.ix;
                var f = 0;
                return d !== 0 && (f = createTypedArray("float32", y.a === 1 ? y.k[0].s.length : y.k.length)), o._cachingAtTime = {
                    lastFrame: initialDefaultFrame,
                    lastIndex: 0,
                    value: f
                }, expressionHelpers.searchExpressions(x, y, o), o.k && m.addDynamicProperty(o), o
            };

            function c(x) {
                return this._cachingAtTime || (this._cachingAtTime = {
                    shapeValue: shapePool.clone(this.pv),
                    lastIndex: 0,
                    lastTime: initialDefaultFrame
                }), x *= this.elem.globalData.frameRate, x -= this.offsetTime, x !== this._cachingAtTime.lastTime && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastTime < x ? this._caching.lastIndex : 0, this._cachingAtTime.lastTime = x, this.interpolateShape(x, this._cachingAtTime.shapeValue, this._cachingAtTime)), this._cachingAtTime.shapeValue
            }
            var g = ShapePropertyFactory.getConstructorFunction(),
                _ = ShapePropertyFactory.getKeyframedConstructorFunction();

            function E() {}
            E.prototype = {
                vertices: function (x, y) {
                    this.k && this.getValue();
                    var d = this.v;
                    y !== void 0 && (d = this.getValueAtTime(y, 0));
                    var b, m = d._length,
                        o = d[x],
                        f = d.v,
                        u = createSizedArray(m);
                    for (b = 0; b < m; b += 1) x === "i" || x === "o" ? u[b] = [o[b][0] - f[b][0], o[b][1] - f[b][1]] : u[b] = [o[b][0], o[b][1]];
                    return u
                },
                points: function (x) {
                    return this.vertices("v", x)
                },
                inTangents: function (x) {
                    return this.vertices("i", x)
                },
                outTangents: function (x) {
                    return this.vertices("o", x)
                },
                isClosed: function () {
                    return this.v.c
                },
                pointOnPath: function (x, y) {
                    var d = this.v;
                    y !== void 0 && (d = this.getValueAtTime(y, 0)), this._segmentsLength || (this._segmentsLength = bez.getSegmentsLength(d));
                    for (var b = this._segmentsLength, m = b.lengths, o = b.totalLength * x, f = 0, u = m.length, S = 0, k; f < u;) {
                        if (S + m[f].addedLength > o) {
                            var C = f,
                                T = d.c && f === u - 1 ? 0 : f + 1,
                                B = (o - S) / m[f].addedLength;
                            k = bez.getPointInSegment(d.v[C], d.v[T], d.o[C], d.i[T], B, m[f]);
                            break
                        } else S += m[f].addedLength;
                        f += 1
                    }
                    return k || (k = d.c ? [d.v[0][0], d.v[0][1]] : [d.v[d._length - 1][0], d.v[d._length - 1][1]]), k
                },
                vectorOnPath: function (x, y, d) {
                    x == 1 ? x = this.v.c : x == 0 && (x = .999);
                    var b = this.pointOnPath(x, y),
                        m = this.pointOnPath(x + .001, y),
                        o = m[0] - b[0],
                        f = m[1] - b[1],
                        u = Math.sqrt(Math.pow(o, 2) + Math.pow(f, 2));
                    if (u === 0) return [0, 0];
                    var S = d === "tangent" ? [o / u, f / u] : [-f / u, o / u];
                    return S
                },
                tangentOnPath: function (x, y) {
                    return this.vectorOnPath(x, y, "tangent")
                },
                normalOnPath: function (x, y) {
                    return this.vectorOnPath(x, y, "normal")
                },
                setGroupProperty: expressionHelpers.setGroupProperty,
                getValueAtTime: expressionHelpers.getStaticValueAtTime
            }, extendPrototype([E], g), extendPrototype([E], _), _.prototype.getValueAtTime = c, _.prototype.initiateExpression = ExpressionManager.initiateExpression;
            var P = ShapePropertyFactory.getShapeProp;
            ShapePropertyFactory.getShapeProp = function (x, y, d, b, m) {
                var o = P(x, y, d, b, m);
                return o.propertyIndex = y.ix, o.lock = !1, d === 3 ? expressionHelpers.searchExpressions(x, y.pt, o) : d === 4 && expressionHelpers.searchExpressions(x, y.ks, o), o.k && x.addDynamicProperty(o), o
            }
        })(),
        function e() {
            function t() {
                return this.data.d.x ? (this.calculateExpression = ExpressionManager.initiateExpression.bind(this)(this.elem, this.data.d, this), this.addEffect(this.getExpressionValue.bind(this)), !0) : null
            }
            TextProperty.prototype.getExpressionValue = function (r, i) {
                var s = this.calculateExpression(i);
                if (r.t !== s) {
                    var n = {};
                    return this.copyData(n, r), n.t = s.toString(), n.__complete = !1, n
                }
                return r
            }, TextProperty.prototype.searchProperty = function () {
                var r = this.searchKeyframes(),
                    i = this.searchExpressions();
                return this.kf = r || i, this.kf
            }, TextProperty.prototype.searchExpressions = t
        }();
        var ShapePathInterface = function () {
                return function (t, r, i) {
                    var s = r.sh;

                    function n(l) {
                        return l === "Shape" || l === "shape" || l === "Path" || l === "path" || l === "ADBE Vector Shape" || l === 2 ? n.path : null
                    }
                    var a = propertyGroupFactory(n, i);
                    return s.setGroupProperty(PropertyInterface("Path", a)), Object.defineProperties(n, {
                        path: {
                            get: function () {
                                return s.k && s.getValue(), s
                            }
                        },
                        shape: {
                            get: function () {
                                return s.k && s.getValue(), s
                            }
                        },
                        _name: {
                            value: t.nm
                        },
                        ix: {
                            value: t.ix
                        },
                        propertyIndex: {
                            value: t.ix
                        },
                        mn: {
                            value: t.mn
                        },
                        propertyGroup: {
                            value: i
                        }
                    }), n
                }
            }(),
            propertyGroupFactory = function () {
                return function (e, t) {
                    return function (r) {
                        return r = r === void 0 ? 1 : r, r <= 0 ? e : t(r - 1)
                    }
                }
            }(),
            PropertyInterface = function () {
                return function (e, t) {
                    var r = {
                        _name: e
                    };

                    function i(s) {
                        return s = s === void 0 ? 1 : s, s <= 0 ? r : t(s - 1)
                    }
                    return i
                }
            }(),
            ShapeExpressionInterface = function () {
                function e(y, d, b) {
                    var m = [],
                        o, f = y ? y.length : 0;
                    for (o = 0; o < f; o += 1) y[o].ty === "gr" ? m.push(r(y[o], d[o], b)) : y[o].ty === "fl" ? m.push(i(y[o], d[o], b)) : y[o].ty === "st" ? m.push(a(y[o], d[o], b)) : y[o].ty === "tm" ? m.push(l(y[o], d[o], b)) : y[o].ty === "tr" || (y[o].ty === "el" ? m.push(g(y[o], d[o], b)) : y[o].ty === "sr" ? m.push(_(y[o], d[o], b)) : y[o].ty === "sh" ? m.push(ShapePathInterface(y[o], d[o], b)) : y[o].ty === "rc" ? m.push(E(y[o], d[o], b)) : y[o].ty === "rd" ? m.push(P(y[o], d[o], b)) : y[o].ty === "rp" ? m.push(x(y[o], d[o], b)) : y[o].ty === "gf" ? m.push(s(y[o], d[o], b)) : m.push(n(y[o], d[o])));
                    return m
                }

                function t(y, d, b) {
                    var m, o = function (S) {
                        for (var k = 0, C = m.length; k < C;) {
                            if (m[k]._name === S || m[k].mn === S || m[k].propertyIndex === S || m[k].ix === S || m[k].ind === S) return m[k];
                            k += 1
                        }
                        return typeof S == "number" ? m[S - 1] : null
                    };
                    o.propertyGroup = propertyGroupFactory(o, b), m = e(y.it, d.it, o.propertyGroup), o.numProperties = m.length;
                    var f = c(y.it[y.it.length - 1], d.it[d.it.length - 1], o.propertyGroup);
                    return o.transform = f, o.propertyIndex = y.cix, o._name = y.nm, o
                }

                function r(y, d, b) {
                    var m = function (S) {
                        switch (S) {
                            case "ADBE Vectors Group":
                            case "Contents":
                            case 2:
                                return m.content;
                            default:
                                return m.transform
                        }
                    };
                    m.propertyGroup = propertyGroupFactory(m, b);
                    var o = t(y, d, m.propertyGroup),
                        f = c(y.it[y.it.length - 1], d.it[d.it.length - 1], m.propertyGroup);
                    return m.content = o, m.transform = f, Object.defineProperty(m, "_name", {
                        get: function () {
                            return y.nm
                        }
                    }), m.numProperties = y.np, m.propertyIndex = y.ix, m.nm = y.nm, m.mn = y.mn, m
                }

                function i(y, d, b) {
                    function m(o) {
                        return o === "Color" || o === "color" ? m.color : o === "Opacity" || o === "opacity" ? m.opacity : null
                    }
                    return Object.defineProperties(m, {
                        color: {
                            get: ExpressionPropertyInterface(d.c)
                        },
                        opacity: {
                            get: ExpressionPropertyInterface(d.o)
                        },
                        _name: {
                            value: y.nm
                        },
                        mn: {
                            value: y.mn
                        }
                    }), d.c.setGroupProperty(PropertyInterface("Color", b)), d.o.setGroupProperty(PropertyInterface("Opacity", b)), m
                }

                function s(y, d, b) {
                    function m(o) {
                        return o === "Start Point" || o === "start point" ? m.startPoint : o === "End Point" || o === "end point" ? m.endPoint : o === "Opacity" || o === "opacity" ? m.opacity : null
                    }
                    return Object.defineProperties(m, {
                        startPoint: {
                            get: ExpressionPropertyInterface(d.s)
                        },
                        endPoint: {
                            get: ExpressionPropertyInterface(d.e)
                        },
                        opacity: {
                            get: ExpressionPropertyInterface(d.o)
                        },
                        type: {
                            get: function () {
                                return "a"
                            }
                        },
                        _name: {
                            value: y.nm
                        },
                        mn: {
                            value: y.mn
                        }
                    }), d.s.setGroupProperty(PropertyInterface("Start Point", b)), d.e.setGroupProperty(PropertyInterface("End Point", b)), d.o.setGroupProperty(PropertyInterface("Opacity", b)), m
                }

                function n() {
                    function y() {
                        return null
                    }
                    return y
                }

                function a(y, d, b) {
                    var m = propertyGroupFactory(C, b),
                        o = propertyGroupFactory(k, m);

                    function f(T) {
                        Object.defineProperty(k, y.d[T].nm, {
                            get: ExpressionPropertyInterface(d.d.dataProps[T].p)
                        })
                    }
                    var u, S = y.d ? y.d.length : 0,
                        k = {};
                    for (u = 0; u < S; u += 1) f(u), d.d.dataProps[u].p.setGroupProperty(o);

                    function C(T) {
                        return T === "Color" || T === "color" ? C.color : T === "Opacity" || T === "opacity" ? C.opacity : T === "Stroke Width" || T === "stroke width" ? C.strokeWidth : null
                    }
                    return Object.defineProperties(C, {
                        color: {
                            get: ExpressionPropertyInterface(d.c)
                        },
                        opacity: {
                            get: ExpressionPropertyInterface(d.o)
                        },
                        strokeWidth: {
                            get: ExpressionPropertyInterface(d.w)
                        },
                        dash: {
                            get: function () {
                                return k
                            }
                        },
                        _name: {
                            value: y.nm
                        },
                        mn: {
                            value: y.mn
                        }
                    }), d.c.setGroupProperty(PropertyInterface("Color", m)), d.o.setGroupProperty(PropertyInterface("Opacity", m)), d.w.setGroupProperty(PropertyInterface("Stroke Width", m)), C
                }

                function l(y, d, b) {
                    function m(f) {
                        return f === y.e.ix || f === "End" || f === "end" ? m.end : f === y.s.ix ? m.start : f === y.o.ix ? m.offset : null
                    }
                    var o = propertyGroupFactory(m, b);
                    return m.propertyIndex = y.ix, d.s.setGroupProperty(PropertyInterface("Start", o)), d.e.setGroupProperty(PropertyInterface("End", o)), d.o.setGroupProperty(PropertyInterface("Offset", o)), m.propertyIndex = y.ix, m.propertyGroup = b, Object.defineProperties(m, {
                        start: {
                            get: ExpressionPropertyInterface(d.s)
                        },
                        end: {
                            get: ExpressionPropertyInterface(d.e)
                        },
                        offset: {
                            get: ExpressionPropertyInterface(d.o)
                        },
                        _name: {
                            value: y.nm
                        }
                    }), m.mn = y.mn, m
                }

                function c(y, d, b) {
                    function m(f) {
                        return y.a.ix === f || f === "Anchor Point" ? m.anchorPoint : y.o.ix === f || f === "Opacity" ? m.opacity : y.p.ix === f || f === "Position" ? m.position : y.r.ix === f || f === "Rotation" || f === "ADBE Vector Rotation" ? m.rotation : y.s.ix === f || f === "Scale" ? m.scale : y.sk && y.sk.ix === f || f === "Skew" ? m.skew : y.sa && y.sa.ix === f || f === "Skew Axis" ? m.skewAxis : null
                    }
                    var o = propertyGroupFactory(m, b);
                    return d.transform.mProps.o.setGroupProperty(PropertyInterface("Opacity", o)), d.transform.mProps.p.setGroupProperty(PropertyInterface("Position", o)), d.transform.mProps.a.setGroupProperty(PropertyInterface("Anchor Point", o)), d.transform.mProps.s.setGroupProperty(PropertyInterface("Scale", o)), d.transform.mProps.r.setGroupProperty(PropertyInterface("Rotation", o)), d.transform.mProps.sk && (d.transform.mProps.sk.setGroupProperty(PropertyInterface("Skew", o)), d.transform.mProps.sa.setGroupProperty(PropertyInterface("Skew Angle", o))), d.transform.op.setGroupProperty(PropertyInterface("Opacity", o)), Object.defineProperties(m, {
                        opacity: {
                            get: ExpressionPropertyInterface(d.transform.mProps.o)
                        },
                        position: {
                            get: ExpressionPropertyInterface(d.transform.mProps.p)
                        },
                        anchorPoint: {
                            get: ExpressionPropertyInterface(d.transform.mProps.a)
                        },
                        scale: {
                            get: ExpressionPropertyInterface(d.transform.mProps.s)
                        },
                        rotation: {
                            get: ExpressionPropertyInterface(d.transform.mProps.r)
                        },
                        skew: {
                            get: ExpressionPropertyInterface(d.transform.mProps.sk)
                        },
                        skewAxis: {
                            get: ExpressionPropertyInterface(d.transform.mProps.sa)
                        },
                        _name: {
                            value: y.nm
                        }
                    }), m.ty = "tr", m.mn = y.mn, m.propertyGroup = b, m
                }

                function g(y, d, b) {
                    function m(u) {
                        return y.p.ix === u ? m.position : y.s.ix === u ? m.size : null
                    }
                    var o = propertyGroupFactory(m, b);
                    m.propertyIndex = y.ix;
                    var f = d.sh.ty === "tm" ? d.sh.prop : d.sh;
                    return f.s.setGroupProperty(PropertyInterface("Size", o)), f.p.setGroupProperty(PropertyInterface("Position", o)), Object.defineProperties(m, {
                        size: {
                            get: ExpressionPropertyInterface(f.s)
                        },
                        position: {
                            get: ExpressionPropertyInterface(f.p)
                        },
                        _name: {
                            value: y.nm
                        }
                    }), m.mn = y.mn, m
                }

                function _(y, d, b) {
                    function m(u) {
                        return y.p.ix === u ? m.position : y.r.ix === u ? m.rotation : y.pt.ix === u ? m.points : y.or.ix === u || u === "ADBE Vector Star Outer Radius" ? m.outerRadius : y.os.ix === u ? m.outerRoundness : y.ir && (y.ir.ix === u || u === "ADBE Vector Star Inner Radius") ? m.innerRadius : y.is && y.is.ix === u ? m.innerRoundness : null
                    }
                    var o = propertyGroupFactory(m, b),
                        f = d.sh.ty === "tm" ? d.sh.prop : d.sh;
                    return m.propertyIndex = y.ix, f.or.setGroupProperty(PropertyInterface("Outer Radius", o)), f.os.setGroupProperty(PropertyInterface("Outer Roundness", o)), f.pt.setGroupProperty(PropertyInterface("Points", o)), f.p.setGroupProperty(PropertyInterface("Position", o)), f.r.setGroupProperty(PropertyInterface("Rotation", o)), y.ir && (f.ir.setGroupProperty(PropertyInterface("Inner Radius", o)), f.is.setGroupProperty(PropertyInterface("Inner Roundness", o))), Object.defineProperties(m, {
                        position: {
                            get: ExpressionPropertyInterface(f.p)
                        },
                        rotation: {
                            get: ExpressionPropertyInterface(f.r)
                        },
                        points: {
                            get: ExpressionPropertyInterface(f.pt)
                        },
                        outerRadius: {
                            get: ExpressionPropertyInterface(f.or)
                        },
                        outerRoundness: {
                            get: ExpressionPropertyInterface(f.os)
                        },
                        innerRadius: {
                            get: ExpressionPropertyInterface(f.ir)
                        },
                        innerRoundness: {
                            get: ExpressionPropertyInterface(f.is)
                        },
                        _name: {
                            value: y.nm
                        }
                    }), m.mn = y.mn, m
                }

                function E(y, d, b) {
                    function m(u) {
                        return y.p.ix === u ? m.position : y.r.ix === u ? m.roundness : y.s.ix === u || u === "Size" || u === "ADBE Vector Rect Size" ? m.size : null
                    }
                    var o = propertyGroupFactory(m, b),
                        f = d.sh.ty === "tm" ? d.sh.prop : d.sh;
                    return m.propertyIndex = y.ix, f.p.setGroupProperty(PropertyInterface("Position", o)), f.s.setGroupProperty(PropertyInterface("Size", o)), f.r.setGroupProperty(PropertyInterface("Rotation", o)), Object.defineProperties(m, {
                        position: {
                            get: ExpressionPropertyInterface(f.p)
                        },
                        roundness: {
                            get: ExpressionPropertyInterface(f.r)
                        },
                        size: {
                            get: ExpressionPropertyInterface(f.s)
                        },
                        _name: {
                            value: y.nm
                        }
                    }), m.mn = y.mn, m
                }

                function P(y, d, b) {
                    function m(u) {
                        return y.r.ix === u || u === "Round Corners 1" ? m.radius : null
                    }
                    var o = propertyGroupFactory(m, b),
                        f = d;
                    return m.propertyIndex = y.ix, f.rd.setGroupProperty(PropertyInterface("Radius", o)), Object.defineProperties(m, {
                        radius: {
                            get: ExpressionPropertyInterface(f.rd)
                        },
                        _name: {
                            value: y.nm
                        }
                    }), m.mn = y.mn, m
                }

                function x(y, d, b) {
                    function m(u) {
                        return y.c.ix === u || u === "Copies" ? m.copies : y.o.ix === u || u === "Offset" ? m.offset : null
                    }
                    var o = propertyGroupFactory(m, b),
                        f = d;
                    return m.propertyIndex = y.ix, f.c.setGroupProperty(PropertyInterface("Copies", o)), f.o.setGroupProperty(PropertyInterface("Offset", o)), Object.defineProperties(m, {
                        copies: {
                            get: ExpressionPropertyInterface(f.c)
                        },
                        offset: {
                            get: ExpressionPropertyInterface(f.o)
                        },
                        _name: {
                            value: y.nm
                        }
                    }), m.mn = y.mn, m
                }
                return function (y, d, b) {
                    var m;

                    function o(u) {
                        if (typeof u == "number") return u = u === void 0 ? 1 : u, u === 0 ? b : m[u - 1];
                        for (var S = 0, k = m.length; S < k;) {
                            if (m[S]._name === u) return m[S];
                            S += 1
                        }
                        return null
                    }

                    function f() {
                        return b
                    }
                    return o.propertyGroup = propertyGroupFactory(o, f), m = e(y, d, o.propertyGroup), o.numProperties = m.length, o._name = "Contents", o
                }
            }(),
            TextExpressionInterface = function () {
                return function (e) {
                    var t, r;

                    function i(s) {
                        switch (s) {
                            case "ADBE Text Document":
                                return i.sourceText;
                            default:
                                return null
                        }
                    }
                    return Object.defineProperty(i, "sourceText", {
                        get: function () {
                            e.textProperty.getValue();
                            var s = e.textProperty.currentData.t;
                            return s !== t && (e.textProperty.currentData.t = t, r = new String(s), r.value = s || new String(s)), r
                        }
                    }), i
                }
            }(),
            LayerExpressionInterface = function () {
                function e(g) {
                    var _ = new Matrix;
                    if (g !== void 0) {
                        var E = this._elem.finalTransform.mProp.getValueAtTime(g);
                        E.clone(_)
                    } else {
                        var P = this._elem.finalTransform.mProp;
                        P.applyToMatrix(_)
                    }
                    return _
                }

                function t(g, _) {
                    var E = this.getMatrix(_);
                    return E.props[12] = 0, E.props[13] = 0, E.props[14] = 0, this.applyPoint(E, g)
                }

                function r(g, _) {
                    var E = this.getMatrix(_);
                    return this.applyPoint(E, g)
                }

                function i(g, _) {
                    var E = this.getMatrix(_);
                    return E.props[12] = 0, E.props[13] = 0, E.props[14] = 0, this.invertPoint(E, g)
                }

                function s(g, _) {
                    var E = this.getMatrix(_);
                    return this.invertPoint(E, g)
                }

                function n(g, _) {
                    if (this._elem.hierarchy && this._elem.hierarchy.length) {
                        var E, P = this._elem.hierarchy.length;
                        for (E = 0; E < P; E += 1) this._elem.hierarchy[E].finalTransform.mProp.applyToMatrix(g)
                    }
                    return g.applyToPointArray(_[0], _[1], _[2] || 0)
                }

                function a(g, _) {
                    if (this._elem.hierarchy && this._elem.hierarchy.length) {
                        var E, P = this._elem.hierarchy.length;
                        for (E = 0; E < P; E += 1) this._elem.hierarchy[E].finalTransform.mProp.applyToMatrix(g)
                    }
                    return g.inversePoint(_)
                }

                function l(g) {
                    var _ = new Matrix;
                    if (_.reset(), this._elem.finalTransform.mProp.applyToMatrix(_), this._elem.hierarchy && this._elem.hierarchy.length) {
                        var E, P = this._elem.hierarchy.length;
                        for (E = 0; E < P; E += 1) this._elem.hierarchy[E].finalTransform.mProp.applyToMatrix(_);
                        return _.inversePoint(g)
                    }
                    return _.inversePoint(g)
                }

                function c() {
                    return [1, 1, 1, 1]
                }
                return function (g) {
                    var _;

                    function E(d) {
                        x.mask = new MaskManagerInterface(d, g)
                    }

                    function P(d) {
                        x.effect = d
                    }

                    function x(d) {
                        switch (d) {
                            case "ADBE Root Vectors Group":
                            case "Contents":
                            case 2:
                                return x.shapeInterface;
                            case 1:
                            case 6:
                            case "Transform":
                            case "transform":
                            case "ADBE Transform Group":
                                return _;
                            case 4:
                            case "ADBE Effect Parade":
                            case "effects":
                            case "Effects":
                                return x.effect;
                            case "ADBE Text Properties":
                                return x.textInterface;
                            default:
                                return null
                        }
                    }
                    x.getMatrix = e, x.invertPoint = a, x.applyPoint = n, x.toWorld = r, x.toWorldVec = t, x.fromWorld = s, x.fromWorldVec = i, x.toComp = r, x.fromComp = l, x.sampleImage = c, x.sourceRectAtTime = g.sourceRectAtTime.bind(g), x._elem = g, _ = TransformExpressionInterface(g.finalTransform.mProp);
                    var y = getDescriptor(_, "anchorPoint");
                    return Object.defineProperties(x, {
                        hasParent: {
                            get: function () {
                                return g.hierarchy.length
                            }
                        },
                        parent: {
                            get: function () {
                                return g.hierarchy[0].layerInterface
                            }
                        },
                        rotation: getDescriptor(_, "rotation"),
                        scale: getDescriptor(_, "scale"),
                        position: getDescriptor(_, "position"),
                        opacity: getDescriptor(_, "opacity"),
                        anchorPoint: y,
                        anchor_point: y,
                        transform: {
                            get: function () {
                                return _
                            }
                        },
                        active: {
                            get: function () {
                                return g.isInRange
                            }
                        }
                    }), x.startTime = g.data.st, x.index = g.data.ind, x.source = g.data.refId, x.height = g.data.ty === 0 ? g.data.h : 100, x.width = g.data.ty === 0 ? g.data.w : 100, x.inPoint = g.data.ip / g.comp.globalData.frameRate, x.outPoint = g.data.op / g.comp.globalData.frameRate, x._name = g.data.nm, x.registerMaskInterface = E, x.registerEffectsInterface = P, x
                }
            }(),
            FootageInterface = function () {
                var e = function (r) {
                        var i = "",
                            s = r.getFootageData();

                        function n() {
                            return i = "", s = r.getFootageData(), a
                        }

                        function a(l) {
                            if (s[l]) return i = l, s = s[l], typeof s == "object" ? a : s;
                            var c = l.indexOf(i);
                            if (c !== -1) {
                                var g = parseInt(l.substr(c + i.length), 10);
                                return s = s[g], typeof s == "object" ? a : s
                            }
                            return ""
                        }
                        return n
                    },
                    t = function (r) {
                        function i(s) {
                            return s === "Outline" ? i.outlineInterface() : null
                        }
                        return i._name = "Outline", i.outlineInterface = e(r), i
                    };
                return function (r) {
                    function i(s) {
                        return s === "Data" ? i.dataInterface : null
                    }
                    return i._name = "Data", i.dataInterface = t(r), i
                }
            }(),
            CompExpressionInterface = function () {
                return function (e) {
                    function t(r) {
                        for (var i = 0, s = e.layers.length; i < s;) {
                            if (e.layers[i].nm === r || e.layers[i].ind === r) return e.elements[i].layerInterface;
                            i += 1
                        }
                        return null
                    }
                    return Object.defineProperty(t, "_name", {
                        value: e.data.nm
                    }), t.layer = t, t.pixelAspect = 1, t.height = e.data.h || e.globalData.compSize.h, t.width = e.data.w || e.globalData.compSize.w, t.pixelAspect = 1, t.frameDuration = 1 / e.globalData.frameRate, t.displayStartTime = 0, t.numLayers = e.layers.length, t
                }
            }(),
            TransformExpressionInterface = function () {
                return function (e) {
                    function t(a) {
                        switch (a) {
                            case "scale":
                            case "Scale":
                            case "ADBE Scale":
                            case 6:
                                return t.scale;
                            case "rotation":
                            case "Rotation":
                            case "ADBE Rotation":
                            case "ADBE Rotate Z":
                            case 10:
                                return t.rotation;
                            case "ADBE Rotate X":
                                return t.xRotation;
                            case "ADBE Rotate Y":
                                return t.yRotation;
                            case "position":
                            case "Position":
                            case "ADBE Position":
                            case 2:
                                return t.position;
                            case "ADBE Position_0":
                                return t.xPosition;
                            case "ADBE Position_1":
                                return t.yPosition;
                            case "ADBE Position_2":
                                return t.zPosition;
                            case "anchorPoint":
                            case "AnchorPoint":
                            case "Anchor Point":
                            case "ADBE AnchorPoint":
                            case 1:
                                return t.anchorPoint;
                            case "opacity":
                            case "Opacity":
                            case 11:
                                return t.opacity;
                            default:
                                return null
                        }
                    }
                    Object.defineProperty(t, "rotation", {
                        get: ExpressionPropertyInterface(e.r || e.rz)
                    }), Object.defineProperty(t, "zRotation", {
                        get: ExpressionPropertyInterface(e.rz || e.r)
                    }), Object.defineProperty(t, "xRotation", {
                        get: ExpressionPropertyInterface(e.rx)
                    }), Object.defineProperty(t, "yRotation", {
                        get: ExpressionPropertyInterface(e.ry)
                    }), Object.defineProperty(t, "scale", {
                        get: ExpressionPropertyInterface(e.s)
                    });
                    var r, i, s, n;
                    return e.p ? n = ExpressionPropertyInterface(e.p) : (r = ExpressionPropertyInterface(e.px), i = ExpressionPropertyInterface(e.py), e.pz && (s = ExpressionPropertyInterface(e.pz))), Object.defineProperty(t, "position", {
                        get: function () {
                            return e.p ? n() : [r(), i(), s ? s() : 0]
                        }
                    }), Object.defineProperty(t, "xPosition", {
                        get: ExpressionPropertyInterface(e.px)
                    }), Object.defineProperty(t, "yPosition", {
                        get: ExpressionPropertyInterface(e.py)
                    }), Object.defineProperty(t, "zPosition", {
                        get: ExpressionPropertyInterface(e.pz)
                    }), Object.defineProperty(t, "anchorPoint", {
                        get: ExpressionPropertyInterface(e.a)
                    }), Object.defineProperty(t, "opacity", {
                        get: ExpressionPropertyInterface(e.o)
                    }), Object.defineProperty(t, "skew", {
                        get: ExpressionPropertyInterface(e.sk)
                    }), Object.defineProperty(t, "skewAxis", {
                        get: ExpressionPropertyInterface(e.sa)
                    }), Object.defineProperty(t, "orientation", {
                        get: ExpressionPropertyInterface(e.or)
                    }), t
                }
            }(),
            ProjectInterface = function () {
                function e(t) {
                    this.compositions.push(t)
                }
                return function () {
                    function t(r) {
                        for (var i = 0, s = this.compositions.length; i < s;) {
                            if (this.compositions[i].data && this.compositions[i].data.nm === r) return this.compositions[i].prepareFrame && this.compositions[i].data.xt && this.compositions[i].prepareFrame(this.currentFrame), this.compositions[i].compInterface;
                            i += 1
                        }
                        return null
                    }
                    return t.compositions = [], t.currentFrame = 0, t.registerComposition = e, t
                }
            }(),
            EffectsExpressionInterface = function () {
                var e = {
                    createEffectsInterface: t
                };

                function t(s, n) {
                    if (s.effectsManager) {
                        var a = [],
                            l = s.data.ef,
                            c, g = s.effectsManager.effectElements.length;
                        for (c = 0; c < g; c += 1) a.push(r(l[c], s.effectsManager.effectElements[c], n, s));
                        var _ = s.data.ef || [],
                            E = function (P) {
                                for (c = 0, g = _.length; c < g;) {
                                    if (P === _[c].nm || P === _[c].mn || P === _[c].ix) return a[c];
                                    c += 1
                                }
                                return null
                            };
                        return Object.defineProperty(E, "numProperties", {
                            get: function () {
                                return _.length
                            }
                        }), E
                    }
                    return null
                }

                function r(s, n, a, l) {
                    function c(x) {
                        for (var y = s.ef, d = 0, b = y.length; d < b;) {
                            if (x === y[d].nm || x === y[d].mn || x === y[d].ix) return y[d].ty === 5 ? _[d] : _[d]();
                            d += 1
                        }
                        throw new Error
                    }
                    var g = propertyGroupFactory(c, a),
                        _ = [],
                        E, P = s.ef.length;
                    for (E = 0; E < P; E += 1) s.ef[E].ty === 5 ? _.push(r(s.ef[E], n.effectElements[E], n.effectElements[E].propertyGroup, l)) : _.push(i(n.effectElements[E], s.ef[E].ty, l, g));
                    return s.mn === "ADBE Color Control" && Object.defineProperty(c, "color", {
                        get: function () {
                            return _[0]()
                        }
                    }), Object.defineProperties(c, {
                        numProperties: {
                            get: function () {
                                return s.np
                            }
                        },
                        _name: {
                            value: s.nm
                        },
                        propertyGroup: {
                            value: g
                        }
                    }), c.enabled = s.en !== 0, c.active = c.enabled, c
                }

                function i(s, n, a, l) {
                    var c = ExpressionPropertyInterface(s.p);

                    function g() {
                        return n === 10 ? a.comp.compInterface(s.p.v) : c()
                    }
                    return s.p.setGroupProperty && s.p.setGroupProperty(PropertyInterface("", l)), g
                }
                return e
            }(),
            MaskManagerInterface = function () {
                function e(r, i) {
                    this._mask = r, this._data = i
                }
                Object.defineProperty(e.prototype, "maskPath", {
                    get: function () {
                        return this._mask.prop.k && this._mask.prop.getValue(), this._mask.prop
                    }
                }), Object.defineProperty(e.prototype, "maskOpacity", {
                    get: function () {
                        return this._mask.op.k && this._mask.op.getValue(), this._mask.op.v * 100
                    }
                });
                var t = function (r) {
                    var i = createSizedArray(r.viewData.length),
                        s, n = r.viewData.length;
                    for (s = 0; s < n; s += 1) i[s] = new e(r.viewData[s], r.masksProperties[s]);
                    var a = function (l) {
                        for (s = 0; s < n;) {
                            if (r.masksProperties[s].nm === l) return i[s];
                            s += 1
                        }
                        return null
                    };
                    return a
                };
                return t
            }(),
            ExpressionPropertyInterface = function () {
                var e = {
                        pv: 0,
                        v: 0,
                        mult: 1
                    },
                    t = {
                        pv: [0, 0, 0],
                        v: [0, 0, 0],
                        mult: 1
                    };

                function r(a, l, c) {
                    Object.defineProperty(a, "velocity", {
                        get: function () {
                            return l.getVelocityAtTime(l.comp.currentFrame)
                        }
                    }), a.numKeys = l.keyframes ? l.keyframes.length : 0, a.key = function (g) {
                        if (!a.numKeys) return 0;
                        var _ = "";
                        "s" in l.keyframes[g - 1] ? _ = l.keyframes[g - 1].s : "e" in l.keyframes[g - 2] ? _ = l.keyframes[g - 2].e : _ = l.keyframes[g - 2].s;
                        var E = c === "unidimensional" ? new Number(_) : Object.assign({}, _);
                        return E.time = l.keyframes[g - 1].t / l.elem.comp.globalData.frameRate, E.value = c === "unidimensional" ? _[0] : _, E
                    }, a.valueAtTime = l.getValueAtTime, a.speedAtTime = l.getSpeedAtTime, a.velocityAtTime = l.getVelocityAtTime, a.propertyGroup = l.propertyGroup
                }

                function i(a) {
                    (!a || !("pv" in a)) && (a = e);
                    var l = 1 / a.mult,
                        c = a.pv * l,
                        g = new Number(c);
                    return g.value = c, r(g, a, "unidimensional"),
                        function () {
                            return a.k && a.getValue(), c = a.v * l, g.value !== c && (g = new Number(c), g.value = c, r(g, a, "unidimensional")), g
                        }
                }

                function s(a) {
                    (!a || !("pv" in a)) && (a = t);
                    var l = 1 / a.mult,
                        c = a.data && a.data.l || a.pv.length,
                        g = createTypedArray("float32", c),
                        _ = createTypedArray("float32", c);
                    return g.value = _, r(g, a, "multidimensional"),
                        function () {
                            a.k && a.getValue();
                            for (var E = 0; E < c; E += 1) _[E] = a.v[E] * l, g[E] = _[E];
                            return g
                        }
                }

                function n() {
                    return e
                }
                return function (a) {
                    return a ? a.propType === "unidimensional" ? i(a) : s(a) : n
                }
            }(),
            TextExpressionSelectorPropFactory = function () {
                function e(t, r) {
                    return this.textIndex = t + 1, this.textTotal = r, this.v = this.getValue() * this.mult, this.v
                }
                return function (t, r) {
                    this.pv = 1, this.comp = t.comp, this.elem = t, this.mult = .01, this.propType = "textSelector", this.textTotal = r.totalChars, this.selectorValue = 100, this.lastValue = [1, 1, 1], this.k = !0, this.x = !0, this.getValue = ExpressionManager.initiateExpression.bind(this)(t, r, this), this.getMult = e, this.getVelocityAtTime = expressionHelpers.getVelocityAtTime, this.kf ? this.getValueAtTime = expressionHelpers.getValueAtTime.bind(this) : this.getValueAtTime = expressionHelpers.getStaticValueAtTime.bind(this), this.setGroupProperty = expressionHelpers.setGroupProperty
                }
            }(),
            propertyGetTextProp = TextSelectorProp.getTextSelectorProp;
        TextSelectorProp.getTextSelectorProp = function (e, t, r) {
            return t.t === 1 ? new TextExpressionSelectorPropFactory(e, t, r) : propertyGetTextProp(e, t, r)
        };

        function SliderEffect(e, t, r) {
            this.p = PropertyFactory.getProp(t, e.v, 0, 0, r)
        }

        function AngleEffect(e, t, r) {
            this.p = PropertyFactory.getProp(t, e.v, 0, 0, r)
        }

        function ColorEffect(e, t, r) {
            this.p = PropertyFactory.getProp(t, e.v, 1, 0, r)
        }

        function PointEffect(e, t, r) {
            this.p = PropertyFactory.getProp(t, e.v, 1, 0, r)
        }

        function LayerIndexEffect(e, t, r) {
            this.p = PropertyFactory.getProp(t, e.v, 0, 0, r)
        }

        function MaskIndexEffect(e, t, r) {
            this.p = PropertyFactory.getProp(t, e.v, 0, 0, r)
        }

        function CheckboxEffect(e, t, r) {
            this.p = PropertyFactory.getProp(t, e.v, 0, 0, r)
        }

        function NoValueEffect() {
            this.p = {}
        }

        function EffectsManager(e, t) {
            var r = e.ef || [];
            this.effectElements = [];
            var i, s = r.length,
                n;
            for (i = 0; i < s; i += 1) n = new GroupEffect(r[i], t), this.effectElements.push(n)
        }

        function GroupEffect(e, t) {
            this.init(e, t)
        }
        extendPrototype([DynamicPropertyContainer], GroupEffect), GroupEffect.prototype.getValue = GroupEffect.prototype.iterateDynamicProperties, GroupEffect.prototype.init = function (e, t) {
            this.data = e, this.effectElements = [], this.initDynamicPropertyContainer(t);
            var r, i = this.data.ef.length,
                s, n = this.data.ef;
            for (r = 0; r < i; r += 1) {
                switch (s = null, n[r].ty) {
                    case 0:
                        s = new SliderEffect(n[r], t, this);
                        break;
                    case 1:
                        s = new AngleEffect(n[r], t, this);
                        break;
                    case 2:
                        s = new ColorEffect(n[r], t, this);
                        break;
                    case 3:
                        s = new PointEffect(n[r], t, this);
                        break;
                    case 4:
                    case 7:
                        s = new CheckboxEffect(n[r], t, this);
                        break;
                    case 10:
                        s = new LayerIndexEffect(n[r], t, this);
                        break;
                    case 11:
                        s = new MaskIndexEffect(n[r], t, this);
                        break;
                    case 5:
                        s = new EffectsManager(n[r], t);
                        break;
                    default:
                        s = new NoValueEffect(n[r]);
                        break
                }
                s && this.effectElements.push(s)
            }
        };
        var lottie = {};

        function setLocationHref(e) {
            locationHref = e
        }

        function searchAnimations() {
            animationManager.searchAnimations()
        }

        function setSubframeRendering(e) {
            subframeEnabled = e
        }

        function setIDPrefix(e) {
            idPrefix = e
        }

        function loadAnimation(e) {
            return animationManager.loadAnimation(e)
        }

        function setQuality(e) {
            if (typeof e == "string") switch (e) {
                case "high":
                    defaultCurveSegments = 200;
                    break;
                default:
                case "medium":
                    defaultCurveSegments = 50;
                    break;
                case "low":
                    defaultCurveSegments = 10;
                    break
            } else !isNaN(e) && e > 1 && (defaultCurveSegments = e)
        }

        function inBrowser() {
            return typeof navigator < "u"
        }

        function installPlugin(e, t) {
            e === "expressions" && (expressionsPlugin = t)
        }

        function getFactory(e) {
            switch (e) {
                case "propertyFactory":
                    return PropertyFactory;
                case "shapePropertyFactory":
                    return ShapePropertyFactory;
                case "matrix":
                    return Matrix;
                default:
                    return null
            }
        }
        lottie.play = animationManager.play, lottie.pause = animationManager.pause, lottie.setLocationHref = setLocationHref, lottie.togglePause = animationManager.togglePause, lottie.setSpeed = animationManager.setSpeed, lottie.setDirection = animationManager.setDirection, lottie.stop = animationManager.stop, lottie.searchAnimations = searchAnimations, lottie.registerAnimation = animationManager.registerAnimation, lottie.loadAnimation = loadAnimation, lottie.setSubframeRendering = setSubframeRendering, lottie.resize = animationManager.resize, lottie.goToAndStop = animationManager.goToAndStop, lottie.destroy = animationManager.destroy, lottie.setQuality = setQuality, lottie.inBrowser = inBrowser, lottie.installPlugin = installPlugin, lottie.freeze = animationManager.freeze, lottie.unfreeze = animationManager.unfreeze, lottie.setVolume = animationManager.setVolume, lottie.mute = animationManager.mute, lottie.unmute = animationManager.unmute, lottie.getRegisteredAnimations = animationManager.getRegisteredAnimations, lottie.setIDPrefix = setIDPrefix, lottie.__getFactory = getFactory, lottie.version = "5.7.13";

        function checkReady() {
            document.readyState === "complete" && (clearInterval(readyStateCheckInterval), searchAnimations())
        }

        function getQueryVariable(e) {
            for (var t = queryString.split("&"), r = 0; r < t.length; r += 1) {
                var i = t[r].split("=");
                if (decodeURIComponent(i[0]) == e) return decodeURIComponent(i[1])
            }
            return null
        }
        var queryString; {
            var scripts = document.getElementsByTagName("script"),
                index = scripts.length - 1,
                myScript = scripts[index] || {
                    src: ""
                };
            queryString = myScript.src.replace(/^[^\?]+\??/, ""), getQueryVariable("renderer")
        }
        var readyStateCheckInterval = setInterval(checkReady, 100);
        return lottie
    })
})(lottie);
var lottieExports = lottie.exports;
const Lottie = getDefaultExportFromCjs(lottieExports),
    _sfc_main$i = {
        __name: "Lottie",
        props: {
            options: Object,
            height: Number,
            width: Number
        },
        emits: ["animCreated"],
        setup(e, {
            emit: t
        }) {
            const r = e,
                i = ref(null),
                s = ref({
                    width: r.width ? `${r.width}px` : "100%",
                    height: r.height ? `${r.height}px` : "100%",
                    overflow: "hidden"
                });
            return onMounted(() => {
                const n = Lottie.loadAnimation({
                    container: i.value,
                    renderer: "svg",
                    loop: r.options.loop,
                    autoplay: r.options.autoplay,
                    animationData: r.options.animationData,
                    rendererSettings: r.options.rendererSettings
                });
                t("animCreated", n)
            }), (n, a) => (openBlock(), createElementBlock("div", {
                class: "lottie-wrap",
                style: normalizeStyle(s.value),
                ref_key: "lavContainer",
                ref: i
            }, null, 4))
        }
    },
    v = "5.1.1",
    fr = 60,
    ip = 0,
    op = 232,
    w = 472,
    h = 472,
    nm = "",
    ddd = 0,
    assets = [{
        id: "comp_0",
        layers: [{
            ddd: 0,
            ind: 1,
            ty: 3,
            nm: "",
            sr: 1,
            ks: {
                o: {
                    a: 0,
                    k: 0,
                    ix: 11
                },
                r: {
                    a: 0,
                    k: 9,
                    ix: 10
                },
                p: {
                    a: 0,
                    k: [236, 236, 0],
                    ix: 2
                },
                a: {
                    a: 0,
                    k: [50, 50, 0],
                    ix: 1
                },
                s: {
                    a: 0,
                    k: [100, 100, 100],
                    ix: 6
                }
            },
            ao: 0,
            ip: 0,
            op: 3600,
            st: 0,
            bm: 0
        }, {
            ddd: 0,
            ind: 2,
            ty: 4,
            nm: "dot-s",
            parent: 1,
            sr: 1,
            ks: {
                o: {
                    a: 0,
                    k: 100,
                    ix: 11
                },
                r: {
                    a: 0,
                    k: 0,
                    ix: 10
                },
                p: {
                    a: 1,
                    k: [{
                        i: {
                            x: .332,
                            y: 1
                        },
                        o: {
                            x: .333,
                            y: 0
                        },
                        n: "0p332_1_0p333_0",
                        t: 197,
                        s: [50, 94.6, 0],
                        e: [50, 111.1, 0],
                        to: [0, 0, 0],
                        ti: [0, 0, 0]
                    }, {
                        t: 211
                    }],
                    ix: 2
                },
                a: {
                    a: 0,
                    k: [.583, 48.333, 0],
                    ix: 1
                },
                s: {
                    a: 1,
                    k: [{
                        i: {
                            x: [.667, .667, .667],
                            y: [1, 1, 1]
                        },
                        o: {
                            x: [.333, .333, .333],
                            y: [0, 0, 0]
                        },
                        n: ["0p667_1_0p333_0", "0p667_1_0p333_0", "0p667_1_0p333_0"],
                        t: 211,
                        s: [68, 68, 100],
                        e: [0, 0, 100]
                    }, {
                        t: 222
                    }],
                    ix: 6
                }
            },
            ao: 0,
            shapes: [{
                ty: "gr",
                it: [{
                    d: 1,
                    ty: "el",
                    s: {
                        a: 0,
                        k: [8, 8],
                        ix: 2
                    },
                    p: {
                        a: 0,
                        k: [0, 0],
                        ix: 3
                    },
                    nm: "",
                    mn: "ADBE Vector Shape - Ellipse",
                    hd: !1
                }, {
                    ty: "fl",
                    c: {
                        a: 0,
                        k: [.333333333333, .866666666667, .949019607843, 1],
                        ix: 4
                    },
                    o: {
                        a: 0,
                        k: 100,
                        ix: 5
                    },
                    r: 1,
                    nm: "",
                    mn: "ADBE Vector Graphic - Fill",
                    hd: !1
                }, {
                    ty: "tr",
                    p: {
                        a: 0,
                        k: [.583, 44.333],
                        ix: 2
                    },
                    a: {
                        a: 0,
                        k: [0, 0],
                        ix: 1
                    },
                    s: {
                        a: 0,
                        k: [100, 100],
                        ix: 3
                    },
                    r: {
                        a: 0,
                        k: 0,
                        ix: 6
                    },
                    o: {
                        a: 0,
                        k: 100,
                        ix: 7
                    },
                    sk: {
                        a: 0,
                        k: 0,
                        ix: 4
                    },
                    sa: {
                        a: 0,
                        k: 0,
                        ix: 5
                    },
                    nm: ""
                }],
                nm: "",
                np: 3,
                cix: 2,
                ix: 1,
                mn: "ADBE Vector Group",
                hd: !1
            }],
            ip: 197,
            op: 3603,
            st: 3,
            bm: 0
        }, {
            ddd: 0,
            ind: 3,
            ty: 4,
            nm: "dot1",
            sr: 1,
            ks: {
                o: {
                    a: 0,
                    k: 100,
                    ix: 11
                },
                r: {
                    a: 0,
                    k: 0,
                    ix: 10
                },
                p: {
                    a: 1,
                    k: [{
                        i: {
                            x: .332,
                            y: 1
                        },
                        o: {
                            x: .333,
                            y: 0
                        },
                        n: "0p332_1_0p333_0",
                        t: 194,
                        s: [236, 282, 0],
                        e: [236, 298, 0],
                        to: [0, 0, 0],
                        ti: [0, 0, 0]
                    }, {
                        t: 208
                    }],
                    ix: 2
                },
                a: {
                    a: 0,
                    k: [.583, 48.333, 0],
                    ix: 1
                },
                s: {
                    a: 1,
                    k: [{
                        i: {
                            x: [.667, .667, .667],
                            y: [1, 1, 1]
                        },
                        o: {
                            x: [.333, .333, .333],
                            y: [0, 0, 0]
                        },
                        n: ["0p667_1_0p333_0", "0p667_1_0p333_0", "0p667_1_0p333_0"],
                        t: 208,
                        s: [100, 100, 100],
                        e: [0, 0, 100]
                    }, {
                        t: 219
                    }],
                    ix: 6
                }
            },
            ao: 0,
            shapes: [{
                ty: "gr",
                it: [{
                    d: 1,
                    ty: "el",
                    s: {
                        a: 0,
                        k: [8, 8],
                        ix: 2
                    },
                    p: {
                        a: 0,
                        k: [0, 0],
                        ix: 3
                    },
                    nm: "",
                    mn: "ADBE Vector Shape - Ellipse",
                    hd: !1
                }, {
                    ty: "fl",
                    c: {
                        a: 0,
                        k: [.333333333333, .866666666667, .949019607843, 1],
                        ix: 4
                    },
                    o: {
                        a: 0,
                        k: 100,
                        ix: 5
                    },
                    r: 1,
                    nm: "",
                    mn: "ADBE Vector Graphic - Fill",
                    hd: !1
                }, {
                    ty: "tr",
                    p: {
                        a: 0,
                        k: [.583, 44.333],
                        ix: 2
                    },
                    a: {
                        a: 0,
                        k: [0, 0],
                        ix: 1
                    },
                    s: {
                        a: 0,
                        k: [100, 100],
                        ix: 3
                    },
                    r: {
                        a: 0,
                        k: 0,
                        ix: 6
                    },
                    o: {
                        a: 0,
                        k: 100,
                        ix: 7
                    },
                    sk: {
                        a: 0,
                        k: 0,
                        ix: 4
                    },
                    sa: {
                        a: 0,
                        k: 0,
                        ix: 5
                    },
                    nm: ""
                }],
                nm: "",
                np: 3,
                cix: 2,
                ix: 1,
                mn: "ADBE Vector Group",
                hd: !1
            }],
            ip: 194,
            op: 3600,
            st: 0,
            bm: 0
        }]
    }],
    layers = [{
        ddd: 0,
        ind: 1,
        ty: 4,
        nm: "“icon_switch”",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 0,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [38, 39, 0],
                ix: 1
            },
            s: {
                a: 1,
                k: [{
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 191,
                    s: [0, 0, 100],
                    e: [2.8, 2.8, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 192,
                    s: [2.8, 2.8, 100],
                    e: [10.4, 10.4, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 193,
                    s: [10.4, 10.4, 100],
                    e: [21.6, 21.6, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 194,
                    s: [21.6, 21.6, 100],
                    e: [35.2, 35.2, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 195,
                    s: [35.2, 35.2, 100],
                    e: [50, 50, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 196,
                    s: [50, 50, 100],
                    e: [64.8, 64.8, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 197,
                    s: [64.8, 64.8, 100],
                    e: [78.4, 78.4, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 198,
                    s: [78.4, 78.4, 100],
                    e: [89.6, 89.6, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 199,
                    s: [89.6, 89.6, 100],
                    e: [97.2, 97.2, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 200,
                    s: [97.2, 97.2, 100],
                    e: [100, 100, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 201,
                    s: [100, 100, 100],
                    e: [104.722, 104.722, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 202,
                    s: [104.722, 104.722, 100],
                    e: [108.642, 108.642, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 203,
                    s: [108.642, 108.642, 100],
                    e: [111.684, 111.684, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 204,
                    s: [111.684, 111.684, 100],
                    e: [113.819, 113.819, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 205,
                    s: [113.819, 113.819, 100],
                    e: [115.066, 115.066, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 206,
                    s: [115.066, 115.066, 100],
                    e: [115.478, 115.478, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 207,
                    s: [115.478, 115.478, 100],
                    e: [115.142, 115.142, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 208,
                    s: [115.142, 115.142, 100],
                    e: [114.165, 114.165, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 209,
                    s: [114.165, 114.165, 100],
                    e: [112.672, 112.672, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 210,
                    s: [112.672, 112.672, 100],
                    e: [110.795, 110.795, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 211,
                    s: [110.795, 110.795, 100],
                    e: [108.666, 108.666, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 212,
                    s: [108.666, 108.666, 100],
                    e: [106.412, 106.412, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 213,
                    s: [106.412, 106.412, 100],
                    e: [104.151, 104.151, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 214,
                    s: [104.151, 104.151, 100],
                    e: [101.985, 101.985, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 215,
                    s: [101.985, 101.985, 100],
                    e: [100, 100, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 216,
                    s: [100, 100, 100],
                    e: [98.263, 98.263, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 217,
                    s: [98.263, 98.263, 100],
                    e: [96.821, 96.821, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 218,
                    s: [96.821, 96.821, 100],
                    e: [95.702, 95.702, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 219,
                    s: [95.702, 95.702, 100],
                    e: [94.916, 94.916, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 220,
                    s: [94.916, 94.916, 100],
                    e: [94.458, 94.458, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 221,
                    s: [94.458, 94.458, 100],
                    e: [94.306, 94.306, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 222,
                    s: [94.306, 94.306, 100],
                    e: [94.43, 94.43, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 223,
                    s: [94.43, 94.43, 100],
                    e: [94.789, 94.789, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 224,
                    s: [94.789, 94.789, 100],
                    e: [95.338, 95.338, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 225,
                    s: [95.338, 95.338, 100],
                    e: [96.029, 96.029, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 226,
                    s: [96.029, 96.029, 100],
                    e: [96.812, 96.812, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 227,
                    s: [96.812, 96.812, 100],
                    e: [97.641, 97.641, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 228,
                    s: [97.641, 97.641, 100],
                    e: [98.473, 98.473, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 229,
                    s: [98.473, 98.473, 100],
                    e: [99.27, 99.27, 100]
                }, {
                    i: {
                        x: [.833, .833, .833],
                        y: [.833, .833, .833]
                    },
                    o: {
                        x: [.167, .167, .167],
                        y: [.167, .167, .167]
                    },
                    n: ["0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167", "0p833_0p833_0p167_0p167"],
                    t: 230,
                    s: [99.27, 99.27, 100],
                    e: [100, 100, 100]
                }, {
                    t: 231
                }],
                ix: 6
            }
        },
        ao: 0,
        shapes: [{
            ty: "gr",
            it: [{
                ind: 0,
                ty: "sh",
                ix: 1,
                ks: {
                    a: 0,
                    k: {
                        i: [[0, 0], [0, 0], [0, 0], [0, 0]],
                        o: [[0, 0], [0, 0], [0, 0], [0, 0]],
                        v: [[-4, -39], [4, -39], [4, 5], [-4, 5]],
                        c: !0
                    },
                    ix: 2
                },
                nm: "",
                mn: "ADBE Vector Shape - Group",
                hd: !1
            }, {
                ind: 1,
                ty: "sh",
                ix: 2,
                ks: {
                    a: 0,
                    k: {
                        i: [[-12.992, 6.04], [0, 0], [0, -10.686], [-16.568, 0], [0, 16.568], [8.413, 5.315], [0, 0], [0, -15.271], [20.986, 0], [0, 20.986]],
                        o: [[0, 0], [-8.413, 5.315], [0, 16.568], [16.568, 0], [0, -10.686], [0, 0], [12.992, 6.04], [0, 20.986], [-20.987, 0], [0, -15.271]],
                        v: [[-16, -33.478], [-16, -24.382], [-30, 1], [0, 31], [30, 1], [16, -24.382], [16, -33.478], [38, 1], [0, 39], [-38, 1]],
                        c: !0
                    },
                    ix: 2
                },
                nm: "",
                mn: "ADBE Vector Shape - Group",
                hd: !1
            }, {
                ty: "fl",
                c: {
                    a: 0,
                    k: [.333333333333, .866666666667, .949019607843, 1],
                    ix: 4
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 5
                },
                r: 1,
                nm: "",
                mn: "ADBE Vector Graphic - Fill",
                hd: !1
            }, {
                ty: "tr",
                p: {
                    a: 0,
                    k: [38, 39],
                    ix: 2
                },
                a: {
                    a: 0,
                    k: [0, 0],
                    ix: 1
                },
                s: {
                    a: 0,
                    k: [100, 100],
                    ix: 3
                },
                r: {
                    a: 0,
                    k: 0,
                    ix: 6
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 7
                },
                sk: {
                    a: 0,
                    k: 0,
                    ix: 4
                },
                sa: {
                    a: 0,
                    k: 0,
                    ix: 5
                },
                nm: ""
            }],
            nm: "",
            np: 3,
            cix: 2,
            ix: 1,
            mn: "ADBE Vector Group",
            hd: !1
        }],
        ip: 191,
        op: 3600,
        st: 0,
        bm: 0
    }, {
        ddd: 0,
        ind: 2,
        ty: 4,
        nm: "“icon_switch”",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 0,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [38, 39, 0],
                ix: 1
            },
            s: {
                a: 1,
                k: [{
                    i: {
                        x: [.667, .667, .667],
                        y: [1, 1, 1]
                    },
                    o: {
                        x: [.333, .333, .333],
                        y: [0, 0, 0]
                    },
                    n: ["0p667_1_0p333_0", "0p667_1_0p333_0", "0p667_1_0p333_0"],
                    t: 186,
                    s: [100, 100, 100],
                    e: [0, 0, 100]
                }, {
                    t: 196
                }],
                ix: 6
            }
        },
        ao: 0,
        shapes: [{
            ty: "gr",
            it: [{
                ind: 0,
                ty: "sh",
                ix: 1,
                ks: {
                    a: 0,
                    k: {
                        i: [[0, 0], [0, 0], [0, 0], [0, 0]],
                        o: [[0, 0], [0, 0], [0, 0], [0, 0]],
                        v: [[-4, -39], [4, -39], [4, 5], [-4, 5]],
                        c: !0
                    },
                    ix: 2
                },
                nm: "",
                mn: "ADBE Vector Shape - Group",
                hd: !1
            }, {
                ind: 1,
                ty: "sh",
                ix: 2,
                ks: {
                    a: 0,
                    k: {
                        i: [[-12.992, 6.04], [0, 0], [0, -10.686], [-16.568, 0], [0, 16.568], [8.413, 5.315], [0, 0], [0, -15.271], [20.986, 0], [0, 20.986]],
                        o: [[0, 0], [-8.413, 5.315], [0, 16.568], [16.568, 0], [0, -10.686], [0, 0], [12.992, 6.04], [0, 20.986], [-20.987, 0], [0, -15.271]],
                        v: [[-16, -33.478], [-16, -24.382], [-30, 1], [0, 31], [30, 1], [16, -24.382], [16, -33.478], [38, 1], [0, 39], [-38, 1]],
                        c: !0
                    },
                    ix: 2
                },
                nm: "",
                mn: "ADBE Vector Shape - Group",
                hd: !1
            }, {
                ty: "fl",
                c: {
                    a: 0,
                    k: [.717647058824, .717647058824, .717647058824, 1],
                    ix: 4
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 5
                },
                r: 1,
                nm: "",
                mn: "ADBE Vector Graphic - Fill",
                hd: !1
            }, {
                ty: "tr",
                p: {
                    a: 0,
                    k: [38, 39],
                    ix: 2
                },
                a: {
                    a: 0,
                    k: [0, 0],
                    ix: 1
                },
                s: {
                    a: 0,
                    k: [100, 100],
                    ix: 3
                },
                r: {
                    a: 0,
                    k: 0,
                    ix: 6
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 7
                },
                sk: {
                    a: 0,
                    k: 0,
                    ix: 4
                },
                sa: {
                    a: 0,
                    k: 0,
                    ix: 5
                },
                nm: ""
            }],
            nm: "",
            np: 3,
            cix: 2,
            ix: 1,
            mn: "ADBE Vector Group",
            hd: !1
        }],
        ip: 0,
        op: 3600,
        st: 0,
        bm: 0
    }, {
        ddd: 0,
        ind: 5,
        ty: 0,
        nm: "dot",
        refId: "comp_0",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 309.1,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [236, 236, 0],
                ix: 1
            },
            s: {
                a: 0,
                k: [100, 100, 100],
                ix: 6
            }
        },
        ao: 0,
        w: 472,
        h: 472,
        ip: 0,
        op: 3600,
        st: 0,
        bm: 0
    }, {
        ddd: 0,
        ind: 6,
        ty: 0,
        nm: "dot",
        refId: "comp_0",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 257,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [236, 236, 0],
                ix: 1
            },
            s: {
                a: 0,
                k: [100, 100, 100],
                ix: 6
            }
        },
        ao: 0,
        w: 472,
        h: 472,
        ip: 0,
        op: 3600,
        st: 0,
        bm: 0
    }, {
        ddd: 0,
        ind: 7,
        ty: 0,
        nm: "dot",
        refId: "comp_0",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 205.5,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [236, 236, 0],
                ix: 1
            },
            s: {
                a: 0,
                k: [100, 100, 100],
                ix: 6
            }
        },
        ao: 0,
        w: 472,
        h: 472,
        ip: 0,
        op: 3600,
        st: 0,
        bm: 0
    }, {
        ddd: 0,
        ind: 8,
        ty: 0,
        nm: "dot",
        refId: "comp_0",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 154,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [236, 236, 0],
                ix: 1
            },
            s: {
                a: 0,
                k: [100, 100, 100],
                ix: 6
            }
        },
        ao: 0,
        w: 472,
        h: 472,
        ip: 0,
        op: 3600,
        st: 0,
        bm: 0
    }, {
        ddd: 0,
        ind: 9,
        ty: 0,
        nm: "dot",
        refId: "comp_0",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 102,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [236, 236, 0],
                ix: 1
            },
            s: {
                a: 0,
                k: [100, 100, 100],
                ix: 6
            }
        },
        ao: 0,
        w: 472,
        h: 472,
        ip: 0,
        op: 3600,
        st: 0,
        bm: 0
    }, {
        ddd: 0,
        ind: 10,
        ty: 0,
        nm: "dot",
        refId: "comp_0",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 51,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [236, 236, 0],
                ix: 1
            },
            s: {
                a: 0,
                k: [100, 100, 100],
                ix: 6
            }
        },
        ao: 0,
        w: 472,
        h: 472,
        ip: 0,
        op: 3600,
        st: 0,
        bm: 0
    }, {
        ddd: 0,
        ind: 11,
        ty: 0,
        nm: "dot",
        refId: "comp_0",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 0,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [236, 236, 0],
                ix: 1
            },
            s: {
                a: 0,
                k: [100, 100, 100],
                ix: 6
            }
        },
        ao: 0,
        w: 472,
        h: 472,
        ip: 0,
        op: 3600,
        st: 0,
        bm: 0
    }, {
        ddd: 0,
        ind: 12,
        ty: 4,
        nm: "line",
        sr: 1,
        ks: {
            o: {
                a: 0,
                k: 100,
                ix: 11
            },
            r: {
                a: 0,
                k: 180,
                ix: 10
            },
            p: {
                a: 0,
                k: [236, 236, 0],
                ix: 2
            },
            a: {
                a: 0,
                k: [24.938, 28.938, 0],
                ix: 1
            },
            s: {
                a: 0,
                k: [100, 100, 100],
                ix: 6
            }
        },
        ao: 0,
        ef: [{
            ty: 5,
            nm: "",
            np: 6,
            mn: "PSEUDO/DUIK_Spring_Bounce",
            ix: 1,
            en: 1,
            ef: [{
                ty: 0,
                nm: "Elasticity",
                mn: "PSEUDO/DUIK_Spring_Bounce-0001",
                ix: 1,
                v: {
                    a: 0,
                    k: 4,
                    ix: 1
                }
            }, {
                ty: 0,
                nm: "Damping",
                mn: "PSEUDO/DUIK_Spring_Bounce-0002",
                ix: 2,
                v: {
                    a: 0,
                    k: 5,
                    ix: 2
                }
            }, {
                ty: 7,
                nm: "Bounce",
                mn: "PSEUDO/DUIK_Spring_Bounce-0003",
                ix: 3,
                v: {
                    a: 0,
                    k: 0,
                    ix: 3
                }
            }, {
                ty: 0,
                nm: "Trigger speed",
                mn: "PSEUDO/DUIK_Spring_Bounce-0004",
                ix: 4,
                v: {
                    a: 0,
                    k: .1,
                    ix: 4
                }
            }]
        }],
        shapes: [{
            ty: "gr",
            it: [{
                d: 1,
                ty: "el",
                s: {
                    a: 0,
                    k: [376, 376],
                    ix: 2
                },
                p: {
                    a: 0,
                    k: [0, 0],
                    ix: 3
                },
                nm: "",
                mn: "ADBE Vector Shape - Ellipse",
                hd: !1
            }, {
                ty: "st",
                c: {
                    a: 0,
                    k: [.333333333333, .866666666667, .949019607843, 1],
                    ix: 3
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 4
                },
                w: {
                    a: 1,
                    k: [{
                        i: {
                            x: [.667],
                            y: [.894]
                        },
                        o: {
                            x: [.465],
                            y: [0]
                        },
                        n: ["0p667_0p894_0p465_0"],
                        t: 180,
                        s: [10],
                        e: [20]
                    }, {
                        t: 192
                    }],
                    ix: 5
                },
                lc: 2,
                lj: 2,
                nm: "",
                mn: "ADBE Vector Graphic - Stroke",
                hd: !1
            }, {
                ty: "tr",
                p: {
                    a: 0,
                    k: [24.938, 28.938],
                    ix: 2
                },
                a: {
                    a: 0,
                    k: [0, 0],
                    ix: 1
                },
                s: {
                    a: 0,
                    k: [100, 100],
                    ix: 3
                },
                r: {
                    a: 0,
                    k: 0,
                    ix: 6
                },
                o: {
                    a: 0,
                    k: 100,
                    ix: 7
                },
                sk: {
                    a: 0,
                    k: 0,
                    ix: 4
                },
                sa: {
                    a: 0,
                    k: 0,
                    ix: 5
                },
                nm: ""
            }],
            nm: "",
            np: 3,
            cix: 2,
            ix: 1,
            mn: "ADBE Vector Group",
            hd: !1
        }, {
            ty: "tm",
            s: {
                a: 0,
                k: 0,
                ix: 1
            },
            e: {
                a: 1,
                k: [{
                    i: {
                        x: [.833],
                        y: [.833]
                    },
                    o: {
                        x: [.167],
                        y: [.167]
                    },
                    n: ["0p833_0p833_0p167_0p167"],
                    t: 6,
                    s: [0],
                    e: [100]
                }, {
                    t: 186
                }],
                ix: 2
            },
            o: {
                a: 0,
                k: 0,
                ix: 3
            },
            m: 1,
            ix: 2,
            nm: "",
            mn: "ADBE Vector Filter - Trim",
            hd: !1
        }],
        ip: 6,
        op: 3606,
        st: 6,
        bm: 0
    }],
    markers = [{
        tm: .00166666666667,
        cm: "",
        dr: 0
    }, {
        tm: .05138888888889,
        cm: "",
        dr: 0
    }, {
        tm: .06416666666667,
        cm: "8",
        dr: 0
    }],
    connect = {
        v,
        fr,
        ip,
        op,
        w,
        h,
        nm,
        ddd,
        assets,
        layers,
        markers
    },
    animationData = Object.freeze(Object.defineProperty({
        __proto__: null,
        assets,
        ddd,
        default: connect,
        fr,
        h,
        ip,
        layers,
        markers,
        nm,
        op,
        v,
        w
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    ConnectButton_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$h = {
        class: "connect-component"
    },
    _hoisted_2$g = {
        class: "connect-btn"
    },
    statusDisconnectNum = 1,
    statusDisconnectingNum = 10,
    statusConnectingNum = 180,
    statusConnectedNum = 230,
    _sfc_main$h = {
        __name: "ConnectButton",
        setup(e) {
            let t, r;
            const i = ref({
                    options: {
                        loop: !1
                    },
                    animationData
                }),
                s = useStore(),
                n = computed(() => s.state.connect),
                a = ref("VPN is OFF");

            function l(y) {
                t = y, t.setSpeed(1), t == null || t.goToAndStop(statusDisconnectNum, !0)
            }

            function c() {
                r && clearInterval(r), t == null || t.setSpeed(1), t == null || t.pause()
            }

            function g() {
                t && (c(), t == null || t.goToAndStop(statusConnectingNum, !0), t.setSpeed(1), t.play(), r = setInterval(() => {
                    t.currentFrame >= statusConnectedNum && (c(), t == null || t.goToAndStop(statusConnectedNum, !0))
                }, 10))
            }

            function _() {
                t && (c(), t == null || t.goToAndStop(statusDisconnectNum, !0), t.setSpeed(1), t.play(), r = setInterval(() => {
                    t.currentFrame >= statusConnectingNum ? (c(), t == null || t.goToAndStop(statusConnectingNum, !0)) : t.currentFrame >= 175 ? t.setSpeed(.1) : t.currentFrame >= 150 ? t.setSpeed(.2) : t.currentFrame >= 120 ? t.setSpeed(.4) : t.currentFrame >= 100 && t.setSpeed(.6)
                }, 10))
            }

            function E() {
                t && (c(), t == null || t.goToAndStop(statusDisconnectNum, !0))
            }

            function P() {
                if (!t) return;
                c();
                const y = t.currentFrame;
                y <= 5 || (t.setSpeed(-8), y >= 180 ? t.goToAndPlay(180, !0) : t.play(), r = setInterval(() => {
                    t.currentFrame <= statusDisconnectingNum ? (c(), t == null || t.goToAndStop(statusDisconnectingNum, !0)) : t.currentFrame <= 60 ? t.setSpeed(-.2) : t.currentFrame <= 90 ? t.setSpeed(-1.2) : t.currentFrame <= 130 ? t.setSpeed(-2) : t.currentFrame <= 160 && t.setSpeed(-4)
                }, 10))
            }
            async function x() {
                switch (n.value) {
                    case CONNECT_DISCONNECTED:
                        await s.connectAction();
                        return;
                    case CONNECT_CONNECTED:
                        await s.disconnectAction();
                        return;
                    case CONNECT_CONNECTING:
                        await s.disconnectAction();
                        return;
                    case CONNECT_DISCONNECTING:
                        await s.disconnectAction();
                        return;
                    default:
                        return
                }
            }
            return watchEffect(() => {
                switch (n.value) {
                    case CONNECT_DISCONNECTED:
                        E(), a.value = "VPN is OFF";
                        return;
                    case CONNECT_CONNECTED:
                        g(), a.value = "VPN is ON";
                        return;
                    case CONNECT_CONNECTING:
                        _(), a.value = "Connecting";
                        return;
                    case CONNECT_DISCONNECTING:
                        P(), a.value = "Disconnecting";
                        return;
                    default:
                        return
                }
            }), onMounted(() => {
                document.addEventListener("visibilitychange", () => {
                    document.visibilityState === "visible" && n.value === CONNECT_CONNECTED && (t == null || t.goToAndStop(statusConnectedNum, !0))
                })
            }), (y, d) => (openBlock(), createElementBlock("div", _hoisted_1$h, [createBaseVNode("p", null, toDisplayString(a.value), 1), createBaseVNode("div", _hoisted_2$g, [createVNode(_sfc_main$i, {
                class: "lottie",
                options: i.value,
                onAnimCreated: l
            }, null, 8, ["options"]), createBaseVNode("div", {
                class: "outline",
                onClick: x
            })])]))
        }
    },
    _imports_0$3 = "/assets/img-go-premuim-dd1ac643.png",
    Sidebar_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$g = {
        class: "sidebar"
    },
    _hoisted_2$f = {
        class: "content"
    },
    _hoisted_3$c = {
        class: "account-info"
    },
    _hoisted_4$a = createBaseVNode("i", {
        class: "icon_avatar"
    }, null, -1),
    _hoisted_5$8 = {
        class: "txt-2"
    },
    _hoisted_6$7 = {
        class: "menu"
    },
    _hoisted_7$6 = createBaseVNode("i", {
        class: "icon_rate"
    }, null, -1),
    _hoisted_8$5 = createBaseVNode("i", {
        class: "icon_settings"
    }, null, -1),
    _hoisted_9$5 = createBaseVNode("i", {
        class: "icon_help"
    }, null, -1),
    _hoisted_10$3 = createBaseVNode("i", {
        class: "icon_about"
    }, null, -1),
    _hoisted_11$3 = createBaseVNode("i", {
        class: "icon_out"
    }, null, -1),
    _hoisted_12$3 = createBaseVNode("p", null, "Follow X-VPN official", -1),
    _sfc_main$g = {
        __name: "Sidebar",
        setup(e) {
            const t = useStore(),
                r = computed(() => {
                    var b;
                    return !!((b = t.state.user) != null && b.Email)
                }),
                i = computed(() => {
                    var b;
                    return r.value ? !!((b = t.state.user) != null && b.IsVip) : !1
                }),
                s = computed(() => {
                    var b;
                    return ((b = t.state.user) == null ? void 0 : b.Email) || "i_h8_coconuts"
                }),
                n = computed(() => "Premium account");

            function a() {
                //if (r.value) {
                //    t.toWebSiteAccount();
                //    return
                //}
                //t.toWebSiteSignIn()
            }

            function l() {
                t.toRateUs()
            }

            function c() {
                t.toPage("settings")
            }

            function g() {
                t.toPage("about")
            }

            function _() {
                t.showSignOutDialog()
            }

            function E() {
                t.toPage("goPremium")
            }

            function P() {
                t.toHelpCenter()
            }

            function x() {
                t.toX()
            }

            function y() {
                t.toFacebook()
            }

            function d() {
                t.toInstagram()
            }
            return (b, m) => (openBlock(), createElementBlock("div", _hoisted_1$g, [createBaseVNode("div", _hoisted_2$f, [createBaseVNode("div", _hoisted_3$c, [_hoisted_4$a, createBaseVNode("div", null, [createBaseVNode("p", {
                class: "txt-1",
                onClick: a
            }, toDisplayString(s.value), 1), createBaseVNode("p", _hoisted_5$8, toDisplayString(n.value), 1)])]), i.value ? createCommentVNode("", !0) : (openBlock(), createElementBlock("img", {
                key: 0,
                class: "",
                src: "",
                alt: "",
                onClick: E
            })), createBaseVNode("div", _hoisted_6$7, [createBaseVNode("div", {
                class: "item",
                onClick: l
            }, [_hoisted_7$6, createTextVNode("Rate Us")]), createBaseVNode("div", {
                class: "item",
                onClick: c
            }, [_hoisted_8$5, createTextVNode("Settings")]), createBaseVNode("div", {
                class: "item",
                onClick: P
            }, [_hoisted_9$5, createTextVNode("Help")]), createBaseVNode("div", {
                class: "item",
                onClick: g
            }, [_hoisted_10$3, createTextVNode("About X-VPN")]), r.value ? (openBlock(), createElementBlock("div", {
                key: 0,
                class: "item",
                onClick: _
            }, [_hoisted_11$3, createTextVNode("Sign out")])) : createCommentVNode("", !0)]), createBaseVNode("div", {
                class: "bottom"
            }, [_hoisted_12$3, createBaseVNode("div", {
                class: "media-list"
            }, [createBaseVNode("i", {
                onClick: x,
                class: "icon_x"
            }), createBaseVNode("i", {
                onClick: y,
                class: "icon_facebook"
            }), createBaseVNode("i", {
                onClick: d,
                class: "icon_instagram"
            })])])])]))
        }
    },
    Server_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$f = {
        class: "label"
    },
    _hoisted_2$e = {
        key: 0
    },
    _hoisted_3$b = ["src"],
    _hoisted_4$9 = {
        class: "name"
    },
    _hoisted_5$7 = {
        key: 0
    },
    _hoisted_6$6 = {
        key: 1,
        class: ""
    },
    _sfc_main$f = Object.assign({
        name: "Server",
        inheritAttrs: !1
    }, {
        __name: "Server",
        props: {
            server: Object,
            level: String,
            unfold: {
                type: Boolean,
                default: !1
            }
        },
        emits: ["addFavorite"],
        setup(e) {
            const t = e,
                r = useStore(),
                i = computed(() => {
                    var y;
                    return (y = r.state.user) == null ? void 0 : y.IsVip
                }),
                s = computed(() => t.level || t.server.Level),
                n = computed(() => t.level ? `l-${t.level}` : `l-${t.server.Level}`),
                a = computed(() => t.server.Total && t.server.Total > 1),
                l = computed(() => i.value ? !1 : t.server.IsVip),
                c = computed(() => t.server.ShowNameV2 || t.server.ShowName),
                g = computed(() => t.server.Flag ? "/region_icon_" + t.server.Flag.toLowerCase() + ".png" : "/region_icon_default.png"),
                _ = ref(!1);

            function E() {
                _.value = !_.value
            }
            watchEffect(() => {
                _.value = t.unfold
            });

            function P(y) {
                if (y.target.className.includes("icon_fold_arrow")) return !1;
                //if (!i.value && t.server.IsVip) {
                //    r.toPage("goPremium");
                //    return
                //}
                r.connectWithServerId(t.server.Id)
            }

            function x(y) {
                y.target.src = "/region_icon_default.png"
            }
            return (y, d) => {
                const b = resolveComponent("Server", !0);
                return openBlock(), createElementBlock(Fragment, null, [s.value === 1 ? (openBlock(), createElementBlock(Fragment, {
                    key: 0
                }, [createBaseVNode("div", _hoisted_1$f, [createTextVNode(toDisplayString(e.server.ShowName) + " ", 1), a.value ? (openBlock(), createElementBlock("span", _hoisted_2$e, "(" + toDisplayString(e.server.Total) + ")", 1)) : createCommentVNode("", !0)]), (openBlock(!0), createElementBlock(Fragment, null, renderList(e.server.ChildList, (m, o) => (openBlock(), createBlock(b, {
                    key: m.Id,
                    server: m,
                    class: normalizeClass(o === e.server.ChildList.length - 1 && "no-border")
                }, null, 8, ["server", "class"]))), 128))], 64)) : createCommentVNode("", !0), s.value !== 1 ? (openBlock(), createElementBlock("div", mergeProps({
                    key: 1,
                    class: "server-item"
                }, y.$attrs), [createBaseVNode("div", {
                    class: normalizeClass(["outter-bar", n.value]),
                    onClick: P
                }, [a.value ? (openBlock(), createElementBlock("i", {
                    key: 0,
                    class: normalizeClass(["icon_fold_arrow", _.value ? "unfold" : "fold"]),
                    onClick: E
                }, null, 2)) : createCommentVNode("", !0), createBaseVNode("img", {
                    src: g.value,
                    class: "icon_flag",
                    onError: x
                }, null, 40, _hoisted_3$b), createBaseVNode("span", _hoisted_4$9, [createTextVNode(toDisplayString(c.value) + " ", 1), a.value && s.value === 2 ? (openBlock(), createElementBlock("span", _hoisted_5$7, "(" + toDisplayString(e.server.Total) + ")", 1)) : createCommentVNode("", !0)]), l.value ? (openBlock(), createElementBlock("i", _hoisted_6$6)) : createCommentVNode("", !0)], 2), a.value ? (openBlock(), createElementBlock("div", {
                    key: 0,
                    class: normalizeClass(["inner-list", _.value && "unfold"])
                }, [(openBlock(!0), createElementBlock(Fragment, null, renderList(e.server.ChildList, m => (openBlock(), createBlock(b, {
                    key: m.Id,
                    server: m,
                    unfold: _.value
                }, null, 8, ["server", "unfold"]))), 128))], 2)) : createCommentVNode("", !0)], 16)) : createCommentVNode("", !0)], 64)
            }
        }
    }),
    Location_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$e = {
        class: "common right location-container"
    },
    _hoisted_2$d = createBaseVNode("h1", null, "Select Location", -1),
    _hoisted_3$a = {
        class: "input"
    },
    _hoisted_4$8 = createBaseVNode("i", {
        class: "icon_search"
    }, null, -1),
    _hoisted_5$6 = ["value"],
    _hoisted_6$5 = {
        class: "select-bar"
    },
    _hoisted_7$5 = {
        class: "server-list-item"
    },
    _hoisted_8$4 = {
        class: "server-list-item"
    },
    _hoisted_9$4 = {
        class: "server-list-item"
    },
    _hoisted_10$2 = {
        class: "tips"
    },
    _hoisted_11$2 = createBaseVNode("p", null, "Can't find the location you are looking for?", -1),
    _hoisted_12$2 = {
        class: "row"
    },
    _hoisted_13$2 = {
        class: "search-result"
    },
    _hoisted_14$2 = createBaseVNode("p", null, "Can't find the location you are looking for?", -1),
    _hoisted_15$2 = createBaseVNode("i", {
        class: "icon_go_premium"
    }, null, -1),
    _sfc_main$e = {
        __name: "Location",
        setup(e) {
            const t = useStore(),
                r = ref("all"),
                i = computed(() => {
                    var S;
                    return (S = t.state.user) == null ? void 0 : S.IsVip
                }),
                s = computed(() => t.state.serverGroup),
                n = computed(() => s.value.recommendServer),
                a = computed(() => s.value.allServer),
                l = computed(() => s.value.streamingServer);

            function c() {
                f(), t.toPage("home")
            }

            function g() {
                f(), t.toPage("goPremium")
            }

            function _(S) {
                r.value = S
            }

            function E() {
                t.toHelpCenter()
            }
            onMounted(async () => {
                await t.updateServerGroup()
            });
            const P = ref(!1),
                x = ref(""),
                y = ref([]);
            let d;

            function b(S) {
                const k = S.target.value;
                x.value = k.toLowerCase(), S.target.value = k, d = setTimeout(() => {
                    d && clearTimeout(d), u()
                }, 500)
            }

            function m(S) {
                P.value = !0
            }

            function o(S) {}

            function f() {
                x.value = "", y.value = [], P.value = !1
            }
            async function u() {
                if (x.value === "") {
                    y.value = [];
                    return
                }
                const S = await serverObj.searchServer(x.value);
                y.value = S
            }
            return (S, k) => (openBlock(), createElementBlock("div", _hoisted_1$e, [createBaseVNode("div", {
                class: "top-bar"
            }, [createBaseVNode("i", {
                class: "icon_back",
                onClick: c
            }), _hoisted_2$d]), createBaseVNode("div", {
                class: normalizeClass(["search-bar", P.value && "active"])
            }, [createBaseVNode("div", _hoisted_3$a, [_hoisted_4$8, createBaseVNode("input", {
                type: "text",
                placeholder: "Search for country or city",
                value: x.value,
                onInput: b,
                onFocus: m,
                onBlur: o
            }, null, 40, _hoisted_5$6)]), createBaseVNode("button", {
                onClick: f
            }, "Cancel")], 2), createBaseVNode("div", _hoisted_6$5, [createBaseVNode("span", {
                class: normalizeClass(r.value === "recommend" && "selected"),
                onClick: k[0] || (k[0] = C => _("recommend"))
            }, "Recommended", 2), createBaseVNode("span", {
                class: normalizeClass(r.value === "all" && "selected"),
                onClick: k[1] || (k[1] = C => _("all"))
            }, "All", 2), createBaseVNode("span", {
                class: normalizeClass(r.value === "streaming" && "selected"),
                onClick: k[2] || (k[2] = C => _("streaming"))
            }, "Streaming", 2)]), createBaseVNode("div", {
                class: normalizeClass(["server-list", i.value && "premium"])
            }, [withDirectives(createBaseVNode("div", _hoisted_7$5, [(openBlock(!0), createElementBlock(Fragment, null, renderList(n.value, (C, T) => (openBlock(), createBlock(_sfc_main$f, {
                class: normalizeClass(T === n.value.length - 1 && "no-border"),
                key: C.Id,
                server: C
            }, null, 8, ["class", "server"]))), 128))], 512), [[vShow, r.value === "recommend"]]), withDirectives(createBaseVNode("div", _hoisted_8$4, [(openBlock(!0), createElementBlock(Fragment, null, renderList(a.value, (C, T) => (openBlock(), createBlock(_sfc_main$f, {
                class: normalizeClass(T === a.value.length - 1 && "no-border"),
                key: C.Id,
                server: C
            }, null, 8, ["class", "server"]))), 128))], 512), [[vShow, r.value === "all"]]), withDirectives(createBaseVNode("div", _hoisted_9$4, [(openBlock(!0), createElementBlock(Fragment, null, renderList(l.value, (C, T) => (openBlock(), createBlock(_sfc_main$f, {
                class: normalizeClass(T === l.value.length - 1 && "no-border"),
                key: C.Id,
                server: C
            }, null, 8, ["class", "server"]))), 128))], 512), [[vShow, r.value === "streaming"]]), createBaseVNode("div", _hoisted_10$2, [_hoisted_11$2, createBaseVNode("div", _hoisted_12$2, [withDirectives(createBaseVNode("button", {
                onClick: k[3] || (k[3] = C => _("all"))
            }, "Try All Location", 512), [[vShow, r.value === "streaming"]]), createBaseVNode("button", {
                class: "gray",
                onClick: E
            }, "Contact Support")])])], 2), createBaseVNode("div", {
                class: normalizeClass(["search-container", P.value && "show"])
            }, [createBaseVNode("div", _hoisted_13$2, [withDirectives(createBaseVNode("p", null, "No result", 512), [[vShow, y.value.length === 0]]), (openBlock(!0), createElementBlock(Fragment, null, renderList(y.value, (C, T) => (openBlock(), createBlock(_sfc_main$f, {
                class: normalizeClass(T === y.value.length - 1 && "no-border"),
                key: C.Id,
                server: C
            }, null, 8, ["class", "server"]))), 128))]), createBaseVNode("div", {
                class: "tips"
            }, [_hoisted_14$2, createBaseVNode("div", {
                class: "row"
            }, [createBaseVNode("button", {
                class: "gray",
                onClick: E
            }, "Contact support")])])], 2), i.value ? createCommentVNode("", !0) : (openBlock(), createElementBlock("div", {
                key: 0,
                class: "go-premium",
                onClick: g
            }, [_hoisted_15$2, createTextVNode(" Mod by DevJASH ")]))]))
        }
    },
    Banner_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$d = {
        class: "banner"
    },
    _sfc_main$d = {
        __name: "Banner",
        setup(e) {
            const t = useStore(),
                r = computed(() => {
                    var k;
                    return !!((k = t.state.user) != null && k.Email)
                }),
                i = computed(() => {
                    var k;
                    return r.value ? !!((k = t.state.user) != null && k.IsVip) : !1
                }),
                s = computed(() => {
                    var k;
                    return ((k = t.state.stableConnect) == null ? void 0 : k.status) || !1
                }),
                n = computed(() => ({
                    t1: "Stable Connection is",
                    status: s.value,
                    t2: s.value ? "Connection takes a longer time but is more stable." : "Connect to the server with the lowest ping."
                }));

            function a() {
                t.setStableConnect(!s.value)
            }
            const l = computed(() => {
                    var k;
                    return ((k = t.state.killSwitch) == null ? void 0 : k.status) || !1
                }),
                c = computed(() => ({
                    t1: "Kill Switch is",
                    status: l.value,
                    t2: l.value ? "Disable all internet for Chrome if X-VPN disconnects." : "The traffic might leak when X-VPN disconnects."
                }));

            function g() {
                t.setKillSwitch(!l.value)
            }
            const _ = computed(() => {
                    var k;
                    return ((k = t.state.autoProtection) == null ? void 0 : k.status) || !1
                }),
                E = computed(() => {
                    var k;
                    return ((k = t.state.autoProtection) == null ? void 0 : k.list) || []
                }),
                P = computed(() => ({
                    t1: "Auto Protection is",
                    status: _.value,
                    t2: _.value ? `${E.value.length} ${E.value.length>1?"websites":"website"} ${E.value.length>1?"are":"is"} automatically protected.` : "No website is automatically protected."
                }));

            function x() {
                //if (!i.value && !_.value) {
                //    t.toPage("goPremium");
                //    return
                //}
                t.setAutProtection(!_.value, [...E.value])
            }
            const y = computed(() => {
                    var k;
                    return ((k = t.state.bypass) == null ? void 0 : k.status) || !1
                }),
                d = computed(() => {
                    var k;
                    return ((k = t.state.bypass) == null ? void 0 : k.list) || []
                }),
                b = computed(() => ({
                    t1: "Split Tunneling is",
                    status: y.value,
                    t2: y.value ? `${d.value.length} ${d.value.length>1?"websites":"website"} ${d.value.length>1?"are":"is"} not using X-VPN.` : "All websites are protected by X-VPN tunnel."
                }));

            function m() {
                //if (!i.value && !y.value) {
                //    t.toPage("goPremium");
                //    return
                //}
                t.setBypass(!y.value, [...d.value])
            }
            const o = ref(""),
                f = computed(() => ({
                    stableConnect: n.value,
                    killSwitch: c.value,
                    autoProtection: P.value,
                    bypass: b.value
                })[o.value]);

            function u(k) {
                o.value === "" && (o.value = k)
            }

            function S() {
                o.value = ""
            }
            return (k, C) => {
                var T, B, D, H;
                return openBlock(), createElementBlock(Fragment, null, [createBaseVNode("div", _hoisted_1$d, [createBaseVNode("i", {
                    onMouseenter: C[0] || (C[0] = L => u("stableConnect")),
                    onMouseleave: S,
                    onClick: a,
                    class: normalizeClass(["icon_stable_connect", s.value && "active"])
                }, null, 34), createBaseVNode("i", {
                    onMouseenter: C[1] || (C[1] = L => u("killSwitch")),
                    onMouseleave: S,
                    onClick: g,
                    class: normalizeClass(["icon_kill_switch", l.value && "active"])
                }, null, 34), createBaseVNode("i", {
                    onMouseenter: C[2] || (C[2] = L => u("autoProtection")),
                    onMouseleave: S,
                    onClick: x,
                    class: normalizeClass(["icon_auto_protection", _.value && "active"])
                }, null, 34), createBaseVNode("i", {
                    onMouseenter: C[3] || (C[3] = L => u("bypass")),
                    onMouseleave: S,
                    onClick: m,
                    class: normalizeClass(["icon_bypass", y.value && "active"])
                }, null, 34)]), createBaseVNode("div", {
                    class: normalizeClass(["banner-tips", o.value !== "" && "show"])
                }, [createBaseVNode("h3", null, [createTextVNode(toDisplayString((T = f.value) == null ? void 0 : T.t1) + " ", 1), createBaseVNode("span", {
                    class: normalizeClass(((B = f.value) == null ? void 0 : B.status) && "active")
                }, toDisplayString((D = f.value) != null && D.status ? "Active" : "Inactive"), 3)]), createBaseVNode("p", null, toDisplayString((H = f.value) == null ? void 0 : H.t2), 1)], 2)], 64)
            }
        }
    },
    Switch_vue_vue_type_style_index_0_scoped_d633caed_lang = "",
    _export_sfc = (e, t) => {
        const r = e.__vccOpts || e;
        for (const [i, s] of t) r[i] = s;
        return r
    },
    _withScopeId = e => (pushScopeId("data-v-d633caed"), e = e(), popScopeId(), e),
    _hoisted_1$c = _withScopeId(() => createBaseVNode("div", {
        class: "outline"
    }, [createBaseVNode("div", {
        class: "circle"
    })], -1)),
    _hoisted_2$c = [_hoisted_1$c],
    _sfc_main$c = {
        __name: "Switch",
        props: {
            on: Boolean
        },
        emits: ["toggle"],
        setup(e, {
            emit: t
        }) {
            return (r, i) => (openBlock(), createElementBlock("div", {
                class: normalizeClass(["comp-switch", e.on && "on"]),
                onClick: i[0] || (i[0] = s => t("toggle"))
            }, _hoisted_2$c, 2))
        }
    },
    Switch = _export_sfc(_sfc_main$c, [["__scopeId", "data-v-d633caed"]]),
    Feature_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$b = {
        class: "common right feature"
    },
    _hoisted_2$b = createBaseVNode("h1", null, "Advanced Features", -1),
    _hoisted_3$9 = {
        class: "feature-content"
    },
    _hoisted_4$7 = createBaseVNode("h3", null, "Connection Features", -1),
    _hoisted_5$5 = {
        class: "switch"
    },
    _hoisted_6$4 = {
        class: "item"
    },
    _hoisted_7$4 = {
        class: "txt"
    },
    _hoisted_8$3 = {
        class: "name"
    },
    _hoisted_9$3 = {
        key: 0
    },
    _hoisted_10$1 = createBaseVNode("p", {
        class: "desc"
    }, "Choose websites that do not use the X-VPN tunnel.", -1),
    _hoisted_11$1 = createBaseVNode("i", {
        class: "icon_back_right"
    }, null, -1),
    _hoisted_12$1 = {
        class: "item item-hover"
    },
    _hoisted_13$1 = createBaseVNode("div", {
        class: "txt"
    }, [createBaseVNode("p", {
        class: "name"
    }, "Stable Connection"), createBaseVNode("p", {
        class: "desc"
    }, "Connection takes longer time but is more stable.")], -1),
    _hoisted_14$1 = createBaseVNode("h3", null, "Security Features", -1),
    _hoisted_15$1 = {
        class: "switch"
    },
    _hoisted_16$1 = {
        class: "item"
    },
    _hoisted_17$1 = {
        class: "txt"
    },
    _hoisted_18$1 = {
        class: "name"
    },
    _hoisted_19$1 = {
        key: 0
    },
    _hoisted_20$1 = createBaseVNode("p", {
        class: "desc"
    }, "Choose websites that automatically use X-VPN.", -1),
    _hoisted_21$1 = createBaseVNode("i", {
        class: "icon_back_right"
    }, null, -1),
    _hoisted_22$1 = {
        class: "item item-hover"
    },
    _hoisted_23$1 = createBaseVNode("div", {
        class: "txt"
    }, [createBaseVNode("p", {
        class: "name"
    }, "Kill Switch"), createBaseVNode("p", {
        class: "desc"
    }, "Disable all internet for Chrome if X-VPN disconnects.")], -1),
    _hoisted_24 = createBaseVNode("h3", null, "Security Test", -1),
    _hoisted_25 = createBaseVNode("div", {
        class: "txt"
    }, [createBaseVNode("p", {
        class: "name"
    }, "DNS Leak Test"), createBaseVNode("p", {
        class: "desc"
    }, "Test if you have a DNS leak risk.")], -1),
    _hoisted_26 = createBaseVNode("i", {
        class: "icon_back_right"
    }, null, -1),
    _hoisted_27 = [_hoisted_25, _hoisted_26],
    _hoisted_28 = createBaseVNode("div", {
        class: "txt"
    }, [createBaseVNode("p", {
        class: "name"
    }, "IP Checker"), createBaseVNode("p", {
        class: "desc"
    }, "See all the information about your current IP address.")], -1),
    _hoisted_29 = createBaseVNode("i", {
        class: "icon_back_right"
    }, null, -1),
    _hoisted_30 = [_hoisted_28, _hoisted_29],
    _hoisted_31 = createBaseVNode("div", {
        class: "txt"
    }, [createBaseVNode("p", {
        class: "name"
    }, "Password Generator"), createBaseVNode("p", {
        class: "desc"
    }, "Automatically block all trackers when you browsing.")], -1),
    _hoisted_32 = createBaseVNode("i", {
        class: "icon_back_right"
    }, null, -1),
    _hoisted_33 = [_hoisted_31, _hoisted_32],
    _hoisted_34 = createBaseVNode("div", {
        class: "txt"
    }, [createBaseVNode("p", {
        class: "name"
    }, "WebRTC Leak Test"), createBaseVNode("p", {
        class: "desc"
    }, "Test if your browser is exposing IP to website you visit.")], -1),
    _hoisted_35 = createBaseVNode("i", {
        class: "icon_back_right"
    }, null, -1),
    _hoisted_36 = [_hoisted_34, _hoisted_35],
    _sfc_main$b = {
        __name: "Feature",
        setup(e) {
            const t = useStore(),
                r = computed(() => {
                    var C;
                    return (C = t.state.user) == null ? void 0 : C.IsVip
                }),
                i = computed(() => t.state.connect === CONNECT_CONNECTED),
                s = computed(() => t.state.bypass),
                n = computed(() => {
                    var C;
                    return ((C = s.value) == null ? void 0 : C.status) || !1
                }),
                a = computed(() => {
                    var C;
                    return ((C = s.value) == null ? void 0 : C.list) || []
                });

            function l() {
                //if (!r.value && !n.value) {
                //    t.toPage("goPremium");
                //    return
                //}
                if (i.value) {
                    showError(DIALOG_SPLITTUNNEL_CONNECTED);
                    return
                }
                t.setBypass(!n.value, [...a.value])
            }

            function c() {
                if (i.value) {
                    showError(DIALOG_SPLITTUNNEL_CONNECTED);
                    return
                }
                t.toPage("splitTunnel")
            }
            const g = computed(() => t.state.stableConnect.status || !1);

            function _() {
                t.setStableConnect(!g.value)
            }
            const E = computed(() => t.state.autoProtection),
                P = computed(() => {
                    var C;
                    return ((C = E.value) == null ? void 0 : C.status) || !1
                }),
                x = computed(() => {
                    var C;
                    return ((C = E.value) == null ? void 0 : C.list) || []
                });

            function y() {
                //if (!r.value && !P.value) {
                 //   t.toPage("goPremium");
                 //   return
                //}
                t.setAutProtection(!P.value, [...x.value])
            }

            function d() {
                t.toPage("autoProtect")
            }
            const b = computed(() => t.state.killSwitch.status || !1);

            function m() {
                t.setKillSwitch(!b.value)
            }
            computed(() => t.state.webRtc.status || !1);

            function o() {
                t.toPage("home")
            }

            function f() {
                t.toWebsiteDnsLeakTest()
            }

            function u() {
                t.toWebsiteIpChecker()
            }

            function S() {
                t.toWebsitePasswordGenerator()
            }

            function k() {
                t.toWebsiteWebRtcLeakTest()
            }
            return (C, T) => (openBlock(), createElementBlock("div", _hoisted_1$b, [createBaseVNode("div", {
                class: "top-bar"
            }, [createBaseVNode("i", {
                class: "icon_back",
                onClick: o
            }), _hoisted_2$b]), createBaseVNode("div", _hoisted_3$9, [_hoisted_4$7, createBaseVNode("div", _hoisted_5$5, [createBaseVNode("div", _hoisted_6$4, [createBaseVNode("div", _hoisted_7$4, [createBaseVNode("p", _hoisted_8$3, [createTextVNode("Split Tunneling "), r.value ? createCommentVNode("", !0) : (openBlock(), createElementBlock("span", _hoisted_9$3, ""))]), _hoisted_10$1]), createVNode(Switch, {
                on: n.value,
                onToggle: l
            }, null, 8, ["on"])]), n.value ? (openBlock(), createElementBlock("div", {
                key: 0,
                class: "next-link",
                onClick: c
            }, [createBaseVNode("p", null, toDisplayString(a.value.length) + " " + toDisplayString(a.value.length > 1 ? "Websites" : "Website") + " Selected", 1), _hoisted_11$1])) : createCommentVNode("", !0)]), createBaseVNode("div", _hoisted_12$1, [_hoisted_13$1, createVNode(Switch, {
                on: g.value,
                onToggle: _
            }, null, 8, ["on"])]), _hoisted_14$1, createBaseVNode("div", _hoisted_15$1, [createBaseVNode("div", _hoisted_16$1, [createBaseVNode("div", _hoisted_17$1, [createBaseVNode("p", _hoisted_18$1, [createTextVNode("Auto Protection "), r.value ? createCommentVNode("", !0) : (openBlock(), createElementBlock("span", _hoisted_19$1, ""))]), _hoisted_20$1]), createVNode(Switch, {
                on: P.value,
                onToggle: y
            }, null, 8, ["on"])]), P.value ? (openBlock(), createElementBlock("div", {
                key: 0,
                class: "next-link",
                onClick: d
            }, [createBaseVNode("p", null, toDisplayString(x.value.length) + " " + toDisplayString(x.value.length > 1 ? "Websites" : "Website") + " Selected", 1), _hoisted_21$1])) : createCommentVNode("", !0)]), createBaseVNode("div", _hoisted_22$1, [_hoisted_23$1, createVNode(Switch, {
                on: b.value,
                onToggle: m
            }, null, 8, ["on"])]), _hoisted_24, createBaseVNode("div", {
                class: "item txt-long",
                onClick: f
            }, _hoisted_27), createBaseVNode("div", {
                class: "item txt-long",
                onClick: u
            }, _hoisted_30), createBaseVNode("div", {
                class: "item txt-long",
                onClick: S
            }, _hoisted_33), createBaseVNode("div", {
                class: "item txt-long",
                onClick: k
            }, _hoisted_36)])]))
        }
    },
    _imports_0$2 = "/assets/img-premium-advantage-b65d34d6.png",
    GoPremium_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$a = {
        class: "go-premium-container"
    },
    _hoisted_2$a = createStaticVNode('<h1>What you get with this mod?</h1><img class="img-advantage" src="' + _imports_0$2 + '" alt=""><div class="icon-list"><div class="item"><i class="icon_splittunnel"></i> Split Tunneling </div><div class="item"><i class="icon_killswitch"></i> Kill Switch </div><div class="item"><i class="icon_autoprotect"></i> Auto Protection </div><div class="item"><i class="icon_securitytest"></i> Security Test </div></div>', 3),
    _sfc_main$a = {
        __name: "GoPremium",
        setup(e) {
            const t = useStore();

            function r() {
                t.toWebSiteSignIn()
            }

            function i() {
                t.toWebSitePricing()
            }

            function s() {
                t.toPage("home")
            }
            return (n, a) => (openBlock(), createElementBlock("div", _hoisted_1$a, [createBaseVNode("i", {
                class: "icon_back",
                onClick: s
            }), _hoisted_2$a, createBaseVNode("button", {
                onClick: i
            }, "Check what you would have paid"), createBaseVNode("p", {
                class: "tips"
            }, [createTextVNode("Mod by i_h8_coconuts ")])]))
        }
    },
    SplitTunnel_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$9 = {
        class: "common right split-tunnel"
    },
    _hoisted_2$9 = createBaseVNode("h1", null, "Split Tunneling", -1),
    _hoisted_3$8 = {
        class: "feature-setting-content"
    },
    _hoisted_4$6 = createBaseVNode("p", null, "Add website you want to bypass: ", -1),
    _hoisted_5$4 = {
        class: "input-bar"
    },
    _hoisted_6$3 = ["onKeyup"],
    _hoisted_7$3 = {
        class: "selected-bar"
    },
    _hoisted_8$2 = {
        class: "list"
    },
    _hoisted_9$2 = ["onClick"],
    _sfc_main$9 = {
        __name: "SplitTunnel",
        setup(e) {
            const t = useStore(),
                r = computed(() => t.state.bypass),
                i = computed(() => {
                    var y;
                    return ((y = r.value) == null ? void 0 : y.list) || []
                }),
                s = computed(() => i.value.length || 0),
                n = computed(() => i.value.length > 1 ? "Websites" : "Website"),
                a = computed(() => i.value.length > 1 ? "are" : "is");

            function l() {
                t.toPage("feature")
            }
            const c = ref(""),
                g = ref(!1),
                _ = ref("");

            function E(y) {
                return new RegExp("^(?:(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$)|^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$").test(y.toLowerCase())
            }

            function P() {
                const y = c.value.toLowerCase();
                if (c.value = y, !E(y)) {
                    g.value = !0, _.value = "This doesn't look like a valid URL.";
                    return
                }
                const d = Array.isArray(i.value) ? i.value : [];
                for (let b = 0; b < d.length; b++)
                    if (d[b] === y) {
                        g.value = !0, _.value = "Repeat URL.";
                        return
                    } g.value = !1, _.value = "", t.setBypass(!0, [...d, y]), c.value = ""
            }

            function x(y) {
                const d = i.value.filter(b => b !== y);
                t.setBypass(!0, [...d])
            }
            return (y, d) => (openBlock(), createElementBlock("div", _hoisted_1$9, [createBaseVNode("div", {
                class: "top-bar"
            }, [createBaseVNode("i", {
                class: "icon_back",
                onClick: l
            }), _hoisted_2$9]), createBaseVNode("div", _hoisted_3$8, [_hoisted_4$6, createBaseVNode("div", _hoisted_5$4, [withDirectives(createBaseVNode("input", {
                type: "text",
                placeholder: "Enter a domain name, like: xvpn.io",
                "onUpdate:modelValue": d[0] || (d[0] = b => c.value = b),
                onKeyup: withKeys(P, ["enter"])
            }, null, 40, _hoisted_6$3), [[vModelText, c.value]]), createBaseVNode("button", {
                onClick: P
            }, "Add"), withDirectives(createBaseVNode("span", {
                class: "error"
            }, toDisplayString(_.value), 513), [[vShow, g.value]])]), createBaseVNode("div", _hoisted_7$3, [createBaseVNode("p", null, [createBaseVNode("span", null, toDisplayString(s.value) + " " + toDisplayString(n.value), 1), createTextVNode(" " + toDisplayString(a.value) + " selected:", 1)]), createBaseVNode("div", _hoisted_8$2, [(openBlock(!0), createElementBlock(Fragment, null, renderList(i.value, b => (openBlock(), createElementBlock("div", {
                class: "item",
                key: b
            }, [createBaseVNode("span", null, toDisplayString(b), 1), createTextVNode(), createBaseVNode("i", {
                class: "icon_delete",
                onClick: m => x(b)
            }, null, 8, _hoisted_9$2)]))), 128))])])])]))
        }
    },
    AutoProtect_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$8 = {
        class: "common right auto-protection"
    },
    _hoisted_2$8 = createBaseVNode("h1", null, "Auto Protection", -1),
    _hoisted_3$7 = {
        class: "feature-setting-content"
    },
    _hoisted_4$5 = createBaseVNode("p", null, "Add website you want to auto-protect: ", -1),
    _hoisted_5$3 = {
        class: "input-bar"
    },
    _hoisted_6$2 = ["onKeyup"],
    _hoisted_7$2 = {
        class: "selected-bar"
    },
    _hoisted_8$1 = {
        class: "list"
    },
    _hoisted_9$1 = ["onClick"],
    _sfc_main$8 = {
        __name: "AutoProtect",
        setup(e) {
            const t = useStore(),
                r = computed(() => t.state.autoProtection),
                i = computed(() => {
                    var y;
                    return ((y = r.value) == null ? void 0 : y.list) || []
                }),
                s = computed(() => {
                    var y;
                    return ((y = i.value) == null ? void 0 : y.length) || 0
                }),
                n = computed(() => {
                    var y;
                    return ((y = i.value) == null ? void 0 : y.length) > 1 ? "Websites" : "Website"
                }),
                a = computed(() => {
                    var y;
                    return ((y = i.value) == null ? void 0 : y.length) > 1 ? "are" : "is"
                });

            function l() {
                t.toPage("feature")
            }
            const c = ref(""),
                g = ref(!1),
                _ = ref("");

            function E(y) {
                return new RegExp("^(?:(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$)|^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$").test(y.toLowerCase())
            }

            function P() {
                const y = c.value.toLowerCase();
                if (c.value = y, !E(y)) {
                    g.value = !0, _.value = "This doesn't look like a valid URL.";
                    return
                }
                const d = Array.isArray(i.value) ? i.value : [];
                for (let b = 0; b < d.length; b++)
                    if (d[b] === y) {
                        g.value = !0, _.value = "Repeat URL.";
                        return
                    } t.updateAutoProtectionList([...d, y]), g.value = !1, _.value = "", c.value = ""
            }

            function x(y) {
                const d = i.value.filter(b => b !== y);
                t.updateAutoProtectionList([...d])
            }
            return (y, d) => (openBlock(), createElementBlock("div", _hoisted_1$8, [createBaseVNode("div", {
                class: "top-bar"
            }, [createBaseVNode("i", {
                class: "icon_back",
                onClick: l
            }), _hoisted_2$8]), createBaseVNode("div", _hoisted_3$7, [_hoisted_4$5, createBaseVNode("div", _hoisted_5$3, [withDirectives(createBaseVNode("input", {
                type: "text",
                placeholder: "Enter a domain name, like: xvpn.io",
                "onUpdate:modelValue": d[0] || (d[0] = b => c.value = b),
                onKeyup: withKeys(P, ["enter"])
            }, null, 40, _hoisted_6$2), [[vModelText, c.value]]), createBaseVNode("button", {
                onClick: P
            }, "Add"), withDirectives(createBaseVNode("span", {
                class: "error"
            }, toDisplayString(_.value), 513), [[vShow, g.value]])]), createBaseVNode("div", _hoisted_7$2, [createBaseVNode("p", null, [createBaseVNode("span", null, toDisplayString(s.value) + " " + toDisplayString(n.value), 1), createTextVNode(" " + toDisplayString(a.value) + " selected:", 1)]), createBaseVNode("div", _hoisted_8$1, [(openBlock(!0), createElementBlock(Fragment, null, renderList(i.value, b => (openBlock(), createElementBlock("div", {
                class: "item",
                key: b
            }, [createBaseVNode("span", null, toDisplayString(b), 1), createTextVNode(), createBaseVNode("i", {
                class: "icon_delete",
                onClick: m => x(b)
            }, null, 8, _hoisted_9$1)]))), 128))])])])]))
        }
    },
    _imports_0$1 = "/assets/img_logo-0c9fd662.png",
    About_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$7 = {
        class: "common right about"
    },
    _hoisted_2$7 = createBaseVNode("h1", null, "About X-VPN", -1),
    _hoisted_3$6 = createBaseVNode("img", {
        class: "logo",
        src: _imports_0$1,
        alt: ""
    }, null, -1),
    _hoisted_4$4 = {
        class: "version"
    },
    _hoisted_5$2 = createBaseVNode("p", {
        class: "s"
    }, "Follow Us", -1),
    _sfc_main$7 = {
        __name: "About",
        setup(e) {
            const t = useStore(),
                r = ref(VERSION);

            function i() {
                t.toPage("home")
            }

            function s() {
                t.toPrivacyPolicy()
            }

            function n() {
                t.toTermsOfService()
            }

            function a() {
                t.toX()
            }

            function l() {
                t.toFacebook()
            }
            return (c, g) => (openBlock(), createElementBlock("div", _hoisted_1$7, [createBaseVNode("div", {
                class: "top-bar"
            }, [createBaseVNode("i", {
                class: "icon_back",
                onClick: i
            }), _hoisted_2$7]), _hoisted_3$6, createBaseVNode("div", _hoisted_4$4, [createBaseVNode("p", null, "Version " + toDisplayString(r.value), 1)]), createBaseVNode("div", {
                class: "link",
                onClick: s
            }, "Privacy Policy"), createBaseVNode("div", {
                class: "link",
                onClick: n
            }, "Terms of Service"), _hoisted_5$2, createBaseVNode("div", {
                class: "row"
            }, [createBaseVNode("i", {
                class: "icon_x_color",
                onClick: a
            }), createBaseVNode("i", {
                class: "icon_facebook_color",
                onClick: l
            })])]))
        }
    },
    Settings_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$6 = {
        class: "common right settings"
    },
    _hoisted_2$6 = createBaseVNode("h1", null, "Extension Setting", -1),
    _hoisted_3$5 = {
        class: "item"
    },
    _hoisted_4$3 = createBaseVNode("div", {
        class: "txt"
    }, [createBaseVNode("p", {
        class: "name"
    }, "Desktop Notification"), createBaseVNode("p", {
        class: "desc"
    }, "Requires Chrome to have notification permissions.")], -1),
    _sfc_main$6 = {
        __name: "Settings",
        setup(e) {
            const t = useStore(),
                r = computed(() => t.state.settings);

            function i() {
                t.toPage("home")
            }
            const s = computed(() => {
                var a;
                return ((a = r.value) == null ? void 0 : a.notification) || !1
            });

            function n() {
                t.toggleNotification()
            }
            return computed(() => {
                var a;
                return ((a = r.value) == null ? void 0 : a.darkMode) || !1
            }), (a, l) => (openBlock(), createElementBlock("div", _hoisted_1$6, [createBaseVNode("div", {
                class: "top-bar"
            }, [createBaseVNode("i", {
                class: "icon_back",
                onClick: i
            }), _hoisted_2$6]), createBaseVNode("div", _hoisted_3$5, [_hoisted_4$3, createVNode(Switch, {
                on: s.value,
                onToggle: n
            }, null, 8, ["on"])])]))
        }
    },
    Privacy_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$5 = {
        class: "privacy"
    },
    _hoisted_2$5 = createStaticVNode('<div class="scroll"><h1>We care about your privacy</h1><p>Welcome to join X-VPN! For your convenience, we present the part related to your biggest concern about the Privacy Policy here.</p><h3>What we don&#39;t do</h3><p>1. X-VPN does not store your IP address or the server IP address you connect to.</p><p>2. X-VPN does not log your browsing history, data content, or DNS queries.</p><p>3. X-VPN will not sell, use, or disclose any data to third parties, including government entities, for any purpose.</p><h3>What we collect, How and Why</h3><h4>General Information</h4><p>To enhance user experience, we may collect certain device system information and country-level location data. However, please note that we absolutely do not track or record users&#39; IP addresses or any other sensitive information.</p><p>We do record users&#39; email addresses when users choose to create a X-VPN account and registration time to allow them to use a VIP account across multiple devices simultaneously. However, it&#39;s important to remember that X-VPN does not require a real email address, and users can choose to provide a fake address if desired.</p><p>During the process of connecting to X-VPN, we may record connection timestamps, choice of protocol, network type, error reports, and app interactions. These logs are kept for LESS THAN 48 HOURS solely for the purpose of improving the quality of connections. After this period, they are automatically and permanently erased from our system. And please keep in mind we never log the server IP to which users connect, nor do we log their browsing history.</p><h4>Payment Information</h4><p>We keep records of users&#39; subscription status, payment methods, subscribed packages, subscription time, and transaction ID (or reference ID). These details are collected to provide VIP services and troubleshooting support (e.g., refunds or adding packages) to our users. However, please rest assured that we absolutely do not store any credit card or payment information itself.</p><p>Please note this is just part of the terms; visit Privacy Policy(https://xvpn.io/policy) and Terms of Service(https://xvpn.io/terms-service) to view the whole version. By clicking the “Agree and Continue” button, you understand and consent clearly to all the terms set forth in our Privacy Policy and Terms of Service.</p></div>', 1),
    _sfc_main$5 = {
        __name: "Privacy",
        setup(e) {
            const t = useStore();

            function r() {
                t.agreePrivacy()
            }
            return (i, s) => (openBlock(), createElementBlock("div", _hoisted_1$5, [createBaseVNode("div", {
                class: "content"
            }, [_hoisted_2$5, createBaseVNode("button", {
                onClick: r
            }, "Agree & Continue")])]))
        }
    },
    _imports_0 = "/assets/img-other-device-b977079e.png",
    OtherProxyWarning_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$4 = {
        class: "dialog-all"
    },
    _hoisted_2$4 = createBaseVNode("img", {
        src: _imports_0,
        alt: ""
    }, null, -1),
    _hoisted_3$4 = createBaseVNode("p", null, "The proxy setting is blocked by other chrome extensions. Please disable other extensions that may affect X-VPN first.", -1),
    _sfc_main$4 = {
        __name: "OtherProxyWarning",
        setup(e) {
            const t = useStore();

            function r() {
                t.disableOtherCrx()
            }
            return (i, s) => (openBlock(), createElementBlock("div", _hoisted_1$4, [_hoisted_2$4, _hoisted_3$4, createBaseVNode("button", {
                onClick: r
            }, "Got it")]))
        }
    },
    DialogCommon_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$3 = {
        class: "dialog"
    },
    _hoisted_2$3 = {
        class: "content"
    },
    _hoisted_3$3 = createBaseVNode("div", {
        class: "title"
    }, "Connect Failed", -1),
    _hoisted_4$2 = createBaseVNode("div", {
        class: "desc"
    }, [createBaseVNode("p", null, "Please make sure you have an internet connection first, then you can change your location or protocol and try again."), createBaseVNode("p", null, "if you still can't connect, please Contact Support.")], -1),
    _hoisted_5$1 = createBaseVNode("div", {
        class: "title"
    }, "Connection Failed", -1),
    _hoisted_6$1 = createBaseVNode("div", {
        class: "desc"
    }, [createBaseVNode("p", null, "It appears that you have lost the internet connection. Please check your network and try reconnecting.")], -1),
    _hoisted_7$1 = createBaseVNode("div", {
        class: "title"
    }, "Kill Switch is Active", -1),
    _hoisted_8 = createBaseVNode("div", {
        class: "desc"
    }, [createBaseVNode("p", null, "It appears that you have lost the internet connection. X-VPN will automatically protect your traffic after the network is restored.")], -1),
    _hoisted_9 = createBaseVNode("div", {
        class: "title"
    }, "Notice", -1),
    _hoisted_10 = createBaseVNode("div", {
        class: "desc"
    }, [createBaseVNode("p", null, "X-VPN has detected a fluctuation in your network. You can ignore this notice if you find your network works fine.")], -1),
    _hoisted_11 = createBaseVNode("div", {
        class: "title"
    }, "Notice", -1),
    _hoisted_12 = createBaseVNode("div", {
        class: "desc"
    }, [createBaseVNode("p", null, "Enable the Kill Switch feature will disable your internet if X-VPN disconnects.")], -1),
    _hoisted_13 = createBaseVNode("div", {
        class: "title"
    }, "Process Failed", -1),
    _hoisted_14 = createBaseVNode("div", {
        class: "desc"
    }, [createBaseVNode("p", null, "Please disconnect X-VPN before making a change to Kill Switch.")], -1),
    _hoisted_15 = createBaseVNode("div", {
        class: "title"
    }, "Process Failed", -1),
    _hoisted_16 = createBaseVNode("div", {
        class: "desc"
    }, [createBaseVNode("p", null, "Please disconnect X-VPN before making a change to Split Tunneling.")], -1),
    _hoisted_17 = createBaseVNode("div", {
        class: "title"
    }, "Notice", -1),
    _hoisted_18 = createBaseVNode("div", {
        class: "desc"
    }, [createBaseVNode("p", null, "It is not recommended to turn on this feature when accessing web pages that require Unblock, such as Streaming, but instead, turn on X-VPN before accessing the URL to ensure that the platform won't detect us.")], -1),
    _hoisted_19 = createBaseVNode("div", {
        class: "title"
    }, "Notice", -1),
    _hoisted_20 = createBaseVNode("div", {
        class: "desc"
    }, "Are you sure you want to sign out?", -1),
    _hoisted_21 = createBaseVNode("div", {
        class: "title"
    }, "Sign in Failed", -1),
    _hoisted_22 = createBaseVNode("div", {
        class: "title"
    }, "Notice", -1),
    _hoisted_23 = createBaseVNode("div", {
        class: "desc"
    }, [createBaseVNode("p", null, "Account error, please sign in again.")], -1),
    _sfc_main$3 = {
        __name: "DialogCommon",
        setup(e) {
            const t = useStore(),
                r = computed(() => t.state.error),
                i = computed(() => r.value.type || null);
            async function s() {
                await hideError()
            }
            async function n() {
                await s(), await t.connectAction()
            }
            async function a() {
                await t.disconnectAction(), await s()
            }
            async function l() {
                await t.disconnectAction(), await s(), t.updateUserFromRemote()
            }
            async function c() {
                await t.setKillSwitchOn(), await s()
            }
            async function g() {
                await s(), await t.toSignOut()
            }
            async function _() {
                await s(), t.toAccountDevice()
            }
            const E = computed(() => {
                var y;
                return ((y = t.state.autoProtection) == null ? void 0 : y.list) || []
            });
            async function P() {
                const y = Array.isArray(E.value) ? E.value : [];
                t.onAutoProtection([...y]), await s()
            }
            async function x() {
                t.closeAutProtection(), P()
            }
            return (y, d) => (openBlock(), createElementBlock("div", _hoisted_1$3, [createBaseVNode("div", _hoisted_2$3, [i.value === unref(ERROR_CONNECTFAILED) ? (openBlock(), createElementBlock(Fragment, {
                key: 0
            }, [_hoisted_3$3, _hoisted_4$2, createBaseVNode("div", {
                class: "row"
            }, [createBaseVNode("button", {
                class: "border",
                onClick: s
            }, "Cancel"), createBaseVNode("button", {
                onClick: n
            }, "Retry")])], 64)) : createCommentVNode("", !0), i.value === unref(ERROR_CONNECTION) ? (openBlock(), createElementBlock(Fragment, {
                key: 1
            }, [_hoisted_5$1, _hoisted_6$1, createBaseVNode("div", {
                class: "row"
            }, [createBaseVNode("button", {
                class: "border",
                onClick: s
            }, "Ignore"), createBaseVNode("button", {
                onClick: n
            }, "Reconnect")])], 64)) : createCommentVNode("", !0), i.value === unref(ERROR_CONNECTIONWITHKS) ? (openBlock(), createElementBlock(Fragment, {
                key: 2
            }, [_hoisted_7$1, _hoisted_8, createBaseVNode("button", {
                class: "single",
                onClick: s
            }, "Okay")], 64)) : createCommentVNode("", !0), i.value === unref(ERROR_TUNNEL) ? (openBlock(), createElementBlock(Fragment, {
                key: 3
            }, [_hoisted_9, _hoisted_10, createBaseVNode("div", {
                class: "row"
            }, [createBaseVNode("button", {
                class: "border",
                onClick: s
            }, "Ignore"), createBaseVNode("button", {
                onClick: l
            }, "Disconnect")])], 64)) : createCommentVNode("", !0), i.value === unref(DIALOG_KILLSWITCH_SET) ? (openBlock(), createElementBlock(Fragment, {
                key: 4
            }, [_hoisted_11, _hoisted_12, createBaseVNode("div", {
                class: "row"
            }, [createBaseVNode("button", {
                class: "border",
                onClick: s
            }, "Cancel"), createBaseVNode("button", {
                onClick: c
            }, "Okay")])], 64)) : createCommentVNode("", !0), i.value === unref(DIALOG_KILLSWITCH_CONNECTED) ? (openBlock(), createElementBlock(Fragment, {
                key: 5
            }, [_hoisted_13, _hoisted_14, createBaseVNode("div", {
                class: "row"
            }, [createBaseVNode("button", {
                class: "border",
                onClick: s
            }, "Cancel"), createBaseVNode("button", {
                onClick: a
            }, "Disconnect")])], 64)) : createCommentVNode("", !0), i.value === unref(DIALOG_SPLITTUNNEL_CONNECTED) ? (openBlock(), createElementBlock(Fragment, {
                key: 6
            }, [_hoisted_15, _hoisted_16, createBaseVNode("div", {
                class: "row"
            }, [createBaseVNode("button", {
                class: "border",
                onClick: s
            }, "Cancel"), createBaseVNode("button", {
                onClick: a
            }, "Disconnect")])], 64)) : createCommentVNode("", !0), i.value === unref(DIALOG_AUTOPROTECT_WARNING) ? (openBlock(), createElementBlock(Fragment, {
                key: 7
            }, [_hoisted_17, _hoisted_18, createBaseVNode("button", {
                class: "single",
                onClick: P
            }, "Okay"), createBaseVNode("button", {
                class: "btn-line",
                onClick: x
            }, "Don't remind me again")], 64)) : createCommentVNode("", !0), i.value === unref(DIALOG_SIGNOUT) ? (openBlock(), createElementBlock(Fragment, {
                key: 8
            }, [_hoisted_19, _hoisted_20, createBaseVNode("div", {
                class: "row"
            }, [createBaseVNode("button", {
                class: "border",
                onClick: s
            }, "Cancel"), createBaseVNode("button", {
                onClick: g
            }, "Confirm")])], 64)) : createCommentVNode("", !0), i.value === unref(ERROR_SYNCFAILED) ? (openBlock(), createElementBlock(Fragment, {
                key: 9
            }, [_hoisted_21, createBaseVNode("div", {
                class: "desc"
            }, [createBaseVNode("p", null, [createTextVNode("Login status synchronization failed, please check your "), createBaseVNode("span", {
                class: "link",
                onClick: _
            }, "linked devices"), createTextVNode(" and internet condition. And then sign in again.")])]), createBaseVNode("button", {
                class: "single",
                onClick: s
            }, "Okay")], 64)) : createCommentVNode("", !0), i.value === unref(ERROR_AUTHFAILED) ? (openBlock(), createElementBlock(Fragment, {
                key: 10
            }, [_hoisted_22, _hoisted_23, createBaseVNode("button", {
                class: "single",
                onClick: g
            }, "Okay")], 64)) : createCommentVNode("", !0)])]))
        }
    },
    LimitedLocation_vue_vue_type_style_index_0_lang = "",
    _sfc_main$2 = {},
    _hoisted_1$2 = {
        class: "dialog-all"
    },
    _hoisted_2$2 = createBaseVNode("img", {
        src: _imports_0,
        alt: ""
    }, null, -1),
    _hoisted_3$2 = createBaseVNode("p", null, "We are sorry to inform you that X-VPN does not provide VPN service in your region.", -1),
    _hoisted_4$1 = [_hoisted_2$2, _hoisted_3$2];

function _sfc_render(e, t) {
    return openBlock(), createElementBlock("div", _hoisted_1$2, _hoisted_4$1)
}
const LimitedLocation = _export_sfc(_sfc_main$2, [["render", _sfc_render]]),
    Debug_vue_vue_type_style_index_0_lang = "",
    _hoisted_1$1 = {
        class: "common right debug-container"
    },
    _hoisted_2$1 = createBaseVNode("h1", null, "Debug", -1),
    _hoisted_3$1 = {
        class: "content"
    },
    _hoisted_4 = createBaseVNode("h2", null, "User", -1),
    _hoisted_5 = {
        class: "item"
    },
    _hoisted_6 = createBaseVNode("h2", null, "Connect Info", -1),
    _hoisted_7 = {
        class: "item"
    },
    _sfc_main$1 = {
        __name: "Debug",
        emits: ["close"],
        setup(e, {
            emit: t
        }) {
            const r = useStore(),
                i = ref({}),
                s = ref({});

            function n() {
                t("close")
            }
            return onMounted(async () => {
                const [a, l] = await r.getConnectInfo();
                !a && l && (s.value = l), i.value = await r.getUser()
            }), (a, l) => (openBlock(), createElementBlock("div", _hoisted_1$1, [createBaseVNode("div", {
                class: "top-bar"
            }, [createBaseVNode("i", {
                class: "icon_back",
                onClick: n
            }), _hoisted_2$1]), createBaseVNode("div", _hoisted_3$1, [_hoisted_4, (openBlock(!0), createElementBlock(Fragment, null, renderList(i.value, (c, g) => (openBlock(), createElementBlock("div", _hoisted_5, [createBaseVNode("span", null, toDisplayString(g), 1), createTextVNode(), createBaseVNode("span", null, toDisplayString(c), 1)]))), 256)), _hoisted_6, (openBlock(!0), createElementBlock(Fragment, null, renderList(s.value, (c, g) => (openBlock(), createElementBlock("div", _hoisted_7, [createBaseVNode("span", null, toDisplayString(g), 1), createTextVNode(), createBaseVNode("span", null, toDisplayString(c), 1)]))), 256))])]))
        }
    },
    App_vue_vue_type_style_index_0_lang = "",
    _hoisted_1 = {
        class: "content"
    },
    _hoisted_2 = ["src"],
    _hoisted_3 = createBaseVNode("i", {
        class: "icon_arrow_right"
    }, null, -1),
    _sfc_main = {
        __name: "App",
        setup(e) {
            const t = useStore(),
                r = computed(() => {
                    var C;
                    return (C = t.state.user) == null ? void 0 : C.IsVip
                }),
                i = computed(() => t.state.page);

            function s(C) {
                t.toPage(C)
            }
            const n = computed(() => i.value === "home" ? "" : "show");

            function a() {
                t.toPage("home")
            }
            const l = computed(() => t.state.error),
                c = computed(() => l.value.status || !1),
                g = computed(() => c.value ? "show" : ""),
                _ = computed(() => t.state.server),
                E = computed(() => _.value.Id === ""),
                P = computed(() => r.value ? "The Fastest Server" : "Free Server"),
                x = computed(() => r.value ? "/region_icon_fastest.png" : "/region_icon_default.png"),
                y = computed(() => E.value ? P.value : _.value.ShowNameV2 || _.value.ShowName || P.value),
                d = computed(() => E.value || !_.value.Flag ? x.value : "/region_icon_" + _.value.Flag.toLowerCase() + ".png");

            function b(C) {
                C.target.src = "/region_icon_default.png"
            }
            const m = computed(() => t.state.settings),
                o = computed(() => {
                    var C;
                    return ((C = m.value) == null ? void 0 : C.darkMode) || !1
                });
            watchEffect(() => {
                o.value ? document.querySelector("#app").classList.add("dark") : document.querySelector("#app").classList.remove("dark")
            });
            const f = computed(() => t.state.limitedLocation);
            onMounted(async () => {
                if (!await t.isPrivacyShown()) {
                    t.toPage("privacy");
                    return
                }
                t.updateUserFromRemote(), t.getCcInfo()
            });
            const u = ref(!1);
            let S = 0;

            function k() {
                S += 1, S >= 20 && (u.value = !0, S = 0)
            }
            return (C, T) => (openBlock(), createElementBlock(Fragment, null, [createBaseVNode("header", null, [createBaseVNode("i", {
                class: "icon_menu",
                onClick: T[0] || (T[0] = B => s("sidebar"))
            }), createBaseVNode("i", {
                class: "icon_logo",
                onClick: k
            }), createBaseVNode("i", {
                class: "icon_menu2",
                onClick: T[1] || (T[1] = B => s("feature"))
            })]), createBaseVNode("main", null, [createBaseVNode("div", _hoisted_1, [createVNode(_sfc_main$h), createBaseVNode("div", {
                class: "location",
                onClick: T[2] || (T[2] = B => s("location"))
            }, [createBaseVNode("img", {
                class: "icon_flag",
                src: d.value,
                onError: b
            }, null, 40, _hoisted_2), createBaseVNode("p", null, toDisplayString(y.value), 1), _hoisted_3])]), r.value ? createCommentVNode("", !0) : (openBlock(), createElementBlock("img", {
                key: 0,
                class: "go-premium",
                src: _imports_0$4,
                alt: "",
                onClick: T[3] || (T[3] = B => s("goPremium"))
            })), createVNode(_sfc_main$d)]), createBaseVNode("div", {
                class: normalizeClass(["mask", n.value]),
                onClick: a
            }, null, 2), createVNode(_sfc_main$5, {
                class: normalizeClass(i.value === "privacy" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$a, {
                class: normalizeClass(i.value === "goPremium" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$g, {
                class: normalizeClass(i.value === "sidebar" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$e, {
                class: normalizeClass(i.value === "location" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$b, {
                class: normalizeClass(i.value === "feature" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$9, {
                class: normalizeClass(i.value === "splitTunnel" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$8, {
                class: normalizeClass(i.value === "autoProtect" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$7, {
                class: normalizeClass(i.value === "about" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$6, {
                class: normalizeClass(i.value === "settings" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$4, {
                class: normalizeClass(i.value === "dialogOtherProxy" && "show")
            }, null, 8, ["class"]), createVNode(_sfc_main$3, {
                class: normalizeClass(g.value)
            }, null, 8, ["class"]), createVNode(LimitedLocation, {
                class: normalizeClass(f.value && "show")
            }, null, 8, ["class"]), u.value ? (openBlock(), createBlock(_sfc_main$1, {
                key: 0,
                onClose: T[4] || (T[4] = B => u.value = !1)
            })) : createCommentVNode("", !0)], 64))
        }
    };
class EventBus {
    constructor() {
        this._eventList = []
    }
    _findEvent(t) {
        return this._eventList.find(r => r.eventName === t)
    }
    _addEvent(t, r = "", i) {
        this._eventList.push({
            eventName: t,
            params: r,
            callbacks: i
        })
    }
    $on(t, r) {
        var s;
        const i = this._findEvent(t);
        i ? (s = i.callbacks) != null && s.find(a => a === r) || (i.callbacks.push(r), r(...i.params)) : this._addEvent(t, "", [r])
    }
    $emit(t, ...r) {
        var s;
        const i = this._findEvent(t);
        i ? (i.params = r, (s = i.callbacks) == null || s.forEach(n => n(...i.params))) : this._addEvent(t, r)
    }
    $off(t) {
        if (typeof t == "string") {
            const r = this._eventList.findIndex(i => i.eventName === t);
            r > -1 && this._eventList.splice(r, 1)
        } else t instanceof Array ? t.map(r => this.$off(r)) : this._eventList = []
    }
}
const eventBusSymbol = Symbol("eventBus"),
    eventBus = new EventBus,
    app = createApp(_sfc_main);
app.provide(storeSymbol, createStore());
app.provide(eventBusSymbol, eventBus);
app.mount("#app");