import './assets/index.js-f8652f26.js';
